MNG FUT Launcher 5.0.0

1. Start the server.
2. Start FIFA separately, normally or with Frosty Mod Manager.
3. Keep the launcher open while playing.
