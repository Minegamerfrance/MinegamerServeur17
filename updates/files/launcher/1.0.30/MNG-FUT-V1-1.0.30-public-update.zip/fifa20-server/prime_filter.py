from __future__ import annotations
import json
import math
import threading
import time
import urllib.parse
import zlib
from typing import Any

MIXED_PACKS = {
    1: (1, 6, 1),
    2: (1, 6, 1),
    3: (1, 6, 1),
    8: (1, 6, 1),
    9: (2, 12, 2),
    10: (1, 6, 1),
    11: (2, 12, 2),
    12: (1, 6, 1),
    13: (2, 12, 2),
    1005: (1, 6, 1),
    1008: (2, 13, 3),
    1009: (2, 13, 3),
    1015: (2, 12, 2),
    1016: (2, 12, 2),
    1017: (1, 4, 2),
    1024: (1, 6, 1),
    1026: (2, 12, 2),
    1027: (1, 6, 1),
}

REMOVED_STORE_PACKS = {4, 5, 6, 7, 23, 24, 1031, 1033, 1034, 1035, 1037}
REMOVED_SBC_SET_IDS = {33, 34, 35, 36, 40, 41}
ADVANCED_GROUP_REWARD_PACK_ID = 1028
PROMO_STORE_ORDER = {15: 1, 1008: 2, 16: 3, 17: 4, 1009: 5, 18: 6}
MARKET_LIVE_BASE = 1180000
MARKET_LIVE_SWING = 90000
FEATURE_DISABLED_MESSAGE = "Kyro is working hard to make this a working feature. Keep an eye out in discord for updates."





# MNG PRIME DATABASE: each Bayern-linked player uses his best historical Regular/Base FUT card.
PRIME_DATABASE_VERSION = "prime-bayern-career-v3-hard-filter"
PRIME_MARKET_DURATION = 21600
PRIME_STARTER_PLAYERS = [167495, 197445, 178603, 183907, 121939, 156616, 181872, 189509, 9014, 189596, 188545]
PRIME_PLAYER_IDS = {9014, 45197, 107713, 121939, 156616, 167495, 168607, 177610, 178603, 181872, 183907, 186569, 188545, 189509, 189596, 190483, 192620, 197445, 205069, 212192, 212622, 213345, 230767, 231227, 231228, 236004}
# The encrypted runtime adds these 12 FIFA 20 stars when the custom player catalog is small.
# They are never part of the Bayern PRIME database and must be removed from state/API output.
LEGACY_FALLBACK_PLAYER_IDS = {20801, 153079, 155862, 158023, 164240, 173731, 176580, 177003, 182521, 183277, 190871, 195864}
# Retired/absent FIFA 17 assets use a valid FIFA 20 native gameplay donor. FUT identity remains the FIFA 17 player.
PRIME_NATIVE_PLAYER_ASSET_OVERRIDES = {
    9014: 225953,      # Arjen Robben -> Steven Bergwijn model donor
    45197: 185132,     # Xabi Alonso -> Mikel San Jose model donor
    107713: 186148,    # Tom Starke -> Ron-Robert Zieler model donor
    121939: 206591,    # Philipp Lahm -> Mitchell Weiser model donor
    168607: 189681,    # Rafinha -> Rafael model donor
    236004: 218339,    # Erdal Ozturk -> Mahmoud Dahoud model donor
}

def _prime_market_resource_ids(module: Any) -> list[int]:
    rows = []
    for resource_id, meta in module.PLAYER_DB.items():
        try:
            rows.append((-int(meta.get("rating", 0) or 0), str(meta.get("name", "") or "").casefold(), int(resource_id)))
        except Exception:
            continue
    rows.sort()
    return [row[2] for row in rows]

def _ensure_prime_market(module: Any) -> int:
    """Keep exactly the Prime catalog available through CPU market listings (one per missing card)."""
    active = _active_cpu_market_players(module)
    wanted = _prime_market_resource_ids(module)
    missing = [rid for rid in wanted if rid not in active]
    if not missing:
        return 0
    rng = module.random.Random((int(time.time()) // 3600) ^ 0xF2017B17)
    added = 0
    for resource_id in missing:
        try:
            if _create_cpu_player_market_listing(module, resource_id, rng):
                added += 1
        except Exception as exc:
            try:
                module.log.warning("PRIME MARKET listing failed resourceId=%s error=%s", resource_id, exc)
            except Exception:
                pass
    if added:
        try:
            module.log.info("PRIME MARKET replenished %d listing(s); catalog=%d", added, len(wanted))
        except Exception:
            pass
    return added

def _item_player_resource_id(item: Any) -> int:
    if not isinstance(item, dict):
        return 0
    kind = str(item.get("itemType", item.get("type", "")) or "").lower()
    if kind != "player":
        return 0
    try:
        return int(item.get("resourceId", item.get("resource_id", item.get("assetId", 0))) or 0)
    except Exception:
        return 0


def _purge_non_prime_state(module: Any) -> dict[str, int]:
    """Remove any non-PRIME player item/auction that survived an older build or was re-injected."""
    state = module.STATE
    removed_auctions = 0
    removed_players = 0
    removed_squads = 0

    for auction in list(state.list_auctions()):
        try:
            item = auction.get("item_data") or auction.get("itemData") or {}
            rid = _item_player_resource_id(item)
            if not rid:
                # Some stored auctions keep resource_id outside item_data.
                kind = str(item.get("itemType", item.get("type", "")) or "").lower() if isinstance(item, dict) else ""
                if kind == "player":
                    rid = int(auction.get("resource_id", auction.get("resourceId", 0)) or 0)
            if rid and rid not in PRIME_PLAYER_IDS:
                trade_id = int(auction.get("trade_id", auction.get("tradeId", auction.get("id", 0))) or 0)
                if trade_id and state.delete_auction(trade_id):
                    removed_auctions += 1
        except Exception:
            pass

    for item in list(state.list_items()):
        try:
            rid = _item_player_resource_id(item)
            if rid and rid not in PRIME_PLAYER_IDS:
                iid = int(item.get("id", item.get("itemId", 0)) or 0)
                if iid and state.delete_item(iid):
                    removed_players += 1
        except Exception:
            pass

    # A stale squad can embed a full copy of a player item even after the item table is cleaned.
    # Only rebuild squads that actually contain a non-PRIME player.
    for squad in list(state.list_squads()):
        try:
            contaminated = False
            slots = squad.get("players", squad.get("squad", [])) or []
            if isinstance(slots, dict):
                slots = list(slots.values())
            for slot in slots if isinstance(slots, list) else []:
                if not isinstance(slot, dict):
                    continue
                embedded = slot.get("itemData") if isinstance(slot.get("itemData"), dict) else slot
                rid = _item_player_resource_id(embedded)
                if rid and rid not in PRIME_PLAYER_IDS:
                    contaminated = True
                    break
            if contaminated:
                sid = int(squad.get("id", squad.get("squadId", 0)) or 0)
                if sid and state.delete_squad(sid):
                    removed_squads += 1
        except Exception:
            pass

    if removed_squads:
        try:
            state._seed_squad()
        except Exception:
            pass
    return {"playersRemoved": removed_players, "auctionsRemoved": removed_auctions, "squadsRemoved": removed_squads}


def _scrub_non_prime_players(value: Any) -> Any:
    """Recursively remove non-PRIME player rows from JSON responses."""
    if isinstance(value, list):
        out = []
        for row in value:
            cleaned = _scrub_non_prime_players(row)
            if cleaned is not None:
                out.append(cleaned)
        return out
    if not isinstance(value, dict):
        return value

    rid = _item_player_resource_id(value)
    if rid and rid not in PRIME_PLAYER_IDS:
        return None
    nested = value.get("itemData")
    nested_rid = _item_player_resource_id(nested) if isinstance(nested, dict) else 0
    if nested_rid and nested_rid not in PRIME_PLAYER_IDS:
        return None

    out = {}
    for key, child in value.items():
        cleaned = _scrub_non_prime_players(child)
        if cleaned is not None:
            out[key] = cleaned
    return out


def _migrate_state_to_prime_database(module: Any) -> dict[str, int]:
    """One-time destructive player migration: removes legacy players/squads/market and seeds the Prime XI."""
    state = module.STATE
    if str(state.get("prime_database_version", "") or "") == PRIME_DATABASE_VERSION:
        cleaned = _purge_non_prime_state(module)
        return {"migrated": 0, **cleaned}
    removed_auctions = 0
    for auction in list(state.list_auctions()):
        try:
            trade_id = int(auction.get("trade_id", auction.get("tradeId", auction.get("id", 0))) or 0)
            if trade_id and state.delete_auction(trade_id): removed_auctions += 1
        except Exception:
            pass
    removed_squads = 0
    for squad in list(state.list_squads()):
        try:
            sid = int(squad.get("id", squad.get("squadId", 0)) or 0)
            if sid and state.delete_squad(sid): removed_squads += 1
        except Exception:
            pass
    removed_players = 0
    for item in list(state.list_items()):
        try:
            if str(item.get("itemType", item.get("type", "")) or "").lower() != "player":
                continue
            iid = int(item.get("id", item.get("itemId", 0)) or 0)
            if iid and state.delete_item(iid): removed_players += 1
        except Exception:
            pass
    # Insert in formation order so _seed_squad() builds a usable f442 XI.
    for rid in PRIME_STARTER_PLAYERS:
        state.make_player_item(int(rid), "club")
    state._seed_squad()
    state.set("prime_database_version", PRIME_DATABASE_VERSION)
    try:
        module.log.warning("PRIME DATABASE migration complete: playersRemoved=%d auctionsRemoved=%d squadsRemoved=%d starterPlayers=%d", removed_players, removed_auctions, removed_squads, len(PRIME_STARTER_PLAYERS))
    except Exception:
        pass
    return {"migrated": 1, "playersRemoved": removed_players, "auctionsRemoved": removed_auctions, "squadsRemoved": removed_squads}

def _market_live_count(actual: int = 0) -> int:
    return max(0, int(actual or 0))


def _route_path(raw_path: str) -> str:
    path = urllib.parse.urlsplit(str(raw_path or "")).path.lower()
    if path.startswith("/ut/ut/"):
        path = "/ut/" + path[7:]
    return path


def _disabled_mode(path: str) -> str:
    low = str(path or "").lower()
    if "/rivals/" in low or low.endswith("/rivals"):
        return "Division Rivals"
    if "/champion/" in low or "/champions/" in low or low.endswith("/champion") or low.endswith("/champions"):
        return "FUT Champions"
    if any(token in low for token in ("sqbt", "squadbattle", "squad/battle", "squad_battle", "featuredsquad")):
        return "Squad Battles"
    return ""

def _round_half_up(value: float) -> int:
    return int(math.floor(float(value) + 0.5))


def fifa20_player_quick_sell(module: Any, resource_id: int) -> int:
    rid = module.canonical_player_resource_id(int(resource_id))
    meta = module.player_meta(rid) or {}
    rating = max(0, int(meta.get("rating", 0) or 0))
    rareflag = int(meta.get("rareflag", 0) or 0)
    special = bool(meta.get("special", False)) or rareflag > 1
    rarity_name = str(meta.get("rarityName", "") or "").strip().lower()
    rarity_class = str(meta.get("rarityClass", "") or "").strip().lower()
    if not special:
        if rating >= 75:
            return int(rating * (8 if rareflag == 1 else 4))
        if rating >= 65:
            return _round_half_up(rating * (3.5 if rareflag == 1 else 1.5))
        return _round_half_up(rating * (0.75 if rareflag == 1 else 0.30))
    if rarity_class == "toty" or rarity_name == "team of the year":
        return int(rating * 800)
    if rareflag in {12, 84} or rarity_name == "icon" or rarity_name.startswith("icon moments"):
        return int(rating * 750)
    if rating >= 75:
        return int(rating * 122)
    if rating >= 65:
        return int(rating * 70)
    return int(rating * 20)


def _regular_rating_weight(rating: int) -> float:
    table = {81: 0.90, 82: 0.80, 83: 0.65, 84: 0.50, 85: 0.36, 86: 0.25, 87: 0.17, 88: 0.11, 89: 0.07, 90: 0.045, 91: 0.028, 92: 0.017, 93: 0.010, 94: 0.006}
    if rating <= 80:
        return 1.0
    if rating >= 95:
        return 0.003
    return table.get(int(rating), 0.003)


def _special_rating_weight(rating: int) -> float:
    table = {85: 0.85, 86: 0.72, 87: 0.60, 88: 0.48, 89: 0.38, 90: 0.29, 91: 0.22, 92: 0.16, 93: 0.115, 94: 0.080, 95: 0.055, 96: 0.038, 97: 0.025, 98: 0.016, 99: 0.010}
    if rating <= 84:
        return 1.0
    return table.get(int(rating), 0.010 if rating >= 99 else 1.0)


def _tier(rating: int) -> str:
    rating = int(rating or 0)
    if rating >= 75:
        return "gold"
    if rating >= 65:
        return "silver"
    return "bronze"


def _is_special(module: Any, item: dict[str, Any]) -> bool:
    rid = int(item.get("resourceId", item.get("assetId", 0)) or 0)
    meta = module.PLAYER_DB.get(rid, {}) or module.player_meta(rid) or {}
    return bool(meta.get("special", False)) or int(item.get("rareflag", meta.get("rareflag", 0)) or 0) > 1


def _pool(module: Any, kind: str, tier: str, rare: bool) -> list[int]:
    if kind == "manager":
        return [int(rid) for rid, meta in module.MANAGER_DB.items() if _tier(int(meta.get("rating", 0) or 0)) == tier and (int(meta.get("rareflag", 0) or 0) > 0) == rare]
    if kind == "consumable":
        return [int(rid) for rid, meta in module.CONSUMABLE_DB.items() if _tier(int(meta.get("rating", 0) or 0)) == tier and (int(meta.get("rareflag", 0) or 0) > 0) == rare]
    if kind == "club_kit":
        native = list(dict.fromkeys(list(getattr(module, "_NATIVE_HOME_KITS", [])) + list(getattr(module, "_NATIVE_AWAY_KITS", []))))
        return [int(rid) for rid in native if int(rid) in module.CLUB_ITEM_DB and (int(module.CLUB_ITEM_DB[int(rid)].get("rareflag", 0) or 0) > 0) == rare]
    if kind == "club_badge":
        native = list(dict.fromkeys(list(getattr(module, "_NATIVE_BADGES", []))))
        return [int(rid) for rid in native if int(rid) in module.CLUB_ITEM_DB and (int(module.CLUB_ITEM_DB[int(rid)].get("rareflag", 0) or 0) > 0) == rare]
    return []


def _pick_resource(module: Any, original_choice, kind: str, tier: str, rare: bool, used: set[int]) -> int | None:
    candidates = [rid for rid in _pool(module, kind, tier, rare) if rid not in used]
    if not candidates:
        candidates = [rid for rid in _pool(module, kind, tier, not rare) if rid not in used]
    if not candidates:
        return None
    return int(original_choice(candidates))


def _pick_consumable(module: Any, original_choice, original_shuffle, tier: str, rare: bool, used: set[int], used_groups: set[int]) -> int | None:
    groups = [list(group) for group in module._consumable_pack_groups()]
    group_indexes = list(range(len(groups)))
    original_shuffle(group_indexes)
    for wanted_rare in (rare, not rare):
        for gi in group_indexes:
            if gi in used_groups:
                continue
            candidates = []
            for rid in groups[gi]:
                rid = int(rid)
                meta = module.CONSUMABLE_DB.get(rid, {})
                if rid in used or _tier(int(meta.get("rating", 0) or 0)) != tier:
                    continue
                if (int(meta.get("rareflag", 0) or 0) > 0) != wanted_rare:
                    continue
                candidates.append(rid)
            if candidates:
                used_groups.add(gi)
                return int(original_choice(candidates))
    positions = []
    for rid, meta in module.CONSUMABLE_DB.items():
        rid = int(rid)
        if rid in used or str(meta.get("sourceMember", "")) != "consumablesPosition":
            continue
        if _tier(int(meta.get("rating", 0) or 0)) != tier:
            continue
        positions.append(rid)
    exact = [rid for rid in positions if (int(module.CONSUMABLE_DB[rid].get("rareflag", 0) or 0) > 0) == rare]
    if exact:
        return int(original_choice(exact))
    if positions:
        return int(original_choice(positions))
    return _pick_resource(module, original_choice, "consumable", tier, rare, used)


def _make_non_player(module: Any, state: Any, original_choice, original_shuffle, kind: str, source: dict[str, Any], used: set[int], used_groups: set[int]) -> dict[str, Any] | None:
    tier = _tier(int(source.get("rating", 0) or 0))
    rare = int(source.get("rareflag", 0) or 0) > 0
    if kind == "consumable":
        rid = _pick_consumable(module, original_choice, original_shuffle, tier, rare, used, used_groups)
    else:
        if kind.startswith("club"):
            tier = "gold"
            rare = True
        rid = _pick_resource(module, original_choice, kind, tier, rare, used)
    if rid is None:
        return None
    if kind == "manager":
        item = state.make_manager_item(rid, "unassigned")
    elif kind == "consumable":
        item = state.make_consumable_item(rid, "unassigned")
    else:
        item = state.make_club_item(rid, "unassigned", "free")
    used.add(rid)
    return item


def _mixed_pack(module: Any, state: Any, pack_id: int, pack: dict[str, Any], original_choice, original_shuffle) -> dict[str, Any]:
    plan = MIXED_PACKS.get(int(pack_id))
    if not plan:
        return pack
    items = list(pack.get("itemData") or [])
    if not items:
        return pack
    manager_count, consumable_count, club_count = plan
    normal = [(idx, item) for idx, item in enumerate(items) if str(item.get("itemType", "player")).lower() == "player" and not _is_special(module, item)]
    normal.sort(key=lambda pair: (int(pair[1].get("rating", 0) or 0), int(pair[1].get("rareflag", 0) or 0), int(pair[1].get("id", 0) or 0)))
    chosen: list[tuple[int, str]] = []
    remaining = list(normal)
    club_kinds = []
    if club_count == 1:
        club_kinds = [original_choice(["club_kit", "club_badge"])]
    elif club_count > 1:
        club_kinds = ["club_kit", "club_badge"] + [original_choice(["club_kit", "club_badge"]) for _ in range(club_count - 2)]
    for club_kind in club_kinds:
        pos = next((i for i, pair in enumerate(remaining) if int(pair[1].get("rareflag", 0) or 0) > 0), None)
        if pos is None:
            break
        idx, _item = remaining.pop(pos)
        chosen.append((idx, club_kind))
    for kind, count in (("manager", manager_count), ("consumable", consumable_count)):
        for _ in range(count):
            if not remaining:
                break
            idx, _item = remaining.pop(0)
            chosen.append((idx, kind))
    used = {int(item.get("resourceId", item.get("assetId", 0)) or 0) for item in items}
    used_groups: set[int] = set()
    for idx, kind in sorted(chosen, key=lambda pair: pair[0], reverse=True):
        source = items[idx]
        replacement = _make_non_player(module, state, original_choice, original_shuffle, kind, source, used, used_groups)
        if replacement is None:
            continue
        try:
            state.delete_item(int(source.get("id", 0) or 0))
        except Exception:
            try:
                state.delete_item(int(replacement.get("id", 0) or 0))
            except Exception:
                pass
            continue
        items[idx] = replacement
    order = {"player": 0, "manager": 1, "development": 2, "kit": 3, "custom": 3, "stadium": 3, "ball": 3}
    items.sort(key=lambda item: order.get(str(item.get("itemType", "player")).lower(), 4))
    pack["itemData"] = items
    pack["itemList"] = items
    pack["items"] = items
    pack["numberItems"] = len(items)
    pack["newcards"] = len(items)
    native_duplicates = list(pack.get("duplicateItemIdList") or [])
    remaining_ids = {int(item.get("id", 0) or 0) for item in items}
    duplicate_pairs = []
    for entry in native_duplicates:
        if not isinstance(entry, dict):
            continue
        item_id = int(entry.get("itemId", 0) or 0)
        if item_id not in remaining_ids:
            continue
        pair = {"itemId": item_id}
        duplicate_id = int(entry.get("duplicateItemId", 0) or 0)
        if duplicate_id:
            pair["duplicateItemId"] = duplicate_id
        duplicate_pairs.append(pair)
    pack["duplicateItemIdList"] = duplicate_pairs
    try:
        detail = []
        for item in items:
            rid = int(item.get("resourceId", item.get("assetId", 0)) or 0)
            kind = str(item.get("itemType", "player")).lower()
            source_member = str(module.CONSUMABLE_DB.get(rid, {}).get("sourceMember", ""))
            family = str(module.CLUB_ITEM_DB.get(rid, {}).get("family", ""))
            detail.append((kind, rid, source_member or family))
        module.log.warning("MNG FUT 20 MIXED PACK id=%d items=%s", int(pack_id), detail)
    except Exception:
        pass
    return pack

def _repair_existing_discard_values(module: Any) -> int:
    state = getattr(module, "STATE", None)
    if state is None:
        return 0
    changed = 0
    try:
        items = list(state.list_items())
    except Exception:
        return 0
    for item in items:
        if str(item.get("itemType", "player")).lower() != "player":
            continue
        iid = int(item.get("id", 0) or 0)
        rid = int(item.get("resourceId", item.get("assetId", 0)) or 0)
        if not iid or not rid:
            continue
        value = fifa20_player_quick_sell(module, rid)
        if int(item.get("discardValue", -1) or 0) == value:
            continue
        try:
            state.update_item_fields(iid, {"discardValue": value})
            changed += 1
        except Exception:
            pass
    return changed



def _active_cpu_market_players(module: Any) -> dict[int, dict[str, Any]]:
    """Return active CPU player auctions keyed by player resource id."""
    active: dict[int, dict[str, Any]] = {}
    current = int(module.now_s())
    try:
        auctions = list(module.STATE.list_auctions())
    except Exception:
        return active
    for auction in auctions:
        try:
            if str(auction.get("seller_type", "")).lower() != "cpu":
                continue
            if str(auction.get("status", "active")).lower() != "active":
                continue
            expires_at = int(auction.get("expires_at", 0) or 0)
            if expires_at and expires_at <= current:
                continue
            item = auction.get("item_data") or {}
            if module._market_item_kind(item) != "player":
                continue
            resource_id = int(
                auction.get("resource_id", 0)
                or item.get("resourceId", item.get("assetId", 0))
                or 0
            )
            if resource_id:
                active.setdefault(resource_id, auction)
        except Exception:
            continue
    return active


def _create_cpu_player_market_listing(module: Any, resource_id: int, rng: Any) -> bool:
    """Create a normal CPU transfer-market listing for one FUT player card."""
    resource_id = int(resource_id)
    if resource_id not in module.PLAYER_DB:
        return False
    recommended = int(module._market_recommended_price(resource_id, "player"))
    buy_now = int(module._market_round_price(int(recommended * rng.uniform(0.94, 1.08))))
    starting = int(module._market_round_price(int(buy_now * rng.uniform(0.84, 0.93))))
    if starting >= buy_now:
        starting = max(150, buy_now - int(module._market_bid_increment(buy_now)))
    virtual_item_id = int(module.STATE.next_item_id())
    item = module.STATE.build_player_item(resource_id, virtual_item_id, "trade")
    item["itemState"] = "forSale"
    item["marketDataMinPrice"] = 150
    item["marketDataMaxPrice"] = min(
        15000000,
        max(5000, int(module._market_round_price(int(recommended * 2.5)))),
    )
    seller_names = list(getattr(module, "_MARKET_SELLER_NAMES", []) or [])
    seller_name = rng.choice(seller_names) if seller_names else "Local FUT Trader"
    module.STATE.create_auction(
        resource_id=resource_id,
        item_data=item,
        seller_type="cpu",
        seller_name=seller_name,
        starting_bid=starting,
        buy_now_price=buy_now,
        duration=PRIME_MARKET_DURATION,
    )
    return True







def apply(module: Any) -> None:
    original_create_pack = module.State.create_pack
    original_choice = module.random.choice
    original_shuffle = module.random.shuffle
    original_get_pack_cfg = module.get_pack_cfg
    original_store_purchasegroups = module._store_purchasegroups
    original_route_fut = module.route_fut
    original_market_seed = module._market_seed
    original_market_all_pools = module._market_all_pools
    original_easw_get = module.EaswHandler.do_GET
    pack_lock = threading.RLock()
    # The encrypted FIFA20 runtime injects 12 legacy fallback stars if the catalog is tiny.
    # Prime mode explicitly removes them so PLAYER_DB is exactly our imported FIFA17 roster.
    for _rid in list(module.PLAYER_DB.keys()):
        if int(_rid) not in PRIME_PLAYER_IDS:
            module.PLAYER_DB.pop(_rid, None)
    native_overrides = getattr(module, "_NATIVE_PLAYER_ASSET_OVERRIDES", None)
    if isinstance(native_overrides, dict):
        native_overrides.update(PRIME_NATIVE_PLAYER_ASSET_OVERRIDES)
    original_pack_exclusion = getattr(module, "_player_is_excluded_from_packs", None)
    if callable(original_pack_exclusion):
        def prime_pack_exclusion(resource_id, meta):
            if int(resource_id) in PRIME_PLAYER_IDS:
                return False
            return original_pack_exclusion(resource_id, meta)
        module._player_is_excluded_from_packs = prime_pack_exclusion
    prime_migration = _migrate_state_to_prime_database(module)
    prime_cleanup = _purge_non_prime_state(module)
    module.SBC_CATALOG = [entry for entry in module.SBC_CATALOG if int(entry.get("set_id", 0) or 0) not in REMOVED_SBC_SET_IDS]
    for entry in module.SBC_CATALOG:
        if int(entry.get("set_id", 0) or 0) in {20, 21, 22}:
            entry["awards"] = [{"type": "PACK", "pack_id": ADVANCED_GROUP_REWARD_PACK_ID, "count": 1}]
            entry["description"] = {
                20: "Solve four escalating league puzzles for a Jumbo Premium Gold Players Pack.",
                21: "Solve four escalating nation puzzles for a Jumbo Premium Gold Players Pack.",
                22: "Master mixed league-and-nation squads for a Jumbo Premium Gold Players Pack.",
            }[int(entry.get("set_id", 0) or 0)]

    def tuned_get_pack_cfg(pack_id: int):
        try:
            if int(pack_id) in REMOVED_STORE_PACKS:
                return {}
        except Exception:
            pass
        cfg = original_get_pack_cfg(pack_id)
        if not isinstance(cfg, dict) or not cfg:
            return cfg
        cfg = dict(cfg)
        # Prime database contains only 26 base cards and no promo pool. Adapt pack
        # size/rarity requirements to the actually available unique cards so the
        # original pack engine never requests an impossible tier/pool.
        enabled_tiers = []
        for tier_name, weight_key in (("gold", "gold_weight"), ("silver", "silver_weight"), ("bronze", "bronze_weight")):
            if int(cfg.get(weight_key, 0) or 0) > 0:
                enabled_tiers.append(tier_name)
        if not enabled_tiers:
            enabled_tiers = ["gold", "silver", "bronze"]
        common_count = 0
        rare_count = 0
        min_rating = int(cfg.get("min_rating", 0) or 0)
        max_rating = int(cfg.get("max_rating", 99) or 99)
        for meta in module.PLAYER_DB.values():
            rating = int(meta.get("rating", 0) or 0)
            tier = "gold" if rating >= 75 else ("silver" if rating >= 65 else "bronze")
            if tier not in enabled_tiers or rating < min_rating or rating > max_rating:
                continue
            if bool(meta.get("special", False)) or int(meta.get("rareflag", 0) or 0) > 1:
                continue
            if int(meta.get("rareflag", 0) or 0) == 1:
                rare_count += 1
            else:
                common_count += 1
        total = common_count + rare_count
        if total:
            size = min(max(1, int(cfg.get("size", 12) or 12)), total)
            desired_rare = max(0, int(cfg.get("rare_slots", 0) or 0))
            # Ensure both the rare and common portions fit the finite Prime pool.
            rare_slots = max(desired_rare, size - common_count)
            rare_slots = min(rare_slots, rare_count, size)
            if size - rare_slots > common_count:
                size = common_count + rare_slots
            cfg["size"] = max(1, size)
            cfg["rare_slots"] = max(0, min(rare_slots, cfg["size"]))
        cfg["special_chance"] = 0.0
        cfg["guaranteed_specials"] = 0
        cfg["special_weights"] = {}
        cfg["_special_weights"] = {}
        return cfg

    def tuned_store_purchasegroups():
        payload = original_store_purchasegroups()
        if isinstance(payload, dict) and isinstance(payload.get("purchase"), list):
            payload = dict(payload)
            rows = [row for row in payload["purchase"] if int(row.get("packId", row.get("id", 0)) or 0) not in REMOVED_STORE_PACKS]
            for row in rows:
                pid = int(row.get("packId", row.get("id", 0)) or 0)
                if pid in PROMO_STORE_ORDER:
                    order = PROMO_STORE_ORDER[pid]
                    row["categoryList"] = {"categoryId": 4, "orderInCategory": order}
                    row["displayGroup"] = {"value": "special", "priority": 4}
                    row["purchaseGroup"] = "special"
                    row["group"] = "special"
                    row["sortPriority"] = order
                    row["isPromo"] = True
            payload["purchase"] = rows
        return payload

    def tuned_route_fut(method: str, raw_path: str, headers: dict[str, str], body: bytes):
        path = _route_path(raw_path)
        mode = _disabled_mode(path)
        if mode:
            payload = {
                "reason": FEATURE_DISABLED_MESSAGE,
                "code": "FEATURE_DISABLED",
                "message": FEATURE_DISABLED_MESSAGE,
                "error": FEATURE_DISABLED_MESSAGE,
                "errorMessage": FEATURE_DISABLED_MESSAGE,
                "localizedMessage": FEATURE_DISABLED_MESSAGE,
                "title": mode,
            }
            try:
                module.log.info("MNG FUT 20 disabled mode blocked mode=%s path=%s", mode, path)
            except Exception:
                pass
            return 409, {"Cache-Control": "no-store"}, module.json_bytes(payload)
        _purge_non_prime_state(module)
        status, response_headers, response_body = original_route_fut(method, raw_path, headers, body)
        if int(status) == 200:
            try:
                content_type = str((response_headers or {}).get("Content-Type", (response_headers or {}).get("content-type", "")) or "").lower()
                if "json" in content_type or (isinstance(response_body, (bytes, bytearray)) and bytes(response_body).lstrip().startswith((b"{", b"["))):
                    decoded_guard = json.loads(bytes(response_body).decode("utf-8"))
                    cleaned_guard = _scrub_non_prime_players(decoded_guard)
                    if cleaned_guard is not None:
                        response_body = module.json_bytes(cleaned_guard)
            except Exception:
                pass
        if int(status) == 200 and path == "/ut/game/fifa20/hub":
            try:
                decoded = json.loads(response_body.decode("utf-8"))
                if isinstance(decoded, dict):
                    actual = max(
                        int(decoded.get("auctionCount", 0) or 0),
                        int(decoded.get("liveAuctions", 0) or 0),
                        int(decoded.get("liveTransfers", 0) or 0),
                    )
                    live = _market_live_count(actual)
                    decoded["auctionCount"] = live
                    decoded["liveAuctions"] = live
                    decoded["liveTransfers"] = live
                    response_body = module.json_bytes(decoded)
                    try:
                        module.log.info("MNG FUT 20 market population liveTransfers=%d activeLocal=%d", live, actual)
                    except Exception:
                        pass
            except Exception:
                pass
        return status, response_headers, response_body


    def tuned_market_seed():
        # Prime database: only catalog players are listed; no legacy/random market seed.
        _purge_non_prime_state(module)
        _ensure_prime_market(module)

    def prime_market_all_pools():
        pools = original_market_all_pools()
        if not isinstance(pools, dict):
            return pools
        clean = {}
        for bucket, values in pools.items():
            if isinstance(values, (list, tuple, set)):
                clean[bucket] = [int(rid) for rid in values if int(rid) in PRIME_PLAYER_IDS]
            else:
                clean[bucket] = values
        return clean

    def quick_sell(self, resource_id: int) -> int:
        return fifa20_player_quick_sell(module, resource_id)

    def weighted_player_choice(seq):
        try:
            values = list(seq)
            if len(values) >= 2 and all(isinstance(x, int) for x in values):
                sample = values[: min(16, len(values))]
                if sample and all(int(x) in module.PLAYER_DB for x in sample):
                    weights = []
                    for rid in values:
                        meta = module.PLAYER_DB.get(int(rid), {}) or {}
                        rating = int(meta.get("rating", 0) or 0)
                        special = bool(meta.get("special", False)) or int(meta.get("rareflag", 0) or 0) > 1
                        weights.append(_special_rating_weight(rating) if special else _regular_rating_weight(rating))
                    total = sum(weights)
                    if total > 0:
                        return module.random.choices(values, weights=weights, k=1)[0]
        except Exception:
            pass
        return original_choice(seq)

    def weighted_player_shuffle(seq):
        try:
            if isinstance(seq, list) and len(seq) >= 2 and all(isinstance(x, int) for x in seq[: min(16, len(seq))]):
                sample = seq[: min(16, len(seq))]
                if sample and all(int(x) in module.PLAYER_DB for x in sample):
                    keyed = []
                    for rid in seq:
                        meta = module.PLAYER_DB.get(int(rid), {}) or {}
                        rating = int(meta.get("rating", 0) or 0)
                        special = bool(meta.get("special", False)) or int(meta.get("rareflag", 0) or 0) > 1
                        weight = _special_rating_weight(rating) if special else _regular_rating_weight(rating)
                        weight = max(float(weight), 0.000001)
                        keyed.append((module.random.random() ** (1.0 / weight), rid))
                    keyed.sort(key=lambda pair: pair[0])
                    seq[:] = [rid for _, rid in keyed]
                    return None
        except Exception:
            pass
        return original_shuffle(seq)

    def tuned_create_pack(self, pack_id: int = 1):
        with pack_lock:
            module.random.choice = weighted_player_choice
            module.random.shuffle = weighted_player_shuffle
            try:
                _purge_non_prime_state(module)
                pack = original_create_pack(self, pack_id)
                pack = _mixed_pack(module, self, int(pack_id), pack, original_choice, original_shuffle)
                cleaned = _scrub_non_prime_players(pack)
                return cleaned if isinstance(cleaned, dict) else pack
            finally:
                module.random.choice = original_choice
                module.random.shuffle = original_shuffle

    # FIFA 20 team-update / roster protocol capture + v1.5.9 boot-fixed manifest matrix.
    #
    # v1.5.7 proved that FIFA itself requests /roster, but it did not proceed to
    # dbMajorLoc. The remaining unknowns are the exact manifest shape, schema
    # candidate, and version comparison rule used by this FIFA 20 build.
    #
    # FIFA 20 caches the roster manifest during boot. The candidate is therefore
    # selected BEFORE FIFA starts and remains fixed for the whole game session.
    # Each new PLAY/capture advances to the next candidate.
    try:
        import roster_capture as _roster_capture

        _probe_payload = bytes((0x10, 0xFB, 0x00, 0x00, 0x20, 0, 0, 0, 0, 0, 0xE6)) + (b"\x00" * 28)
        _probe_crc_u32 = zlib.crc32(_probe_payload) & 0xFFFFFFFF
        _probe_crc = _probe_crc_u32 if _probe_crc_u32 < 0x80000000 else _probe_crc_u32 - 0x100000000

        _schema_a = "596426fe3525c25b90593b800b9ce5c3c61ccab5"
        _schema_b = "00e20ae6ad44d892ad15ea7f060ce6d97ca9e730"

        def _minimal_xml(version: int) -> bytes:
            loc = f"fifa/fifalive/squads/{version}/Squads20991231000000"
            return f'''<?xml version="1.0" encoding="UTF-8"?>
<squad>
  <squadInfoSet>
    <squadInfo platform="pc64">
      <dbMajor>{version}</dbMajor>
      <dbMajorLoc>{loc}</dbMajorLoc>
      <dbFUTVer>1.fut</dbFUTVer>
      <dbFUTLoc></dbFUTLoc>
    </squadInfo>
  </squadInfoSet>
</squad>'''.encode("utf-8")

        def _full_xml(version: int, schema_crc: str) -> bytes:
            loc = f"fifa/fifalive/squads/{version}/Squads20991231000000"
            return f'''<?xml version="1.0" encoding="UTF-8"?>
<squad>
  <squadInfoSet>
    <squadInfo platform="pc64">
      <dbSchemaCRC>{schema_crc}</dbSchemaCRC>
      <dbMajor>{version}</dbMajor>
      <dbMinor>0</dbMinor>
      <dbMajorCRC>{_probe_crc}</dbMajorCRC>
      <dbMinorCRC>0</dbMinorCRC>
      <dbMajorLoc>{loc}</dbMajorLoc>
      <dbMinorLoc></dbMinorLoc>
      <dbFUTVer>1</dbFUTVer>
      <dbFUTCRC>0</dbFUTCRC>
      <dbFUTLoc></dbFUTLoc>
    </squadInfo>
  </squadInfoSet>
</squad>'''.encode("utf-8")

        _matrix = [
            ("MIN_SEQ2", 2, _minimal_xml(2)),
            ("FULL_A_SEQ2", 2, _full_xml(2, _schema_a)),
            ("FULL_B_SEQ2", 2, _full_xml(2, _schema_b)),
            ("MIN_HIGH999", 999, _minimal_xml(999)),
            ("FULL_A_HIGH999", 999, _full_xml(999, _schema_a)),
            ("FULL_B_HIGH999", 999, _full_xml(999, _schema_b)),
        ]

        def _select_variant():
            index = int(_roster_capture.active_probe_variant_index())
            if index < 0 or index >= len(_matrix):
                index = 1
            return index + 1, _matrix[index]

        def _probe_locations(version: int) -> set[str]:
            name = "Squads20991231000000"
            base = f"/fifa/fifalive/squads/{version}/{name}".lower()
            return {
                base,
                base + ".bin",
                f"/squads/{version}/{name}".lower(),
                f"/squads/{version}/{name}.bin".lower(),
            }

        _all_probe_paths: set[str] = set()
        for _variant_name, _version, _xml in _matrix:
            _all_probe_paths.update(_probe_locations(_version))

        _manifest_alias = "/fifa/fifalive/gen4title/rosterupdate.xml"

        def captured_easw_get(self):
            request_id = None
            req_path = urllib.parse.urlsplit(str(getattr(self, "path", "") or "")).path.lower()
            _headers = getattr(self, "headers", None)
            try:
                _is_self_test = False
                try:
                    _is_self_test = str(_headers.get("X-MNG-Self-Test", "") or "").strip() == "1"
                except Exception:
                    _is_self_test = False

                is_roster = req_path in {"/roster", _manifest_alias}
                variant_no, (variant_name, variant_version, variant_xml) = _select_variant()

                if not _is_self_test:
                    request_id = _roster_capture.record_request(
                        getattr(self, "command", "GET"),
                        getattr(self, "path", ""),
                        _headers,
                        b"",
                    )

                if is_roster:
                    capture_headers = {
                        "Content-Type": "application/xml; charset=utf-8",
                        "EASW": "1",
                        "X-MNG-Build": "1.5.9-roster-boot-matrix",
                        "X-MNG-Probe-Variant": f"{variant_no}/6 {variant_name}",
                    }
                    if request_id:
                        _roster_capture.record_response(request_id, 200, capture_headers, variant_xml)
                    try:
                        module.log.warning(
                            "ROSTER BOOT MATRIX served variant=%d/6 name=%s version=%s path=%s",
                            variant_no, variant_name, variant_version, req_path,
                        )
                    except Exception:
                        pass
                    session_headers = {
                        "EASW-Session": module.STATE.sid(),
                        "EASW-Token": module.STATE.token(),
                        "EASW-Userid": str(module.CFG["nucleus_id"]),
                        "X-MNG-Build": "1.5.9-roster-boot-matrix",
                        "X-MNG-Probe-Variant": f"{variant_no}/6 {variant_name}",
                    }
                    self._send(200, variant_xml, "application/xml; charset=utf-8", session_headers)
                    return None

                if req_path in _all_probe_paths:
                    capture_headers = {
                        "Content-Type": "application/octet-stream",
                        "EASW": "1",
                        "X-MNG-Build": "1.5.9-roster-boot-matrix",
                        "X-MNG-Probe-Download": "1",
                    }
                    if request_id:
                        _roster_capture.record_response(request_id, 200, capture_headers, _probe_payload)
                    try:
                        module.log.warning("ROSTER BOOT MATRIX DOWNLOAD requested path=%s bytes=%d", req_path, len(_probe_payload))
                    except Exception:
                        pass
                    self._send(200, _probe_payload, "application/octet-stream", capture_headers)
                    return None
            except Exception as exc:
                try:
                    module.log.warning("ROSTER BOOT MATRIX GET hook failed: %s", exc)
                except Exception:
                    pass

            return original_easw_get(self)

        def captured_easw_post(self):
            try:
                _headers = getattr(self, "headers", None)
                _is_self_test = False
                try:
                    _is_self_test = str(_headers.get("X-MNG-Self-Test", "") or "").strip() == "1"
                except Exception:
                    _is_self_test = False
                if not _is_self_test:
                    _roster_capture.record_request(
                        getattr(self, "command", "POST"),
                        getattr(self, "path", ""),
                        _headers,
                        b"",
                    )
            except Exception as exc:
                try:
                    module.log.warning("ROSTER CAPTURE POST metadata logging failed: %s", exc)
                except Exception:
                    pass
            return original_easw_post(self)

        module.EaswHandler.do_GET = captured_easw_get
        module.EaswHandler.do_POST = captured_easw_post
    except Exception as exc:
        try:
            module.log.warning("ROSTER BOOT MATRIX hook unavailable: %s", exc)
        except Exception:
            pass

    module.get_pack_cfg = tuned_get_pack_cfg
    module._store_purchasegroups = tuned_store_purchasegroups
    module.route_fut = tuned_route_fut
    module._market_seed = tuned_market_seed
    module._market_all_pools = prime_market_all_pools
    module.State.player_discard_value = quick_sell
    module.State.create_pack = tuned_create_pack
    repaired = _repair_existing_discard_values(module)
    try:
        module.log.warning("MNG FUT 20 release tuning active: PRIME Career Bayern database HARD FILTER, mixed packs, rating weights, discard values, Prime-only market, disabled online modes, removedSBCs=%d, repairedItems=%d", len(REMOVED_SBC_SET_IDS), repaired)
    except Exception:
        pass
