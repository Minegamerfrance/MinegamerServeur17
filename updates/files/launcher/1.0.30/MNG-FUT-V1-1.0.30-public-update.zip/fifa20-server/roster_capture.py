from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parent
SAVE_ROOT = Path(os.environ.get("LOCALAPPDATA", str(ROOT / "runtime"))) / "FUT20LocalFUT"
CAPTURE_ROOT = SAVE_ROOT / "roster-captures"
ACTIVE_FILE = CAPTURE_ROOT / "active.json"
PROBE_STATE_FILE = SAVE_ROOT / "roster-probe-state.json"
PROBE_BUILD = "1.5.10-force-full-a"
PROBE_VARIANTS = [
    "MIN_SEQ2",
    "FULL_A_SEQ2",
    "FULL_B_SEQ2",
    "MIN_HIGH999",
    "FULL_A_HIGH999",
    "FULL_B_HIGH999",
]
_LOCK = threading.RLock()

_SENSITIVE_HEADER_NAMES = {
    "authorization",
    "cookie",
    "set-cookie",
    "easw-token",
    "easw-session",
    "x-auth-token",
    "x-access-token",
    "proxy-authorization",
}


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="milliseconds")


def _now_id() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S-%f")[:-3]


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _read_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            block = f.read(1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _candidate_settings_dirs() -> list[Path]:
    override = os.environ.get("MNG_FIFA20_SETTINGS_DIR", "").strip()
    candidates: list[Path] = []
    if override:
        candidates.append(Path(override).expanduser())

    roots: list[Path] = []
    for value in (
        os.environ.get("USERPROFILE", ""),
        str(Path.home()),
        os.environ.get("OneDrive", ""),
        os.environ.get("OneDriveConsumer", ""),
        os.environ.get("OneDriveCommercial", ""),
    ):
        if value:
            p = Path(value).expanduser()
            if p not in roots:
                roots.append(p)

    for root in roots:
        # If root already is a OneDrive directory, Documents lives directly below it.
        candidates.append(root / "Documents" / "FIFA 20" / "settings")
        # Standard local Documents directory.
        candidates.append(root / "FIFA 20" / "settings")
        # Some installations use an Electronic Arts parent folder.
        candidates.append(root / "Documents" / "Electronic Arts" / "FIFA 20" / "settings")

    user = Path(os.environ.get("USERPROFILE", str(Path.home()))).expanduser()
    try:
        for one_drive in user.glob("OneDrive*"):
            candidates.append(one_drive / "Documents" / "FIFA 20" / "settings")
    except Exception:
        pass

    unique: list[Path] = []
    for path in candidates:
        try:
            normalized = Path(os.path.normpath(str(path)))
        except Exception:
            normalized = path
        if normalized not in unique:
            unique.append(normalized)
    return unique


def _snapshot_settings() -> dict[str, Any]:
    directories = _candidate_settings_dirs()
    found = [p for p in directories if p.is_dir()]
    # Keep the primary expected path in the report even when FIFA has not created it yet.
    watched = found or directories[:1]
    files: dict[str, Any] = {}
    dir_rows: list[dict[str, Any]] = []

    for index, base in enumerate(watched, start=1):
        label = f"settings{index}"
        dir_rows.append({"label": label, "path": str(base), "exists": base.is_dir()})
        if not base.is_dir():
            continue
        try:
            entries = sorted(p for p in base.rglob("*") if p.is_file())
        except Exception:
            entries = []
        for path in entries:
            try:
                stat = path.stat()
                rel = path.relative_to(base).as_posix()
                key = f"{label}/{rel}"
                files[key] = {
                    "key": key,
                    "label": label,
                    "relative_path": rel,
                    "absolute_path": str(path),
                    "size": int(stat.st_size),
                    "mtime_ns": int(stat.st_mtime_ns),
                    "sha256": _sha256(path),
                }
            except Exception as exc:
                files[f"{label}/{path.name}"] = {
                    "key": f"{label}/{path.name}",
                    "absolute_path": str(path),
                    "error": str(exc),
                }
    return {"captured_at": _now_iso(), "directories": dir_rows, "files": files}


def _active() -> dict[str, Any]:
    if not ACTIVE_FILE.is_file():
        return {}
    data = _read_json(ACTIVE_FILE)
    session_dir = Path(str(data.get("session_dir", ""))) if data.get("session_dir") else None
    if not session_dir or not session_dir.is_dir():
        return {}
    return data


def is_active() -> bool:
    return bool(_active())


def active_session_dir() -> Path | None:
    data = _active()
    return Path(data["session_dir"]) if data else None




def _allocate_probe_variant() -> tuple[int, str]:
    # v1.5.10 diagnostic build: force candidate #5 FULL_A_HIGH999 on every launch.
    selected = 4
    _write_json(PROBE_STATE_FILE, {
        "build": PROBE_BUILD,
        "current_index": selected,
        "current_name": PROBE_VARIANTS[selected],
        "next_index": selected,
        "updated_at": _now_iso(),
    })
    return selected, PROBE_VARIANTS[selected]

def active_probe_variant_index() -> int:
    active = _active()
    if active:
        try:
            return int(active.get("probe_variant_index", 1) or 1)
        except Exception:
            pass
    state = _read_json(PROBE_STATE_FILE)
    try:
        return int(state.get("current_index", 1) or 1)
    except Exception:
        return 1


def active_probe_variant_name() -> str:
    index = active_probe_variant_index()
    if 0 <= index < len(PROBE_VARIANTS):
        return PROBE_VARIANTS[index]
    return PROBE_VARIANTS[1]

def begin_capture() -> dict[str, Any]:
    with _LOCK:
        CAPTURE_ROOT.mkdir(parents=True, exist_ok=True)
        previous = _active()
        if previous:
            # Do not silently destroy evidence from a forgotten previous run.
            try:
                finish_capture(note="Automatically closed because a new capture was started.")
            except Exception:
                pass

        # Allocate ONE manifest candidate before FIFA starts. FIFA caches the
        # roster manifest early in the boot sequence, so changing candidates
        # after the game is already open cannot test the comparison logic.
        probe_index, probe_name = _allocate_probe_variant()

        session_id = _now_id()
        session_dir = CAPTURE_ROOT / session_id
        (session_dir / "requests").mkdir(parents=True, exist_ok=True)
        (session_dir / "responses").mkdir(parents=True, exist_ok=True)
        (session_dir / "changed-files").mkdir(parents=True, exist_ok=True)

        before = _snapshot_settings()
        _write_json(session_dir / "settings-before.json", before)
        data = {
            "schema": 1,
            "session_id": session_id,
            "session_dir": str(session_dir),
            "started_at": _now_iso(),
            "status": "ACTIVE",
            "request_count": 0,
            "probe_variant_index": probe_index,
            "probe_variant_number": probe_index + 1,
            "probe_variant_name": probe_name,
            "probe_build": PROBE_BUILD,
        }
        _write_json(session_dir / "capture.json", data)
        _write_json(ACTIVE_FILE, data)
        return data


def _sanitize_headers(headers: Mapping[str, Any] | None) -> dict[str, str]:
    out: dict[str, str] = {}
    if not headers:
        return out
    try:
        items = headers.items()
    except Exception:
        items = []
    for key, value in items:
        name = str(key)
        text = str(value)
        if name.lower() in _SENSITIVE_HEADER_NAMES:
            text = "<redacted>"
        out[name] = text
    return out


def record_request(method: str, raw_path: str, headers: Mapping[str, Any] | None = None, body: bytes | bytearray | None = None) -> str | None:
    with _LOCK:
        active = _active()
        if not active:
            return None
        session_dir = Path(active["session_dir"])
        capture_file = session_dir / "capture.json"
        capture = _read_json(capture_file)
        seq = int(capture.get("request_count", 0) or 0) + 1
        capture["request_count"] = seq
        capture["last_request_at"] = _now_iso()
        _write_json(capture_file, capture)
        _write_json(ACTIVE_FILE, capture)

        request_id = f"{seq:04d}-{_now_id()}"
        payload = bytes(body or b"")
        parsed = urlsplit(str(raw_path or ""))
        body_name = None
        if payload:
            body_name = f"{request_id}.bin"
            (session_dir / "requests" / body_name).write_bytes(payload)

        row = {
            "request_id": request_id,
            "captured_at": _now_iso(),
            "method": str(method or "").upper(),
            "raw_path": str(raw_path or ""),
            "path": parsed.path,
            "query": parse_qs(parsed.query, keep_blank_values=True),
            "headers": _sanitize_headers(headers),
            "body_size": len(payload),
            "body_sha256": _sha256_bytes(payload) if payload else None,
            "body_file": body_name,
        }
        _write_json(session_dir / "requests" / f"{request_id}.json", row)
        with (session_dir / "trace.ndjson").open("a", encoding="utf-8") as f:
            f.write(json.dumps({"type": "request", **row}, ensure_ascii=False) + "\n")
        return request_id


def record_response(request_id: str | None, status: int, headers: Mapping[str, Any] | None, body: bytes | bytearray | None) -> None:
    if not request_id:
        return
    with _LOCK:
        active = _active()
        if not active:
            return
        session_dir = Path(active["session_dir"])
        payload = bytes(body or b"")
        body_name = f"{request_id}.bin"
        if payload:
            (session_dir / "responses" / body_name).write_bytes(payload)
        row = {
            "request_id": request_id,
            "captured_at": _now_iso(),
            "status": int(status),
            "headers": _sanitize_headers(headers),
            "body_size": len(payload),
            "body_sha256": _sha256_bytes(payload) if payload else None,
            "body_file": body_name if payload else None,
        }
        _write_json(session_dir / "responses" / f"{request_id}.json", row)
        with (session_dir / "trace.ndjson").open("a", encoding="utf-8") as f:
            f.write(json.dumps({"type": "response", **row}, ensure_ascii=False) + "\n")


def _diff_snapshots(before: dict[str, Any], after: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    old = before.get("files", {}) if isinstance(before.get("files"), dict) else {}
    new = after.get("files", {}) if isinstance(after.get("files"), dict) else {}
    added: list[dict[str, Any]] = []
    changed: list[dict[str, Any]] = []
    removed: list[dict[str, Any]] = []

    for key, row in new.items():
        if key not in old:
            added.append(row)
            continue
        old_row = old[key]
        if row.get("sha256") != old_row.get("sha256") or row.get("size") != old_row.get("size"):
            changed.append({"before": old_row, "after": row})
    for key, row in old.items():
        if key not in new:
            removed.append(row)
    return {"added": added, "changed": changed, "removed": removed}


def _copy_changed_files(session_dir: Path, diff: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    copied: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = list(diff.get("added", []))
    candidates += [row.get("after", {}) for row in diff.get("changed", [])]
    for row in candidates:
        source = Path(str(row.get("absolute_path", "")))
        if not source.is_file():
            continue
        rel = Path(str(row.get("relative_path", source.name)))
        label = str(row.get("label", "settings"))
        dest = session_dir / "changed-files" / label / rel
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
            copied.append({"source": str(source), "copy": str(dest.relative_to(session_dir)), "sha256": _sha256(dest)})
        except Exception as exc:
            copied.append({"source": str(source), "error": str(exc)})
    return copied


def _request_summary(session_dir: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted((session_dir / "requests").glob("*.json")):
        row = _read_json(path)
        if row:
            rows.append(row)
    return rows


def _response_map(session_dir: Path) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in sorted((session_dir / "responses").glob("*.json")):
        row = _read_json(path)
        request_id = str(row.get("request_id", ""))
        if request_id:
            rows[request_id] = row
    return rows


def _collect_runtime_diagnostics(session_dir: Path) -> None:
    diag = session_dir / "diagnostics"
    diag.mkdir(parents=True, exist_ok=True)
    runtime = ROOT / "runtime"
    for name in (
        "server.log", "server.error.log", "launcher-status.json",
        "launcher-processes.json", "redirector.log", "redirector.error.log",
        "control.log", "control.error.log", "status.json",
        "trust-patch.log", "offline-data.log",
    ):
        src = runtime / name
        if src.is_file():
            try:
                shutil.copy2(src, diag / name)
            except Exception:
                pass
    info = {
        "captured_at": _now_iso(),
        "build": "1.5.9-roster-boot-matrix",
        "root": str(ROOT),
        "localappdata": os.environ.get("LOCALAPPDATA", ""),
    }
    try:
        cp = subprocess.run(["netstat", "-ano"], capture_output=True, timeout=8)
        raw = cp.stdout or cp.stderr or b""
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", errors="replace")
        (diag / "netstat.txt").write_text(str(raw), encoding="utf-8", errors="replace")
    except Exception as exc:
        info["netstat_error"] = str(exc)

    # If FIFA terminated unexpectedly, keep recent Windows Application Error /
    # WER entries in the capture so the next report can distinguish a launcher
    # problem from an actual FIFA20.exe crash. This is best-effort only.
    try:
        ps = (
            "$since=(Get-Date).AddMinutes(-15); "
            "Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$since} -ErrorAction SilentlyContinue | "
            "Where-Object { $_.ProviderName -in @('Application Error','Windows Error Reporting') -and $_.Message -match 'FIFA20\\.exe' } | "
            "Select-Object -First 20 TimeCreated,ProviderName,Id,LevelDisplayName,Message | Format-List"
        )
        cp = subprocess.run(["powershell.exe", "-NoProfile", "-Command", ps], capture_output=True, timeout=12)
        raw = cp.stdout or cp.stderr or b""
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", errors="replace")
        (diag / "fifa-crash-events.txt").write_text(str(raw), encoding="utf-8", errors="replace")
    except Exception as exc:
        info["crash_event_error"] = str(exc)

    _write_json(diag / "build.json", info)

def _write_report(session_dir: Path, capture: dict[str, Any], diff: dict[str, list[dict[str, Any]]], copied: list[dict[str, Any]], note: str = "") -> Path:
    requests = _request_summary(session_dir)
    roster_requests = [r for r in requests if str(r.get("path", "")).lower() == "/roster"]
    roster_manifest_requests = [r for r in requests if str(r.get("path", "")).lower().endswith("/rosterupdate.xml")]
    roster_bin_requests = [r for r in requests if "/squads/" in str(r.get("path", "")).lower() and not str(r.get("path", "")).lower().endswith("rosterupdate.xml")]
    responses = _response_map(session_dir)
    easw_requests = [r for r in requests if str(r.get("path", "")).lower().startswith("/easw/")]
    lines = [
        "MNG FUT 20 - FIFA 20 TEAM UPDATE / ROSTER CAPTURE",
        "=" * 64,
        f"Session: {capture.get('session_id', session_dir.name)}",
        f"Started: {capture.get('started_at', '')}",
        f"Finished: {capture.get('finished_at', '')}",
        f"Requests captured: {len(requests)}",
        f"/roster legacy requests: {len(roster_requests)}",
        f"rosterupdate.xml requests: {len(roster_manifest_requests)}",
        f"roster .bin requests: {len(roster_bin_requests)}",
        f"/easw/* requests: {len(easw_requests)}",
        f"Settings files added: {len(diff.get('added', []))}",
        f"Settings files changed: {len(diff.get('changed', []))}",
        f"Settings files removed: {len(diff.get('removed', []))}",
        f"Changed/new files copied: {len([x for x in copied if 'copy' in x])}",
        "",
    ]
    if note:
        lines += [f"Note: {note}", ""]
    lines += [
        "REQUESTS",
        "-" * 64,
    ]
    if requests:
        for row in requests:
            response = responses.get(str(row.get("request_id", "")), {})
            headers = response.get("headers", {}) if isinstance(response.get("headers"), dict) else {}
            variant = headers.get("X-MNG-Probe-Variant", "")
            suffix = f" variant={variant}" if variant else ""
            lines.append(f"{row.get('method', '')} {row.get('raw_path', '')} body={row.get('body_size', 0)} sha256={row.get('body_sha256') or '-'}{suffix}")
    else:
        lines.append("No EASW request was captured. Start Local FUT, start capture, then use FIFA 20's team update option.")
    lines += ["", "SETTINGS CHANGES", "-" * 64]
    for row in diff.get("added", []):
        lines.append(f"ADDED   {row.get('relative_path', row.get('absolute_path', ''))} size={row.get('size', 0)} sha256={row.get('sha256', '-')}")
    for row in diff.get("changed", []):
        after = row.get("after", {})
        before = row.get("before", {})
        lines.append(f"CHANGED {after.get('relative_path', after.get('absolute_path', ''))} size={before.get('size', 0)}->{after.get('size', 0)} sha256={after.get('sha256', '-')}")
    for row in diff.get("removed", []):
        lines.append(f"REMOVED {row.get('relative_path', row.get('absolute_path', ''))}")
    if not any(diff.values()):
        lines.append("No file change detected in FIFA 20 settings directories.")
    lines += [
        "",
        "PRIVACY",
        "-" * 64,
        "Authorization, Cookie, EASW-Token and EASW-Session values are redacted automatically.",
        "Binary request bodies and changed squad/settings files are kept for protocol analysis.",
        "",
        "NEXT STEP",
        "-" * 64,
        "For v1.5.9, the manifest candidate is fixed BEFORE FIFA starts. Use Team Update once, finish the capture, then close FIFA and click PLAY again to test the next candidate.",
    ]
    report = session_dir / "report.txt"
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report


def finish_capture(note: str = "") -> dict[str, Any]:
    with _LOCK:
        active = _active()
        if not active:
            return {"ok": False, "error": "No active roster capture."}
        session_dir = Path(active["session_dir"])
        before = _read_json(session_dir / "settings-before.json")
        after = _snapshot_settings()
        _write_json(session_dir / "settings-after.json", after)
        diff = _diff_snapshots(before, after)
        _write_json(session_dir / "settings-diff.json", diff)
        copied = _copy_changed_files(session_dir, diff)
        _write_json(session_dir / "copied-files.json", copied)
        capture = _read_json(session_dir / "capture.json") or dict(active)
        capture["status"] = "FINISHED"
        capture["finished_at"] = _now_iso()
        capture["settings_added"] = len(diff["added"])
        capture["settings_changed"] = len(diff["changed"])
        capture["settings_removed"] = len(diff["removed"])
        if note:
            capture["note"] = note
        _write_json(session_dir / "capture.json", capture)
        _collect_runtime_diagnostics(session_dir)
        report = _write_report(session_dir, capture, diff, copied, note=note)
        zip_path: Path | None = CAPTURE_ROOT / f"{session_dir.name}.zip"
        try:
            if zip_path.exists():
                zip_path.unlink()
            shutil.make_archive(str(zip_path.with_suffix("")), "zip", root_dir=session_dir)
        except Exception:
            zip_path = None
        try:
            ACTIVE_FILE.unlink()
        except FileNotFoundError:
            pass
        return {
            "ok": True,
            "session_dir": str(session_dir),
            "report": str(report),
            "zip_path": str(zip_path) if zip_path else "",
            "capture": capture,
            "diff": diff,
        }


def open_capture_root() -> Path:
    CAPTURE_ROOT.mkdir(parents=True, exist_ok=True)
    return CAPTURE_ROOT
