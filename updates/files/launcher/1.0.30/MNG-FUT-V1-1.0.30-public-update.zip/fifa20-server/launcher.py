from __future__ import annotations
import json
import os
import sqlite3
import subprocess
import urllib.request
import urllib.error
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

import roster_capture

ROOT = Path(__file__).resolve().parent
SETTINGS = ROOT / "launcher-settings.json"
SAVE_DIR = Path(os.environ.get("LOCALAPPDATA", str(ROOT))) / "FUT20LocalFUT"
PROFILE = SAVE_DIR / "profile.json"
PROFILE_KEYS = ("display_name", "club_name", "club_abbr", "fifa_exe")


def _read_json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _abbr(value: str) -> str:
    return "".join(ch for ch in str(value).upper() if "A" <= ch <= "Z")[:3]


class MngFut20(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("MNG FUT 20")
        self.geometry("780x590")
        self.minsize(780, 590)
        self.configure(bg="#0d1117")
        self.data = _read_json(SETTINGS)
        saved = _read_json(PROFILE)
        for key in PROFILE_KEYS:
            if key in saved:
                self.data[key] = saved[key]
        self.status = tk.StringVar(value="READY")
        self.display = tk.StringVar(value=str(self.data.get("display_name", "Player")))
        self.club = tk.StringVar(value=str(self.data.get("club_name", "My FUT Club")))
        self.abbr = tk.StringVar(value=_abbr(str(self.data.get("club_abbr", "FUT"))) or "FUT")
        self.game = tk.StringVar(value=str(self.data.get("fifa_exe", "")))
        self._abbr_guard = False
        self.abbr.trace_add("write", self._normalize_abbr)
        self._build()

    def _normalize_abbr(self, *_args):
        if self._abbr_guard:
            return
        value = _abbr(self.abbr.get())
        if value != self.abbr.get():
            self._abbr_guard = True
            self.abbr.set(value)
            self._abbr_guard = False

    def _build(self):
        left = tk.Frame(self, bg="#111827", width=260)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        tk.Label(left, text="KYRO", font=("Segoe UI Semibold", 34), fg="#f8fafc", bg="#111827").pack(anchor="w", padx=28, pady=(42, 0))
        tk.Label(left, text="20", font=("Segoe UI Black", 46), fg="#22d3ee", bg="#111827").pack(anchor="w", padx=28)
        tk.Label(left, text="LOCAL ULTIMATE TEAM", font=("Segoe UI Semibold", 10), fg="#94a3b8", bg="#111827").pack(anchor="w", padx=30, pady=(4, 26))
        tk.Frame(left, bg="#22d3ee", height=2, width=58).pack(anchor="w", padx=30)
        tk.Label(left, text="FIFA 20\nMNG FUT 20 LOCAL FUT", justify="left", font=("Segoe UI", 11), fg="#cbd5e1", bg="#111827").pack(anchor="w", padx=30, pady=24)
        tk.Label(left, textvariable=self.status, wraplength=195, justify="left", font=("Consolas", 9), fg="#67e8f9", bg="#111827").pack(side="bottom", anchor="w", padx=30, pady=28)
        body = tk.Frame(self, bg="#0d1117")
        body.pack(side="right", fill="both", expand=True, padx=38, pady=34)
        tk.Label(body, text="LOCAL FUT PROFILE", font=("Segoe UI Semibold", 18), fg="#f8fafc", bg="#0d1117").pack(anchor="w", pady=(2, 22))
        self._field(body, "Display name", self.display)
        self._field(body, "Club name", self.club)
        self._field(body, "Club abbreviation (3 letters)", self.abbr)
        game_row = tk.Frame(body, bg="#0d1117")
        game_row.pack(fill="x", pady=(0, 15))
        tk.Label(game_row, text="FIFA20.exe", font=("Segoe UI", 9), fg="#94a3b8", bg="#0d1117").pack(anchor="w")
        line = tk.Frame(game_row, bg="#0d1117")
        line.pack(fill="x", pady=(5, 0))
        tk.Entry(line, textvariable=self.game, font=("Segoe UI", 10), bg="#161b22", fg="#e5e7eb", insertbackground="#e5e7eb", relief="flat").pack(side="left", fill="x", expand=True, ipady=9)
        tk.Button(line, text="BROWSE", command=self.browse, font=("Segoe UI Semibold", 9), bg="#1f2937", fg="#e5e7eb", activebackground="#334155", activeforeground="#ffffff", relief="flat", padx=14, pady=8).pack(side="right", padx=(8, 0))
        controls = tk.Frame(body, bg="#0d1117")
        controls.pack(fill="x", pady=(18, 0))
        tk.Button(controls, text="START LOCAL FUT", command=self.start_local, font=("Segoe UI Semibold", 11), bg="#22d3ee", fg="#071018", activebackground="#67e8f9", activeforeground="#071018", relief="flat", padx=22, pady=12).pack(side="left")
        tk.Button(controls, text="STOP", command=self.stop_local, font=("Segoe UI Semibold", 10), bg="#1f2937", fg="#e5e7eb", activebackground="#334155", activeforeground="#ffffff", relief="flat", padx=20, pady=12).pack(side="left", padx=9)
        tk.Button(controls, text="SAVE PROFILE", command=self.save_profile, font=("Segoe UI Semibold", 10), bg="#1f2937", fg="#e5e7eb", activebackground="#334155", activeforeground="#ffffff", relief="flat", padx=18, pady=12).pack(side="left")

        capture = tk.Frame(body, bg="#0d1117")
        capture.pack(fill="x", pady=(14, 0))
        tk.Button(capture, text="ROSTER TEST INFO", command=self.start_roster_capture, font=("Segoe UI Semibold", 9), bg="#0f766e", fg="#ecfeff", activebackground="#0d9488", activeforeground="#ffffff", relief="flat", padx=14, pady=10).pack(side="left")
        tk.Button(capture, text="FINISH CAPTURE", command=self.finish_roster_capture, font=("Segoe UI Semibold", 9), bg="#1f2937", fg="#e5e7eb", activebackground="#334155", activeforeground="#ffffff", relief="flat", padx=14, pady=10).pack(side="left", padx=8)
        tk.Button(capture, text="CAPTURES", command=self.open_captures, font=("Segoe UI", 9), bg="#0d1117", fg="#94a3b8", activebackground="#0d1117", activeforeground="#e5e7eb", relief="flat", padx=8, pady=10).pack(side="left")

        tk.Label(body, text="Roster test: capture starts automatically BEFORE FIFA when you click PLAY. Use Team Update once, then FINISH CAPTURE.", font=("Segoe UI", 8), fg="#64748b", bg="#0d1117").pack(anchor="w", pady=(5, 0))

        footer = tk.Frame(body, bg="#0d1117")
        footer.pack(fill="x", side="bottom")
        tk.Button(footer, text="OPEN SAVE FOLDER", command=self.open_save, font=("Segoe UI", 9), bg="#0d1117", fg="#94a3b8", activebackground="#0d1117", activeforeground="#e5e7eb", relief="flat").pack(side="left")
        tk.Label(footer, text="Profile, executable path and club data persist locally.", font=("Segoe UI", 9), fg="#64748b", bg="#0d1117").pack(side="right")

    def _field(self, parent, label, var):
        box = tk.Frame(parent, bg="#0d1117")
        box.pack(fill="x", pady=(0, 15))
        tk.Label(box, text=label, font=("Segoe UI", 9), fg="#94a3b8", bg="#0d1117").pack(anchor="w")
        tk.Entry(box, textvariable=var, font=("Segoe UI", 11), bg="#161b22", fg="#e5e7eb", insertbackground="#e5e7eb", relief="flat").pack(fill="x", pady=(5, 0), ipady=9)

    def browse(self):
        path = filedialog.askopenfilename(title="Select FIFA20.exe", filetypes=[("FIFA 20", "FIFA20.exe"), ("Executable", "*.exe")])
        if path:
            self.game.set(path)
            self.save_profile(False)

    def save_profile(self, notify=True):
        club = self.club.get().strip() or "My FUT Club"
        abbr = _abbr(self.abbr.get()) or "FUT"
        display = self.display.get().strip() or "Player"
        game = self.game.get().strip()
        self.club.set(club)
        self.abbr.set(abbr)
        self.display.set(display)
        self.data["display_name"] = display
        self.data["club_name"] = club
        self.data["club_abbr"] = abbr
        self.data["squad_name"] = "Active Squad" if str(self.data.get("squad_name", "")).lower() in {"kyro xi", "local xi", ""} else self.data["squad_name"]
        self.data["fifa_exe"] = game
        SAVE_DIR.mkdir(parents=True, exist_ok=True)
        self.data["database_path"] = str(SAVE_DIR / "localfut20.sqlite3")
        SETTINGS.write_text(json.dumps(self.data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        PROFILE.write_text(json.dumps({key: self.data.get(key, "") for key in PROFILE_KEYS}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        db = Path(self.data["database_path"])
        if db.exists():
            try:
                con = sqlite3.connect(db)
                for key, value in (("club_name", club), ("club_abbr", abbr)):
                    con.execute("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, json.dumps(value)))
                row = con.execute("SELECT value FROM kv WHERE key='squad_name'").fetchone()
                if row:
                    try:
                        current = json.loads(row[0])
                    except Exception:
                        current = ""
                    if str(current).lower() in {"kyro xi", "local xi", ""}:
                        con.execute("UPDATE kv SET value=? WHERE key='squad_name'", (json.dumps("Active Squad"),))
                con.commit()
                con.close()
            except Exception:
                pass
        self.status.set(f"PROFILE SAVED\n{club} [{abbr}]")
        if notify:
            messagebox.showinfo("MNG FUT 20", "Profile saved.")

    def start_local(self):
        self.save_profile(False)
        self.status.set("STARTING LOCAL FUT...")
        try:
            capture = roster_capture.begin_capture()
            variant_no = int(capture.get("probe_variant_number", 0) or 0)
            variant_name = str(capture.get("probe_variant_name", ""))
            subprocess.Popen(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ROOT / "Launch.ps1")], cwd=ROOT)
            self.status.set(f"LAUNCH STARTED\nRoster test {variant_no}/6: {variant_name}")
        except Exception as exc:
            self.status.set("START FAILED")
            messagebox.showerror("MNG FUT 20", str(exc))

    def stop_local(self):
        try:
            subprocess.Popen(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ROOT / "Stop.ps1")], cwd=ROOT)
            self.status.set("STOP REQUESTED")
        except Exception as exc:
            messagebox.showerror("MNG FUT 20", str(exc))

    def start_roster_capture(self):
        active = roster_capture._active()
        if active:
            number = int(active.get("probe_variant_number", 0) or 0)
            name = str(active.get("probe_variant_name", ""))
            messagebox.showinfo(
                "MNG FUT 20 - Team Update Capture",
                f"Capture is already active from PLAY.\n\nRoster test: {number}/6 {name}\n\nGo to FIFA 20, use Team Update ONCE, wait for the result, then click FINISH CAPTURE.",
            )
            return
        messagebox.showwarning(
            "MNG FUT 20 - Team Update Capture",
            "FIFA 20 caches the roster manifest during startup.\n\nClose FIFA 20 if it is open, then click PLAY. The capture will start automatically BEFORE FIFA launches.\n\nAfter FIFA opens, use Team Update once and click FINISH CAPTURE.",
        )

    def finish_roster_capture(self):
        try:
            result = roster_capture.finish_capture()
            if not result.get("ok"):
                messagebox.showwarning("MNG FUT 20", str(result.get("error", "No active capture.")))
                return
            session_dir = str(result.get("session_dir", ""))
            zip_path = str(result.get("zip_path", ""))
            capture = result.get("capture", {}) or {}
            self.status.set(
                "CAPTURE FINISHED\nRequests={0} | Files changed={1}".format(
                    int(capture.get("request_count", 0) or 0),
                    int(capture.get("settings_added", 0) or 0) + int(capture.get("settings_changed", 0) or 0),
                )
            )
            messagebox.showinfo(
                "MNG FUT 20 - Capture complete",
                "Capture complete.\n\nFolder:\n" + session_dir + "\n\nZIP ready to send:\n" + (zip_path or "(ZIP creation failed; send the folder)") + "\n\nSend the ZIP back for analysis.",
            )
            if session_dir and Path(session_dir).is_dir():
                os.startfile(session_dir)
        except Exception as exc:
            self.status.set("CAPTURE FINISH FAILED")
            messagebox.showerror("MNG FUT 20", str(exc))

    def open_captures(self):
        try:
            os.startfile(roster_capture.open_capture_root())
        except Exception as exc:
            messagebox.showerror("MNG FUT 20", str(exc))

    def open_save(self):
        SAVE_DIR.mkdir(parents=True, exist_ok=True)
        os.startfile(SAVE_DIR)


def main():
    MngFut20().mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
