from __future__ import annotations

import base64
import importlib.abc
import importlib.util
import json
import marshal
import sys
import types
import zlib
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT = Path(__file__).resolve().parent
PAYLOAD = ROOT / "runtime" / "secure_payload.f20"

A = (93,83,63,32,147,238,98,141,219,191,159,246,7,174,26,169,54,11,13,207,141,186,163,75,13,253,49,242,55,150,58,221)
B = (153,232,211,233,232,93,238,36,212,244,8,76,153,49,4,139,185,89,204,59,177,195,187,136,228,24,86,55,4,222,1,215)
C = (126,215,12,204,34,161,178,99,63,230,87,222,191,106,0,10,8,101,70,155,44,138,25,141,112,221,152,225,222,25,119,171)

ALIASES = {
    "auth_guard": "localfut20.auth_guard",
    "config_loader": "localfut20.config_loader",
    "sbc_catalog": "localfut20.sbc_catalog",
}
ENTRY_ALIASES = {
    "offline_data": "localfut20.offline_data",
    "control_server": "localfut20.control_server",
    "server": "localfut20.server",
}


def _key() -> bytes:
    return bytes(x ^ y ^ z for x, y, z in zip(A, B, C))


def _load_entries() -> dict[str, dict]:
    raw = PAYLOAD.read_bytes()
    if raw[:8] != b"F20P1\x00\x00\x00":
        raise SystemExit("MNG FUT 20 runtime payload is invalid.")
    clear = AESGCM(_key()).decrypt(
        raw[8:20], raw[20:], b"FUT20-PRIVATE-PAYLOAD-v1"
    )
    return json.loads(zlib.decompress(clear).decode("utf-8"))["entries"]


ENTRIES = _load_entries()


def _code(name: str):
    return marshal.loads(base64.b64decode(ENTRIES[name]["code"]))


class _Loader(importlib.abc.Loader):
    def __init__(self, full: str, target: str):
        self.full = full
        self.target = target

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        meta = ENTRIES[self.target]
        module.__file__ = str(ROOT / meta["file"])
        module.__package__ = self.full.rpartition(".")[0]
        module.__loader__ = self
        exec(_code(self.target), module.__dict__, module.__dict__)


class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        mapped = ALIASES.get(fullname, fullname)
        if mapped in ENTRIES and mapped not in {
            "launcher",
            "legacy_launcher",
            "launcher_pre_save",
            "redirector_tls",
            "trust_patch",
            "localfut20.server",
        }:
            return importlib.util.spec_from_loader(
                fullname,
                _Loader(fullname, mapped),
                origin=str(ROOT / ENTRIES[mapped]["file"]),
            )
        return None


for p in (ROOT, ROOT / "localfut20", ROOT / "runtime-source"):
    s = str(p)
    if s not in sys.path:
        sys.path.insert(0, s)

sys.meta_path.insert(0, _Finder())


def run(name: str, args: list[str]) -> None:
    name = ENTRY_ALIASES.get(name, name)

    # Some native FIFA/LSX helper output contains bytes that are undefined in
    # Windows cp1252. The encrypted trust_patch component uses text-mode
    # subprocess pipes, so make those pipes replacement-safe instead of letting
    # Python's reader thread raise UnicodeDecodeError.
    if name == "trust_patch":
        import subprocess as _subprocess
        _OriginalPopen = _subprocess.Popen

        class _ReplacementSafePopen(_OriginalPopen):
            def __init__(self, *popen_args, **popen_kwargs):
                wants_text = bool(popen_kwargs.get("text") or popen_kwargs.get("universal_newlines") or popen_kwargs.get("encoding"))
                if wants_text and popen_kwargs.get("errors") is None:
                    popen_kwargs["errors"] = "replace"
                super().__init__(*popen_args, **popen_kwargs)

        _subprocess.Popen = _ReplacementSafePopen
    if name not in ENTRIES:
        raise SystemExit(f"Unknown MNG FUT 20 component: {name}")

    meta = ENTRIES[name]
    old_argv = sys.argv[:]
    sys.argv = [str(ROOT / meta["file"])] + list(args)
    try:
        if name == "localfut20.server":
            module = types.ModuleType(name)
            module.__file__ = str(ROOT / meta["file"])
            module.__package__ = "localfut20"
            module.__loader__ = None
            sys.modules[name] = module
            exec(_code(name), module.__dict__, module.__dict__)
            from prime_filter import apply as apply_prime_filter
            apply_prime_filter(module)
            raise SystemExit(int(module.main()))

        ns = {
            "__name__": "__main__",
            "__file__": str(ROOT / meta["file"]),
            "__package__": None,
            "__cached__": None,
            "__loader__": None,
            "__builtins__": __builtins__,
        }
        exec(_code(name), ns, ns)
    finally:
        sys.argv = old_argv


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("Usage: py -3.13 runtime_runner.py <component> [args]")
    run(sys.argv[1], sys.argv[2:])
