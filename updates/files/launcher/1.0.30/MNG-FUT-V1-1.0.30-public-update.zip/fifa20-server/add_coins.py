from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path

AMOUNT = 10_000_000


def save_dir() -> Path:
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        raise RuntimeError("LOCALAPPDATA is not available for this Windows user.")
    return Path(local) / "FUT20LocalFUT"


def main() -> int:
    db = save_dir() / "localfut20.sqlite3"
    if not db.is_file():
        print("MNG FUT 20 save database was not found.")
        print("Launch Local FUT once to create your club, close FIFA 20, then run this again.")
        return 1

    with sqlite3.connect(db, timeout=10) as con:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("SELECT value FROM kv WHERE key='credits'").fetchone()
        if row is None:
            current = 0
        else:
            try:
                current = int(json.loads(row[0]))
            except (TypeError, ValueError, json.JSONDecodeError):
                current = int(row[0])
        updated = current + AMOUNT
        con.execute(
            "INSERT INTO kv(key,value) VALUES('credits',?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(updated),),
        )
        con.commit()

    print(f"Coins before : {current:,}")
    print(f"Coins added  : {AMOUNT:,}")
    print(f"New balance  : {updated:,}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
