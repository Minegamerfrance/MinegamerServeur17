@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title FIFA 15 Local FUT - Verification

set "PY="
where py.exe >nul 2>nul && set "PY=py -3"
if not defined PY where python.exe >nul 2>nul && set "PY=python"
if not defined PY (
  echo ERREUR: Python 3 est introuvable.
  exit /b 1
)

echo Verification de la structure FIFA 15 Local FUT...
for %%F in (
  "payload\localfut15\server.py"
  "payload\localfut15\admin_menu.py"
  "payload\localfut15\config.json"
  "payload\localfut15\players.json"
  "payload\localfut15\pack_settings.json"
  "payload\PLAY_LOCAL_FUT15.cmd"
  "payload\START_LOCAL_FUT15.cmd"
  "payload\STOP_LOCAL_FUT15.cmd"
) do if not exist "%%~F" (
  echo MANQUANT: %%~F
  exit /b 2
)

%PY% -c "import ast,json,pathlib; r=pathlib.Path(r'payload/localfut15'); [ast.parse((r/n).read_text(encoding='utf-8-sig'), filename=n) for n in ('server.py','admin_menu.py','add_coins.py')]; [json.loads((r/n).read_text(encoding='utf-8-sig')) for n in ('config.json','players.json','pack_settings.json','club_identity_catalog.json','consumable_catalog.json','totw.json')]; print('Python et JSON : OK')"
if errorlevel 1 exit /b 3

echo Structure et fichiers principaux : OK
echo Serveur actif : payload\localfut15\server.py
exit /b 0
