# FIFA 15 Local FUT — Public Test 1

Local/offline FIFA 15 Ultimate Team restoration test build for PC, based on the working v0.2.39 backend.

## Quick start

1. Extract the ZIP to a normal folder (for example, Downloads).
2. Run **`INSTALL_PREREQUISITES.cmd`** once. It checks/installs Python, the required Python package, and the Visual C++ runtime used by the FIFA 15 Cards DLL.
3. Run **`PLAY_LOCAL_FUT15.cmd`**. On first run it finds your FIFA 15 installation, backs up files it replaces, installs the Local FUT payload, creates a desktop shortcut, starts the localhost services, and launches FIFA 15.
4. Future launches can use the **FIFA 15 Local FUT** desktop shortcut.

This requires your own installed copy of FIFA 15 PC. The project is intended for local/offline restoration testing; it does not connect you to EA's retired FUT service.

## Fresh starter club

A brand-new Local FUT save starts intentionally small:

- **0 coins** by default.
- **14 bronze Premier League players** only (including a usable mix of GK/DEF/MID/ST positions).
- One active **Arsenal badge**.
- **Arsenal home + away kits**.
- One starter **stadium** (Sanderson Park).
- One starter **ball** so matches have a complete club identity.
- One starter squad, with additional squads supported.

FUT will still let the player choose/confirm their own club name. Club progress, coins, squads, items and Transfer List state are persisted in:

`%LOCALAPPDATA%\FIFA15LocalFUT\fut15-local.sqlite3`

If you previously used a development build and want to test the exact fresh-public state, run **`RESET_TO_STARTER_CLUB.cmd`**. It only deletes the Local FUT database; it does not delete normal Career/Settings saves.

The modern Admin Panel also provides **Tools → Delete club and start fresh**. It creates a dated SQLite backup, closes FIFA, stops only the Local FUT server process, deletes the Local FUT club save and then confirms when it is safe to relaunch. Career Mode and normal FIFA settings are not touched.

## Daily reward packs

The Admin Panel Overview includes a **Daily reward** card while the Local FUT server is running. One reward can be claimed per local calendar day. Consecutive claims advance through a seven-day pack ladder: Gold, Premium Gold, Rare Gold, Premium Gold Players, Mega, Rare Players, then Jumbo Rare Players. Reward cards use the normal pack generator and appear in Unassigned Items; existing Unassigned Items must be cleared before claiming.

## Open Transfer Market price range

User listings can use any valid start price and Buy Now price from **150 to 15,000,000 coins**, regardless of the card's suggested AI-market value. The local AI buyer still considers its internal valuation when deciding whether and how quickly to purchase an expensive listing.

The local market can also place a visible AI bid on an active listing. A bid is never below the card's stored market valuation and can be up to 8% higher, provided the user's starting price is not above the offer. Press **Y** on the Transfer List entry to view the received offer. Competitive Buy Now listings can still sell immediately; otherwise a winning AI bid settles when the auction expires and the normal 5% tax applies.

Transfer Targets are persisted in the local save. Adding a watched card, placing a bid, buying a card or submitting a card offer automatically adds that auction to Transfer Targets; removing it clears the saved target. Incoming AI offer details use FIFA 15's captured `{bid, itemData}` card-trade format.

## Optional test coins

Run **`ADD_COINS.cmd`** and enter how many local coins you want to add. The default is 1,000,000 coins. This modifies only the localhost FUT SQLite balance.

## Admin Centre edition

Run **`ADMIN_MENU.cmd`** to open the graphical Local FUT admin centre. It can:

- Set or add coins and FIFA Points on the active local save.
- Change the club name, abbreviation and manager name.
- Create, duplicate, enable, disable and delete store packs.
- Adjust pack prices, contents, rarity, tier weights, special-card odds and a guaranteed minimum player rating live.
- Configure the local AI Transfer Market and offline modes.
- Back up the Local FUT save, open logs and safely reset the club.

Balance and pack edits are read by the running server. Refresh the relevant FUT
screen after saving. Core server/market configuration changes apply on the next
launch. This edition also orders pack reveals by player OVR, highest first, with
rarity used as the tie-breaker.

## What is included

- Persistent local FUT club/profile.
- Store and pack opening, including promo packs.
- FIFA 15 player database and special-card pack pools.
- Club consumables.
- Badge/kit/stadium/ball support.
- Transfer List lifecycle, relisting, sold-item clearing and quick sell.
- Large deterministic local AI Transfer Market and local AI buyers for user listings.
- Multiple squads.
- Offline Seasons work from the current development line.
- Port auto-remapping for local FIFA services where possible.

This is a **test release**, so logs are intentionally verbose. They are stored under `%LOCALAPPDATA%\FIFA15LocalFUT\logs` and are useful when reporting bugs.

## Files new testers should care about

- `INSTALL_PREREQUISITES.cmd` — one-time dependency setup.
- `PLAY_LOCAL_FUT15.cmd` — main first-run installer/launcher.
- `ADD_COINS.cmd` — optional local coin helper.
- `RESET_TO_STARTER_CLUB.cmd` — optional destructive Local FUT reset.
- `RESTORE_BACKUP.cmd` — restores game files backed up by the Local FUT installer.

Everything inside `payload/` is installed automatically by the main launcher.

## Pelé active-link compatibility test

This build adds pack **43 – Pelé Active Legend Test**. It keeps Pelé's existing
player ID and database row, but changes his hidden Classic XI team link to an active
FUT-visible link. The pack then uses the encoded Legend resource ID so FIFA can pair
the Legend presentation with player ID `190043`. Older broken test packs are retired.

Version 46 completes Pelé's local identity data: full name, known-as name,
23/10/1940 birth date, 174 cm height, right foot, four-star weak foot,
five-star skills, Brazil, and the FIFA Legends club/league. It also includes a
local Pelé portrait fallback and repairs Pelé cards already owned from v44/v45.

Version 48 matches packed and owned Pelé cards to the subtype and wire format
used by the correctly rendered Transfer Market Pelé definition. Existing local
copies are normalized automatically when the club is loaded.

Version 49 adds persistent local Transfer Market bidding. AI auctions start at
roughly 25–55% of Buy Now, reserve only the submitted bid, count down in
Transfer Targets, and award the player to New Items when an uncontested auction
expires. Raising a bid charges only the difference; Buy Now credits an already
reserved bid toward the final price.

Version 50 orders every Transfer Market search by remaining auction time, with
the ending-soonest cards first. Player, position, quality and price filters are
still applied before ordering.

Version 51 gives local AI buyers a chance to compete for auctions you bid on.
An opponent has a hidden maximum, bids after a short delay, and refunds your
reserved coins immediately when it outbids you. You can rebid until you exceed
its ceiling; auctions with no interested opponent remain cheap bargains.

Version 52 delivers won auctions directly into My Club and removes completed
targets automatically. It also repairs cards already won under v49-v51 by
moving their hidden unassigned item into My Club on the next target refresh.
About 38% of live AI listings begin with one to three existing bids; the rest
remain no-bid opportunities that can still be won at their low opening price.

Version 53 integrates the exact Aurora Legends 1.4.3 archives verified in this
FIFA 15 installation: database, cards, startup metadata, localization, and 2D
player heads. The launcher backs up and the restore tool restores every archive
affected by the Legends installation.

## Legend market prices

Aurora Legend cards now use a dedicated premium market economy instead of the
generic special-card multiplier. Guide prices scale from about **350,000 coins
at 86 OVR** to **8,000,000 coins at 95 OVR**. Their live Buy Now prices vary
slightly around those guides, while opening bids are normally 55-78% of Buy
Now so it remains possible to win a no-bid Icon for less.

This revision also accepts FIFA 15's `usePreOrder=1` request for zero-points local
promo packs. Previously that request returned no items, causing the pack animation
to start and immediately close. Pack 43 is free while this compatibility test runs.

The launcher backs up the existing client files before installing the payload. Use
`RESTORE_BACKUP.cmd` if you want to return to the files that were present beforehand.

## About `ItsAMe_Origin.dll`

The filename is intentionally left unchanged. It is part of the compatibility chain used by this build and its exact filename is embedded in the binary, so renaming it just for presentation could break startup on clean machines.

## Bug reports

When reporting a problem, include:

- What screen/action you were on.
- What you expected to happen.
- What actually happened/crashed/froze.
- The newest log from `%LOCALAPPDATA%\FIFA15LocalFUT\logs`.

Please test on a legitimate FIFA 15 PC installation and keep reports focused on the localhost/offline restoration.
