from foundation_content import ARNAUTOVIC_ID
from foundation_objectives import group as reward_group, claim_group as claim_reward_group


CATEGORY_ID = 4
GROUP_ID = 5
OBJECTIVES = (
    (501, "Bienvenue à Shanghai", "Terminez 2 matchs Clash d'équipes avec au moins 1 joueur de Shanghai SIPG titulaire, difficulté Semi-pro minimum.", "arnautovic_club_matches", 2, 25),
    (502, "Les Aigles rouges", "Gagnez 3 matchs Clash d'équipes avec au moins 2 joueurs de Shanghai SIPG titulaires, difficulté Semi-pro minimum.", "arnautovic_club_wins", 3, 25),
    (503, "Découverte de la CSL", "Terminez 3 matchs Clash d'équipes avec au moins 3 joueurs de Chinese Super League titulaires, difficulté Semi-pro minimum.", "arnautovic_league_matches", 3, 25),
    (504, "Maîtrise du championnat", "Gagnez 4 matchs Clash d'équipes avec au moins 5 joueurs de Chinese Super League titulaires, difficulté Semi-pro minimum.", "arnautovic_league_wins", 4, 25),
    (505, "Fierté autrichienne", "Terminez 2 matchs Clash d'équipes avec au moins 1 joueur autrichien titulaire, difficulté Semi-pro minimum.", "arnautovic_nation_matches", 2, 25),
    (506, "Victoire de l'Autriche", "Gagnez 3 matchs Clash d'équipes avec au moins 2 joueurs autrichiens titulaires, difficulté Semi-pro minimum.", "arnautovic_nation_wins", 3, 25),
    (507, "À la pointe", "Terminez 3 matchs Clash d'équipes avec au moins 1 joueur de poste d'origine BU titulaire, difficulté Semi-pro minimum.", "arnautovic_position_matches", 3, 25),
    (508, "Duo de buteurs", "Gagnez 4 matchs Clash d'équipes avec au moins 2 joueurs de poste d'origine BU titulaires, difficulté Semi-pro minimum.", "arnautovic_position_wins", 4, 25),
)


def match_increments(context, reason):
    if reason not in {"WIN", "DRAW", "LOSS"} or context.get("mode") != "squad_battles" or int(context.get("difficulty", -1)) < 2:
        return {}
    starters = context.get("starters", [])
    counts = {
        "club": sum(player.get("teamid") == 112540 for player in starters),
        "league": sum(player.get("leagueId") == 2012 for player in starters),
        "nation": sum(player.get("nation") == 4 for player in starters),
        "position": sum(player.get("preferredPosition") == "ST" for player in starters),
    }
    result = {}
    for kind, minimum in (("club", 1), ("league", 3), ("nation", 1), ("position", 1)):
        if counts[kind] >= minimum:
            result[f"arnautovic_{kind}_matches"] = 1
        win_minimum = 5 if kind == "league" else 2
        if reason == "WIN" and counts[kind] >= win_minimum:
            result[f"arnautovic_{kind}_wins"] = 1
    return result


def group(season, progress):
    return reward_group(season, progress, OBJECTIVES, ARNAUTOVIC_ID, GROUP_ID, "arnautovicOtwClaimed",
                        "À surveiller — Arnautović",
                        "Terminez les huit défis liés à Shanghai SIPG, la Chinese Super League, l'Autriche et au poste de buteur pour gagner Arnautović OTW 82 BU invendable et 200 XP au total.", 1)


def claim_group(season):
    return claim_reward_group(season, OBJECTIVES, ARNAUTOVIC_ID, "arnautovicOtwClaimed")
