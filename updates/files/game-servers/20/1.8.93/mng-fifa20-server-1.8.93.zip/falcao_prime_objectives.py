from foundation_content import FALCAO_ID, FALCAO_PRIME_ID
from foundation_objectives import group as reward_group, claim_group as claim_reward_group, upgrade_status


GROUP_ID = 6
OBJECTIVES = (
    (601, "L'héritage colombien", "Avec Falcao Baby 86 titulaire, terminez 4 matchs Clash d'équipes avec au moins 2 Colombiens titulaires, difficulté Professionnel minimum.", "falcao_prime_colombia_matches", 4, 25),
    (602, "La force des Cafeteros", "Avec Falcao Baby 86 titulaire, gagnez 5 matchs Clash d'équipes avec au moins 3 Colombiens titulaires, difficulté Professionnel minimum.", "falcao_prime_colombia_wins", 5, 25),
    (603, "Les couleurs de la Süper Lig", "Avec Falcao Baby 86 titulaire, terminez 5 matchs Clash d'équipes avec au moins 5 joueurs de Süper Lig titulaires, difficulté Professionnel minimum.", "falcao_prime_league_matches", 5, 25),
    (604, "Domination du championnat", "Avec Falcao Baby 86 titulaire, gagnez 6 matchs Clash d'équipes avec au moins 7 joueurs de Süper Lig titulaires, difficulté Professionnel minimum.", "falcao_prime_league_wins", 6, 25),
    (605, "Au cœur de Galatasaray", "Avec Falcao Baby 86 titulaire, terminez 4 matchs Clash d'équipes avec au moins 2 joueurs de Galatasaray titulaires, difficulté Professionnel minimum.", "falcao_prime_club_matches", 4, 25),
    (606, "Le règne des Lions", "Avec Falcao Baby 86 titulaire, gagnez 5 matchs Clash d'équipes avec au moins 4 joueurs de Galatasaray titulaires, difficulté Professionnel minimum.", "falcao_prime_club_wins", 5, 25),
)


def unlocked(progress):
    return bool(progress.get("foundationFalcaoClaimed"))


def match_increments(context, reason):
    if not context.get("foundationPrimeUnlocked") or reason not in {"WIN", "DRAW", "LOSS"}:
        return {}
    if context.get("mode") != "squad_battles" or int(context.get("difficulty", -1)) < 3:
        return {}
    starters = context.get("starters", [])
    if not any(player.get("resourceId") == FALCAO_ID for player in starters):
        return {}
    colombians = sum(player.get("nation") == 56 for player in starters)
    league_players = sum(player.get("leagueId") == 68 for player in starters)
    club_players = sum(player.get("teamid") == 325 for player in starters)
    result = {}
    for counter, valid in (("falcao_prime_colombia_matches", colombians >= 2),
                           ("falcao_prime_colombia_wins", reason == "WIN" and colombians >= 3),
                           ("falcao_prime_league_matches", league_players >= 5),
                           ("falcao_prime_league_wins", reason == "WIN" and league_players >= 7),
                           ("falcao_prime_club_matches", club_players >= 2),
                           ("falcao_prime_club_wins", reason == "WIN" and club_players >= 4)):
        if valid:
            result[counter] = 1
    return result


def group(season, progress):
    result = reward_group(season, progress, OBJECTIVES, FALCAO_PRIME_ID, GROUP_ID, "foundationFalcaoPrimeClaimed",
                        "SL League Upgrade",
                        "Utilisez Falcao Baby 86 dans les six nouveaux défis pour gagner Falcao Prime 88 BU invendable et 150 XP supplémentaires. Vous conservez la Baby.", 1)
    return upgrade_status(result, unlocked(progress), 4, "SL League Player")


def claim_group(season):
    return claim_reward_group(season, OBJECTIVES, FALCAO_PRIME_ID, "foundationFalcaoPrimeClaimed", "foundationFalcaoClaimed")
