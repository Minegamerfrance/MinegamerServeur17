from __future__ import annotations

import copy
from typing import Any


OTW_SPECS = (
    (178603, 352500139, "Hummels", 87, "CB", 35),
    (216594, 352538130, "Fekir", 84, "CAM", 25),
    (220018, 352541554, "Rebić", 80, "ST", 15),
)
SEASON_PASS_OTW_IDS = frozenset(entry[1] for entry in OTW_SPECS)


def install(module: Any) -> None:
    for asset_id, resource_id, name, rating, position, level in OTW_SPECS:
        base = module.PLAYER_DB.get(asset_id)
        if base is None:
            raise ValueError(f"Season Pass OTW base player missing: {asset_id}")
        if int(base.get("rating", 0)) != rating or base.get("preferredPosition") != position:
            raise ValueError(f"Season Pass OTW base player mismatch: {asset_id}")
        player = copy.deepcopy(base)
        player.update({
            "resourceId": resource_id,
            "rating": rating,
            "rareflag": 21,
            "rarityName": "Ones to Watch",
            "rarityClass": "otw",
            "preferredPosition": position,
            "tier": "gold",
            "special": True,
            "untradeable": True,
            "packEligible": False,
            "marketEligible": False,
            "rewardEligible": True,
            "obtainable": True,
            "availability": "season_pass",
            "baseResourceId": asset_id,
            "dynamicPortrait": True,
            "seasonPassLevel": level,
        })
        module.PLAYER_DB[resource_id] = player
