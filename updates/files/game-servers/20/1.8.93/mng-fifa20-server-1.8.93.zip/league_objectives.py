from __future__ import annotations

import json
from foundation_objectives import group as reward_group, claim_group as claim_reward_group, upgrade_status
from league_players import CARDS, CLUB_NAMES, LEAGUE_NAMES, NATION_NAMES


GROUPS = {}
for card in CARDS:
    group_id = card["groupId"]
    upgrade = card["stage"] == "prime" or group_id == 16
    baby = next((entry for entry in CARDS if entry["key"] == card["key"] and entry["stage"] == "baby"), None)
    if group_id == 16:
        baby = next(entry for entry in CARDS if entry["groupId"] == 15)
    if card.get("requiresGroupId"):
        baby = next(entry for entry in CARDS if entry["groupId"] == card["requiresGroupId"])
    name = card.get("objectiveName") or card.get("displayName") or ("Moi Gómez" if card["key"] == "moi_gomez" else card["key"].replace("_", " ").title())
    baby_name = (baby.get("objectiveName") or baby.get("displayName") or baby["key"].replace("_", " ").title()) if baby and baby["key"] != card["key"] else name
    claimed_key = f"league_{card['key']}{'Prime' if card['stage'] == 'prime' else 'Baby' if card['stage'] == 'baby' else 'Single'}Claimed"
    required_key = "league_shojiSingleClaimed" if group_id == 16 else f"league_{card['key']}BabyClaimed" if upgrade else None
    if card.get("requiresGroupId"):
        required_key = f"league_{baby['key']}BabyClaimed"
    title = f"{card['prefix']} League {'Upgrade' if upgrade else 'Player'}"
    if card["key"] != "trossard":
        title += f" — {name}"
    source = baby if card["stage"] == "prime" else card
    if card.get("requiresGroupId"):
        source = card
    if card["stage"] == "prime":
        conditions = (("Victoire sur l'aile", "league", "wins", 6, 11),
                      ("Architecte du jeu", "club", "matches", 7, 2),
                      ("Précision du championnat", "nation", "wins", 3, 3))
    else:
        conditions = (("Fierté nationale", "nation", "matches", 2, 1),
                      ("Victoire nationale", "nation", "wins", 3, 2),
                      ("Découverte du championnat", "league", "matches", 3, 3),
                      ("Maîtrise du championnat", "league", "wins", 4, 5),
                      ("Bienvenue au club", "club", "matches", 2, 1),
                      ("Les couleurs du club", "club", "wins", 3, 2))
    specifications = []
    rules = []
    for number, (objective_title, field, event, target, minimum) in enumerate(conditions, 1):
        identifier = group_id * 100 + number
        counter = f"league_{group_id}_{field}_{event}"
        label = {"nation": NATION_NAMES[source["nation"]], "league": LEAGUE_NAMES[source["leagueId"]], "club": CLUB_NAMES[source["teamid"]]}[field]
        action = "Gagnez" if event == "wins" else "Terminez"
        prerequisite = f"Avec {baby_name} Baby {baby['rating']} titulaire, " if upgrade else ""
        if group_id == 16:
            prerequisite = f"Avec Shoji {baby['rating']} titulaire, "
        difficulty = "Professionnel" if upgrade else "Semi-pro"
        description = f"{prerequisite}{action} {target} matchs Clash d'équipes avec au moins {minimum} joueurs de {label} titulaires, difficulté {difficulty} minimum."
        specifications.append((identifier, objective_title, description, counter, target, 25))
        field_name = {"nation": "nation", "league": "leagueId", "club": "teamid"}[field]
        rules.append((counter, field_name, source[field_name], minimum, event == "wins"))
    description = f"Terminez ces défis pour gagner {name} {card['rating']} invendable et {len(specifications) * 25} XP."
    if upgrade:
        description += f" Défis adaptés aux Clash d'équipes : centres, tirs en finesse et buts individuels ne sont pas vérifiables ici. Vous conservez la Baby {baby['rating']}."
        if group_id == 16:
            description = description.replace(f"la Baby {baby['rating']}", f"Shoji {baby['rating']}")
    elif baby:
        description += " Récupérez la carte Baby pour débloquer le groupe League Upgrade."
    GROUPS[group_id] = dict(card=card, specifications=tuple(specifications), rules=tuple(rules),
                           claimed_key=claimed_key, required_key=required_key, title=title,
                           description=description, baby_resource=baby["resourceId"] if upgrade else None)

OBJECTIVES = tuple(entry for group in GROUPS.values() for entry in group["specifications"])
OBJECTIVE_GROUPS = {entry[0]: group_id for group_id, group in GROUPS.items() for entry in group["specifications"]}
SIDE_REWARDS = {identifier: {"type": "pack", "value": 1010, "count": 1, "isUntradeable": True, "halId": 4, "loan": 0}
                for identifier in (801, 802, 803)}


def unlocked(progress, group_id):
    required = GROUPS[group_id]["required_key"]
    return not required or bool(progress.get(required)) or bool(progress.get(GROUPS[group_id]["claimed_key"]))


def unlocked_upgrades(progress):
    return [group_id for group_id, group in GROUPS.items() if group["required_key"] and unlocked(progress, group_id)]


def groups(season, progress):
    result = []
    for group_id, specification in GROUPS.items():
        group = reward_group(season, progress, specification["specifications"], specification["card"]["resourceId"],
                             group_id, specification["claimed_key"], specification["title"], specification["description"], group_id)
        if specification["required_key"]:
            baby = next(entry for entry in CARDS if entry["resourceId"] == specification["baby_resource"])
            upgrade_status(group, unlocked(progress, group_id), baby["groupId"], GROUPS[baby["groupId"]]["title"])
            if group_id == 16 and group["locked"]:
                for field in ("subtitle", "description", "groupDescription"):
                    group[field] = group[field].replace("sa carte Baby", "sa carte Shoji 86")
        for objective in group["objectivesList"]:
            if objective["objectiveId"] in SIDE_REWARDS:
                reward = dict(SIDE_REWARDS[objective["objectiveId"]])
                objective["awardsList"].append(season._native_award(reward))
                objective["awards"].append(dict(reward, **season._native_award(reward)))
                objective["rewardsList"].append(reward)
        result.append(group)
    return result


def claim_group(season, group_id):
    group = GROUPS[group_id]
    result = claim_reward_group(season, group["specifications"], group["card"]["resourceId"], group["claimed_key"], group["required_key"])
    unlocked_groups = [identifier for identifier, upgrade in GROUPS.items()
                       if upgrade["required_key"] == group["claimed_key"]]
    if unlocked_groups:
        result["needsGroupsRefresh"] = True
        result["groupIdsToUnlock"] = unlocked_groups
    return result


def grant_side_reward(season, cursor, progress, objective_id):
    claimed = progress.setdefault("leagueSideRewardsClaimed", [])
    if objective_id in claimed:
        return []
    reward = SIDE_REWARDS[objective_id]
    cursor.execute("INSERT INTO unopened_packs(pack_id,data) VALUES(?,?)",
                   (reward["value"], json.dumps({"source": f"MNG League objective {objective_id}", "untradeable": True, "isUntradeable": True})))
    claimed.append(objective_id)
    return [dict(season._native_award(reward), awardValue=reward["value"])]


def match_increments(context, reason, progress):
    if reason not in {"WIN", "DRAW", "LOSS"} or context.get("mode") != "squad_battles":
        return {}
    starters = context.get("starters", [])
    result = {}
    for group_id, group in GROUPS.items():
        upgrade = bool(group["required_key"])
        if int(context.get("difficulty", -1)) < (3 if upgrade else 2):
            continue
        if upgrade and (not unlocked(progress, group_id) or group_id not in context.get("leagueUpgradesUnlocked", [])
                        or not any(player.get("resourceId") == group["baby_resource"] for player in starters)):
            continue
        for counter, field, value, minimum, win_required in group["rules"]:
            if (not win_required or reason == "WIN") and sum(player.get(field) == value for player in starters) >= minimum:
                result[counter] = 1
    return result
