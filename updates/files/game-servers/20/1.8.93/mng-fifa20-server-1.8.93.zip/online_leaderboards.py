from __future__ import annotations

import copy
import hashlib
import json
import threading
from urllib.parse import parse_qs, urlsplit
from urllib.request import Request, build_opener

from launcher_identity import NoRedirects, session_path
from squad_battles_progress import weekly_window


API = "https://mng-fut20-stats.minegamerfrance.workers.dev/api/fifa20/squad-battles"


class OnlineScores:
    def __init__(self, module, opener=None):
        self.module = module
        self.opener = opener or build_opener(NoRedirects()).open
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.cache = {}

    def token(self):
        identity = getattr(self.module, "_mng_launcher_account", None)
        path = session_path()
        if not identity or path is None:
            return None
        try:
            if path.stat().st_size > 65536:
                return None
            session = json.loads(path.read_text(encoding="utf-8-sig"))
            token = session.get("token", "")
            if not isinstance(token, str) or not token or len(token) > 8192:
                return None
            if hashlib.sha256(token.encode("utf-8")).hexdigest() != identity["tokenHash"]:
                return None
            return token
        except (OSError, ValueError, TypeError, AttributeError):
            return None

    def exchange(self, token, period, payload=None):
        url = API + ("?period=prev" if period == "prev" else "")
        request = Request(url, data=json.dumps(payload).encode() if payload is not None else None,
                          headers={"Authorization": "Bearer " + token, "Accept": "application/json",
                                   "Content-Type": "application/json", "User-Agent": "MNG-FUT-20/1.8.65"},
                          method="POST" if payload is not None else "GET")
        with self.opener(request, timeout=8) as response:
            if response.geturl() != url:
                raise ValueError("Unexpected statistics redirect")
            raw = response.read(262145)
        if len(raw) > 262144:
            raise ValueError("Oversized statistics response")
        result = json.loads(raw)
        if result.get("ok") is not True or not isinstance(result.get("entries"), list):
            raise ValueError("Invalid statistics response")
        start = weekly_window(self.module.now_s())[0]
        expected = weekly_window(start - 1)[0] if period == "prev" else start
        if result.get("week") != expected or len(result["entries"]) > 100:
            raise ValueError("Invalid statistics week")
        with self.lock:
            self.cache[period] = result

    def sync(self):
        token = self.token()
        if token is None:
            with self.lock:
                self.cache.clear()
            return
        with self.module._sb_lock:
            owner = self.module.STATE.get("mng_online_score_owner", "")
            username = self.module._mng_launcher_account["username"]
            if owner and owner != username:
                with self.lock:
                    self.cache.clear()
                self.module.log.warning("MNG FIFA20 : club lie a un autre compte; envoi des scores refuse")
                return
            if not owner:
                self.module.STATE.set("mng_online_score_owner", username)
            snapshot = self.module._sb_state()
            payload = {"week": snapshot["competitionStart"], "points": snapshot["battlePoints"],
                       "matches": snapshot["matchesPlayed"], "wins": snapshot.get("wins", 0),
                       "clubName": self.module.STATE.get("club_name", self.module.CFG["club_name"]), "badge": 1}
        try:
            self.exchange(token, "curr", payload)
            self.exchange(token, "prev")
        except (OSError, ValueError, TypeError, AttributeError) as error:
            self.module.log.warning("MNG FIFA20 classement en ligne indisponible (%s); aucun classement simule", type(error).__name__)

    def run(self):
        while True:
            self.wake.clear()
            self.sync()
            self.wake.wait(30)

    def result(self, period="curr"):
        if self.token() is None:
            return {"entries": [], "leaderboard": [], "total": 0}
        start = weekly_window(self.module.now_s())[0]
        expected = weekly_window(start - 1)[0] if period == "prev" else start
        with self.lock:
            cached = copy.deepcopy(self.cache.get(period, {}))
        if cached.get("week") != expected:
            return {"entries": [], "leaderboard": [], "total": 0}
        entries = cached.get("entries", [])
        return {"entries": entries, "leaderboard": entries, "total": cached.get("total", 0)}

    def rank(self, points):
        if self.token() is None:
            return 101
        with self.lock:
            cached = copy.deepcopy(self.cache.get("curr", {}))
        if cached.get("week") != weekly_window(self.module.now_s())[0]:
            return 101
        user = cached.get("user") or {}
        if user.get("score", {}).get("value") == points:
            return max(1, int(user.get("rank", 101)))
        return 101


def install(module, start_background=True, opener=None):
    scores = OnlineScores(module, opener)
    original_route = module.route_fut
    original_save = module._sb_save

    def save(snapshot):
        original_save(snapshot)
        scores.wake.set()

    def route(method, raw_path, headers, body):
        parsed = urlsplit(raw_path)
        path = parsed.path.replace("/ut/ut/", "/ut/").lower()
        if method.upper() == "GET" and path == "/ut/game/fifa20/sqbt/leaderboard":
            period = "prev" if parse_qs(parsed.query).get("period", ["curr"])[0] == "prev" else "curr"
            scores.wake.set()
            result = scores.result(period)
            module.log.info("MNG FIFA20 classement reel: period=%s comptes=%s", period, result["total"])
            return 200, {"Cache-Control": "no-store"}, module.json_bytes(result)
        if method.upper() == "GET" and path == "/ut/game/fifa20/leaderboards/options":
            module.log.info("MNG FIFA20 classements club: options vides, ecran natif a valider")
            return 200, {"Cache-Control": "no-store"}, module.json_bytes({"options": []})
        if method.upper() == "GET" and (path == "/ut/game/fifa20/leaderboards" or path.startswith("/ut/game/fifa20/leaderboards/")):
            return 200, {"Cache-Control": "no-store"}, module.json_bytes({"entries": [], "leaderboard": [], "total": 0})
        return original_route(method, raw_path, headers, body)

    module._sb_leaderboard = lambda snapshot: scores.result()
    module._sb_rank = scores.rank
    module._sb_save = save
    module.route_fut = route
    module._mng_online_scores = scores
    if start_background and scores.token() is not None:
        threading.Thread(target=scores.run, name="mng-fifa20-scores", daemon=True).start()
    return scores
