from __future__ import annotations

import copy
from storyline_catalog import ATTRIBUTE_GROUPS, _adjust_group
from league_players import install_players as install_league_players


FALCAO_ASSET_ID = 167397
FALCAO_ID = FALCAO_ASSET_ID + 85 * 16777216
FALCAO_PRIME_ID = FALCAO_ASSET_ID + 86 * 16777216
DAVID_LUIZ_ASSET_ID = 179944
DAVID_LUIZ_ID = DAVID_LUIZ_ASSET_ID + 21 * 16777216
DAVID_LUIZ_SET_ID = 53
PLAYER_CATEGORY_ID = 4
ARNAUTOVIC_ASSET_ID = 184200
ARNAUTOVIC_ID = ARNAUTOVIC_ASSET_ID + 21 * 16777216
CILLESSEN_ASSET_ID = 199987
CILLESSEN_ID = CILLESSEN_ASSET_ID + 21 * 16777216
CILLESSEN_SET_ID = 54
BOJAN_ASSET_ID = 176993
BOJAN_ID = BOJAN_ASSET_ID + 51 * 16777216


def install_players(module):
    for asset, resource, rating, rarity, label, rarity_class, face in (
        (FALCAO_ASSET_ID, FALCAO_ID, 86, 85, "Joueur de championnat", "league_player", [76, 86, 73, 83, 48, 78]),
        (FALCAO_ASSET_ID, FALCAO_PRIME_ID, 88, 85, "Joueur de championnat", "league_player", [81, 88, 76, 85, 54, 80]),
        (DAVID_LUIZ_ASSET_ID, DAVID_LUIZ_ID, 83, 21, "À surveiller", "ones_to_watch", [61, 65, 74, 71, 82, 77]),
        (ARNAUTOVIC_ASSET_ID, ARNAUTOVIC_ID, 82, 21, "À surveiller", "ones_to_watch", [80, 79, 77, 81, 47, 82]),
        (CILLESSEN_ASSET_ID, CILLESSEN_ID, 83, 21, "À surveiller", "ones_to_watch", [82, 83, 78, 83, 50, 81]),
        (BOJAN_ASSET_ID, BOJAN_ID, 83, 51, "Flashback", "flashback", [86, 81, 81, 85, 52, 66]),
    ):
        existing = module.PLAYER_DB.get(resource)
        if existing and existing.get("assetId") != asset:
            raise ValueError("Foundation reward resource collision")
        base = module.PLAYER_DB[asset]
        player = copy.deepcopy(base)
        if asset in {FALCAO_ASSET_ID, BOJAN_ASSET_ID}:
            for target, weights in zip(face, ATTRIBUTE_GROUPS):
                _adjust_group(player["attributes"], weights, target)
            player["attributes"]["composure"] = min(99, base["attributes"]["composure"] + face[3] - base["face"][3])
            if asset == FALCAO_ASSET_ID:
                player.update(teamid=325, teamName="Galatasaray SK", leagueId=68, leagueName="Süper Lig")
            else:
                player.update(teamid=241, teamName="FC Barcelona", leagueId=53, leagueName="LaLiga",
                              preferredPosition="CF", nation=45, nationName="Spain")
        if asset == CILLESSEN_ASSET_ID:
            player["attributes"].update(acceleration=50, sprintSpeed=50, gkSpeed=50)
        player.pop("wefutCard", None)
        player.update(resourceId=resource, rating=rating, rareflag=rarity, rarityName=label,
                      rarityClass=rarity_class, face=face, cardsubtypeid=0, tier="gold",
                      special=True, untradeable=True, packEligible=False, marketEligible=False,
                      dynamicPortrait=True, rewardEligible=True, obtainable=True,
                      availability="foundation_objective" if asset in {FALCAO_ASSET_ID, BOJAN_ASSET_ID} else "otw_objective" if asset == ARNAUTOVIC_ASSET_ID else "player_sbc")
        module.PLAYER_DB[resource] = player
    install_league_players(module)


def david_luiz_sbc():
    specifications = (
        (5301, "Les Gunners", "Construisez une équipe autour du nouveau club de David Luiz.", 80, 80,
         [{"kind": "club_players", "value": 1, "count": 1, "text": "Joueurs d'Arsenal : min. 1"}]),
        (5302, "La Seleção", "Mettez le Brésil à l'honneur dans votre équipe.", 80, 80,
         [{"kind": "nation_players", "value": 54, "count": 2, "text": "Joueurs brésiliens : min. 2"}]),
        (5303, "Premier League", "Réunissez des joueurs du championnat anglais.", 81, 75,
         [{"kind": "league_players", "value": 13, "count": 3, "text": "Joueurs de Premier League : min. 3"}]),
        (5304, "De Chelsea à Arsenal", "Rappelez le parcours londonien de David Luiz.", 81, 75,
         [{"kind": "club_players", "value": 5, "count": 1, "text": "Joueurs de Chelsea : min. 1"},
          {"kind": "club_players", "value": 1, "count": 1, "text": "Joueurs d'Arsenal : min. 1"}]),
        (5305, "Équipe compétitive", "Échangez une équipe de qualité avec cinq joueurs rares.", 82, 70,
         [{"kind": "rare_count", "value": 5, "count": -1, "text": "Joueurs rares : min. 5"}]),
        (5306, "À surveiller", "Ajoutez un joueur de l'Équipe de la semaine à votre équipe.", 83, 65,
         [{"kind": "totw_count", "value": 3, "count": 1, "text": "Joueurs Équipe de la semaine : min. 1"}]),
    )
    challenges = []
    for identifier, name, description, rating, chemistry, additional in specifications:
        rules = [
            {"kind": "player_count", "value": 11, "scope": "exact", "count": -1, "text": "Joueurs dans l'équipe : 11"},
            {"kind": "team_rating", "value": rating, "scope": "min", "count": -1, "text": f"Note d'équipe : min. {rating}"},
            {"kind": "chemistry", "value": chemistry, "scope": "min", "count": -1, "text": f"Collectif d'équipe : min. {chemistry}"},
        ]
        rules.extend(dict(rule, scope="min") for rule in additional)
        challenges.append({"challenge_id": identifier, "name": name, "description": description,
                           "players": 11, "formation": "f442", "rules": rules, "awards": []})
    return {"set_id": DAVID_LUIZ_SET_ID, "category_id": PLAYER_CATEGORY_ID, "category": "Joueur", "priority": 0,
            "name": "À surveiller — David Luiz", "description": "Terminez les six DCE pour gagner David Luiz À surveiller 83 DC invendable. Chaque équipe soumise est échangée définitivement.",
            "repeatable": False, "awards": [{"type": "PLAYER", "value": DAVID_LUIZ_ID, "count": 1}],
            "challenges": challenges}


def cillessen_sbc():
    specifications = (
        (5401, "Bienvenue à Valence", "Mettez le nouveau club de Cillessen à l'honneur.", 79, 80,
         {"kind": "club_players", "value": 461, "count": 1, "text": "Joueurs de Valence CF : min. 1"}),
        (5402, "Les Oranje", "Composez une équipe avec des joueurs néerlandais.", 80, 75,
         {"kind": "nation_players", "value": 34, "count": 2, "text": "Joueurs néerlandais : min. 2"}),
        (5403, "LaLiga", "Réunissez des joueurs du championnat espagnol.", 80, 75,
         {"kind": "league_players", "value": 53, "count": 3, "text": "Joueurs de LaLiga : min. 3"}),
        (5404, "Équipe compétitive", "Échangez une équipe contenant cinq joueurs rares.", 81, 70,
         {"kind": "rare_count", "value": 5, "count": -1, "text": "Joueurs rares : min. 5"}),
        (5405, "À surveiller", "Ajoutez un joueur de l'Équipe de la semaine.", 82, 65,
         {"kind": "totw_count", "value": 3, "count": 1, "text": "Joueurs Équipe de la semaine : min. 1"}),
    )
    challenges = []
    for identifier, name, description, rating, chemistry, additional in specifications:
        rules = [
            {"kind": "player_count", "value": 11, "scope": "exact", "count": -1, "text": "Joueurs dans l'équipe : 11"},
            {"kind": "team_rating", "value": rating, "scope": "min", "count": -1, "text": f"Note d'équipe : min. {rating}"},
            {"kind": "chemistry", "value": chemistry, "scope": "min", "count": -1, "text": f"Collectif d'équipe : min. {chemistry}"},
            dict(additional, scope="min"),
        ]
        challenges.append({"challenge_id": identifier, "name": name, "description": description,
                           "players": 11, "formation": "f442", "rules": rules, "awards": []})
    return {"set_id": CILLESSEN_SET_ID, "category_id": PLAYER_CATEGORY_ID, "category": "Joueur", "priority": 1,
            "name": "À surveiller — Jasper Cillessen", "description": "Terminez les cinq DCE pour gagner Jasper Cillessen À surveiller 83 G invendable. Chaque équipe soumise est échangée définitivement.",
            "repeatable": False, "awards": [{"type": "PLAYER", "value": CILLESSEN_ID, "count": 1}],
            "challenges": challenges}
