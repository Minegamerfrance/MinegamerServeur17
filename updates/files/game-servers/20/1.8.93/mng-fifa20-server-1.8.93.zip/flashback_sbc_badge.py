import re
from pathlib import Path
from urllib.parse import urlsplit


REVISION = "mng-flashback-badge-v1"
IMAGE_PATH = re.compile(r"^/fut/sbc/gen4/sets/images/sbc_set_image_(\d+)-" + REVISION + r"\.png$")


def is_flashback(set_entry, players):
    for reward in set_entry.get("awards", []):
        if reward.get("type") == "PLAYER_PICK" and "flashback" in str(reward.get("pool", "")).lower():
            return True
        if reward.get("type") == "PLAYER":
            player = players.get(int(reward.get("value", 0)), {})
            if str(player.get("rarityClass", "")).lower() == "flashback" or player.get("rareflag") == 51:
                return True
    return False


def install(module):
    if getattr(module, "_mng_flashback_badge_installed", False):
        return
    original_summary = module._sbc_set_summary
    original_route = module.route_fut
    asset = Path(__file__).resolve().parent / "assets/sbc/flashback_badge.png"

    def summary(set_entry, *arguments, **keywords):
        result = original_summary(set_entry, *arguments, **keywords)
        if is_flashback(set_entry, module.PLAYER_DB):
            result = dict(result, setImageId=f"{1000000 + int(set_entry['set_id'])}-{REVISION}")
        return result

    def route(method, raw_path, headers, body):
        path = urlsplit(raw_path).path.lower()
        match = IMAGE_PATH.fullmatch(path)
        if match:
            set_id = int(match.group(1)) - 1000000
            entry = next((entry for entry in module.SBC_CATALOG if entry["set_id"] == set_id), None)
            if entry is None or not is_flashback(entry, module.PLAYER_DB):
                return 404, {"Content-Type": "application/json"}, module.json_bytes({"reason": "unknownFlashbackSbc"})
            if method.upper() not in {"GET", "HEAD"}:
                return 405, {"Allow": "GET, HEAD"}, b""
            if not asset.is_file():
                return 404, {"Content-Type": "application/json"}, module.json_bytes({"reason": "missingFlashbackBadge"})
            image = asset.read_bytes()
            module.log.info("Flashback SBC badge served set=%s bytes=%s", set_id, len(image))
            response_headers = {"Content-Type": "image/png", "Content-Length": str(len(image)), "Cache-Control": "no-store"}
            return 200, response_headers, image if method.upper() == "GET" else b""
        return original_route(method, raw_path, headers, body)

    module._sbc_set_summary = summary
    module.route_fut = route
    module._mng_flashback_badge_installed = True
