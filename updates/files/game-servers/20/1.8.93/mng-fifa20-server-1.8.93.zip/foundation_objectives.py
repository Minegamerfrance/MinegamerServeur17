from __future__ import annotations

import json
from foundation_content import FALCAO_ID


CATEGORY_ID = 3
GROUP_ID = 4
OBJECTIVES = (
    (401, "Fierté colombienne", "Terminez 2 matchs Clash d'équipes avec au moins 1 joueur colombien titulaire, difficulté Semi-pro minimum.", "foundation_colombia_matches", 2, 25),
    (402, "Victoire des Cafeteros", "Gagnez 3 matchs Clash d'équipes avec au moins 2 joueurs colombiens titulaires, difficulté Semi-pro minimum.", "foundation_colombia_wins", 3, 25),
    (403, "Découverte de la Süper Lig", "Terminez 3 matchs Clash d'équipes avec au moins 3 joueurs de Süper Lig titulaires, difficulté Semi-pro minimum.", "foundation_league_matches", 3, 25),
    (404, "Maîtrise du championnat", "Gagnez 4 matchs Clash d'équipes avec au moins 5 joueurs de Süper Lig titulaires, difficulté Semi-pro minimum.", "foundation_league_wins", 4, 25),
    (405, "Bienvenue à Galatasaray", "Terminez 2 matchs Clash d'équipes avec au moins 1 joueur de Galatasaray titulaire, difficulté Semi-pro minimum.", "foundation_club_matches", 2, 25),
    (406, "Les Lions d'Istanbul", "Gagnez 3 matchs Clash d'équipes avec au moins 2 joueurs de Galatasaray titulaires, difficulté Semi-pro minimum.", "foundation_club_wins", 3, 25),
)


def match_increments(context, reason):
    if reason not in {"WIN", "DRAW", "LOSS"} or context.get("mode") != "squad_battles" or int(context.get("difficulty", -1)) < 2:
        return {}
    starters = context.get("starters", [])
    colombians = sum(player.get("nation") == 56 for player in starters)
    league_players = sum(player.get("leagueId") == 68 for player in starters)
    club_players = sum(player.get("teamid") == 325 for player in starters)
    result = {}
    for counter, valid in (("foundation_colombia_matches", colombians >= 1),
                           ("foundation_league_matches", league_players >= 3),
                           ("foundation_club_matches", club_players >= 1),
                           ("foundation_colombia_wins", reason == "WIN" and colombians >= 2),
                           ("foundation_league_wins", reason == "WIN" and league_players >= 5),
                           ("foundation_club_wins", reason == "WIN" and club_players >= 2)):
        if valid:
            result[counter] = 1
    return result


def group(season, progress, specifications=OBJECTIVES, resource_id=FALCAO_ID, group_id=GROUP_ID,
          claimed_key="foundationFalcaoClaimed", title="SL League Player",
          description="Terminez les six défis pour gagner Falcao Baby 86 BU invendable et 150 XP. Récupérez sa carte pour débloquer le groupe Falcao Prime 88 ; conservez la Baby pour ses nouveaux défis.", priority=0):
    objectives = []
    for identifier, objective_title, objective_description, counter, target, xp in specifications:
        actual = min(target, progress["totals"].get(counter, 0))
        claimed = season._objective_key(progress, identifier) in progress["claimedObjectives"]
        completed = actual >= target
        reward = {"type": "xp", "value": xp, "count": 1, "isUntradeable": True, "halId": 0, "loan": 0}
        objectives.append({"objectiveId": identifier, "objectiveName": objective_title, "name": objective_title,
                           "objectiveDescription": objective_description, "description": objective_description, "shortDescription": objective_title,
                           "currentProgress": actual, "ruleTargetValue": target, "xp": xp, "xpReward": xp,
                           "progress": actual, "target": target, "currentValue": actual, "targetValue": target,
                           "completed": completed, "isCompleted": completed, "isClaimed": claimed,
                           "state": 2 if claimed else 1 if completed else 0,
                           "awardsList": [season._native_award(reward)],
                           "awards": [dict(reward, **season._native_award(reward))],
                           "rewardsList": [reward], "rewards": [reward]})
    reward = {"type": "player", "value": resource_id, "count": 1, "isUntradeable": True, "halId": 0, "loan": 0}
    claimed = bool(progress.get(claimed_key))
    completed = all(entry["isCompleted"] for entry in objectives)
    return {"groupId": group_id, "name": title, "groupName": title, "title": title, "shortDescription": title,
            "subtitle": description, "description": description, "groupDescription": description,
            "groupType": 1, "priority": priority, "startTime": progress["startedAt"], "endTime": 2145916800,
            "objectivesList": objectives, "objectives": objectives,
            "awardsList": [season._native_award(reward)], "rewardsList": [reward], "rewards": [reward],
            "completed": completed, "isCompleted": completed, "isClaimed": claimed,
            "groupState": 2 if claimed else 1 if completed else 0, "state": 2 if claimed else 1 if completed else 0}


def upgrade_status(group, is_unlocked, required_group_id, required_title):
    locked = not is_unlocked
    group.update(locked=locked, isLocked=locked, requiredGroupId=required_group_id)
    group["groupState"] = group["state"] = 5 if locked else 4 if group["isClaimed"] else 2 if group["isCompleted"] else 1
    if locked:
        description = f"Verrouillé : terminez {required_title} et récupérez sa carte Baby pour débloquer ces défis."
        group["subtitle"] = group["description"] = group["groupDescription"] = description
        group.update(completed=False, isCompleted=False, isClaimed=False)
        for objective in group["objectivesList"]:
            objective.update(locked=True, isLocked=True, completed=False, isCompleted=False, isClaimed=False, state=0,
                             currentProgress=0, progress=0, currentValue=0)
    return group


def claim_group(season, specifications=OBJECTIVES, resource_id=FALCAO_ID, claimed_key="foundationFalcaoClaimed", required_claimed_key=None):
    def claim(cursor, progress):
        if progress.get(claimed_key):
            return {"success": True, "alreadyClaimed": True, "itemData": [], "rewards": [], "awardedPrizes": []}
        if required_claimed_key and not progress.get(required_claimed_key):
            raise ValueError("GROUP_LOCKED")
        if not all(progress["totals"].get(entry[3], 0) >= entry[4] for entry in specifications):
            raise ValueError("OBJECTIVE_NOT_COMPLETE")
        if not all(season._objective_key(progress, entry[0]) in progress["claimedObjectives"] for entry in specifications):
            raise ValueError("OBJECTIVES_NOT_CLAIMED")
        row = cursor.execute("SELECT value FROM kv WHERE key='next_item_id'").fetchone()
        maximum = cursor.execute("SELECT COALESCE(MAX(id),0) FROM items").fetchone()[0]
        item_id = max(int(json.loads(row[0])) if row else 900000000000, maximum) + 1
        item = season.state.build_player_item(resource_id, item_id, "unassigned")
        item.update(untradeable=True, discardValue=0)
        owned = cursor.execute("SELECT id FROM items WHERE resource_id=? AND pile IN ('club','squad') LIMIT 1", (resource_id,)).fetchone()
        if owned:
            item["duplicateId"] = int(owned[0])
        cursor.execute("INSERT INTO items(id,resource_id,pile,data) VALUES(?,?,?,?)", (item_id, resource_id, "unassigned", json.dumps(item)))
        cursor.execute("INSERT INTO kv(key,value) VALUES('next_item_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(item_id),))
        progress[claimed_key] = True
        prize = {"awardType": "item", "awardCount": 1, "awardValue": resource_id, "halId": 0,
                 "loan": 0, "untradeable": True, "itemData": item}
        result = {"success": True, "alreadyClaimed": False, "itemData": [item], "awardedPrizes": [prize],
                  "rewards": [{"type": "player", "value": resource_id, "count": 1, "isUntradeable": True, "halId": 0, "loan": 0}], "userXp": progress["xp"]}
        if claimed_key == "foundationFalcaoClaimed" or claimed_key.endswith("BabyClaimed"):
            result["needsGroupsRefresh"] = True
        if claimed_key == "foundationFalcaoClaimed":
            result["groupIdsToUnlock"] = [6]
        return result
    return season._transaction(claim)
