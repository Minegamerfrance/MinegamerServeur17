import re
import urllib.parse


NATIVE_IDS = {16786230: 9014, 33563446: 500001, 50340662: 500002,
              16777246: 30, 33554462: 500003, 50331678: 500004}


def install(module):
    original_asset = module._native_player_asset_id
    original_search = module._market_search
    original_route = module.route_fut
    resources = {native: resource for resource, native in NATIVE_IDS.items()}
    portrait_aliases = {native: resource for native, resource in resources.items() if native >= 500000}
    portrait_aliases.update({native + resource // 16777216 * 16777216: resource
                            for native, resource in list(portrait_aliases.items())})

    def native_asset(meta, fallback):
        return NATIVE_IDS.get(int(meta.get("resourceId", fallback)), original_asset(meta, fallback))

    def market_search(query):
        selected = module._int_or(module._market_first(query, "maskedDefId", "defId", "assetId"), 0)
        if selected in resources:
            query = dict(query)
            for key in ("maskedDefId", "defId", "assetId"):
                query.pop(key, None)
            query["definitionId"] = [str(resources[selected])]
        return original_search(query)

    def route(method, raw_path, headers, body):
        parsed = urllib.parse.urlsplit(raw_path)
        matched = re.fullmatch(r"/fut/playerheads/g4/single/p(\d+)\.dds", parsed.path.lower())
        resource = portrait_aliases.get(int(matched.group(1))) if matched else None
        if resource is not None:
            raw_path = f"/fut/playerheads/g4/single/p{resource}.dds" + ("?" + parsed.query if parsed.query else "")
        return original_route(method, raw_path, headers, body)

    module._native_player_asset_id = native_asset
    module._market_search = market_search
    module.PLAYER_RESOURCE_ALIASES.update(portrait_aliases)
    module.route_fut = route
