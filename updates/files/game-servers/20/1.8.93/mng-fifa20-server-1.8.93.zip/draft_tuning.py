from __future__ import annotations

import random
from collections import defaultdict
from typing import Any


TARGET_CHOICE_COUNT = 5
MINIMUM_RATING = 75
ELITE_RATING = 90
ELITE_DRAFT_BUDGET = 6


def _rating_weight(rating: int, rarity: int) -> float:
    if rating <= 78:
        weight = 8.0
    elif rating <= 82:
        weight = 6.0
    elif rating <= 85:
        weight = 3.5
    elif rating <= 88:
        weight = 1.6
    elif rating <= 91:
        weight = 0.55
    else:
        weight = 0.12
    if rarity not in (0, 1):
        weight *= 0.35
    if rarity == 48:
        weight *= 0.35
    return weight


def _role_fallback(allowed: set[str] | None) -> set[str] | None:
    if allowed is None:
        return None
    if allowed == {"GK"}:
        return {"GK"}
    if allowed & {"CB", "LB", "RB", "LWB", "RWB"}:
        return {"CB", "LB", "RB", "LWB", "RWB"}
    if allowed & {"CM", "CDM", "CAM", "LM", "RM"}:
        return {"CM", "CDM", "CAM", "LM", "RM"}
    return {"ST", "CF", "LW", "RW", "LF", "RF"}


def _player_groups(module: Any, run: dict[str, Any], allowed: set[str] | None):
    seen_assets = {int(value) for value in run.get("seenAssets", [])}
    groups: dict[int, list[tuple[int, int, int, dict[str, Any]]]] = defaultdict(list)
    for raw_resource_id, meta in module.PLAYER_DB.items():
        resource_id = int(raw_resource_id)
        rating = int(meta.get("rating", 0) or 0)
        if rating < MINIMUM_RATING:
            continue
        if meta.get("availability") in {"season_pass", "catalogue_only"}:
            continue
        if meta.get("obtainable") is False:
            continue
        asset_id = int(module._native_player_asset_id(meta, resource_id))
        if asset_id in seen_assets:
            continue
        position = str(meta.get("preferredPosition", "") or "").upper()
        if not position or (allowed is not None and position not in allowed):
            continue
        rarity = int(meta.get("rareflag", 0) or 0)
        groups[asset_id].append((resource_id, rating, rarity, meta))
    return groups


def _draw_choices(module: Any, rng: random.Random, groups, count: int, elite_budget: int):
    chosen = []
    remaining = {asset_id: list(rows) for asset_id, rows in groups.items()}
    while len(chosen) < count and remaining:
        allow_elite = elite_budget > 0 and not any(row[1][1] >= ELITE_RATING for row in chosen)
        options = [
            (asset_id, row)
            for asset_id, rows in remaining.items()
            for row in rows
            if allow_elite or row[1] < ELITE_RATING
        ]
        if not options:
            break
        weights = [_rating_weight(row[1], row[2]) for _, row in options]
        asset_id, selected = rng.choices(options, weights=weights, k=1)[0]
        chosen.append((asset_id, selected))
        del remaining[asset_id]
    return chosen


def _balanced_player_choices(module: Any, run: dict[str, Any], position_id: int, captain: bool = False):
    allowed = None if captain else module._draft_allowed_positions(run, position_id)
    groups = _player_groups(module, run, allowed)
    target_count = TARGET_CHOICE_COUNT
    non_elite_count = sum(any(row[1] < ELITE_RATING for row in rows) for rows in groups.values())
    if non_elite_count < target_count:
        groups = _player_groups(module, run, _role_fallback(allowed))
        non_elite_count = sum(any(row[1] < ELITE_RATING for row in rows) for rows in groups.values())
    if non_elite_count < target_count:
        groups = _player_groups(module, run, None)
        non_elite_count = sum(any(row[1] < ELITE_RATING for row in rows) for rows in groups.values())
    if non_elite_count < target_count and len(groups) < target_count:
        raise ValueError(f"DRAFT_CHOICES_UNDERFILLED:{position_id}:{len(groups)}")

    serial = int(run.get("choiceSerial", 0) or 0)
    seed = int(run.get("seed", 1) or 1)
    rng = random.Random(seed + serial * 1009 + int(position_id) * 31)
    elite_budget = max(0, ELITE_DRAFT_BUDGET - int(run.get("eliteOptionsShown", 0) or 0))
    selected = _draw_choices(module, rng, groups, target_count, elite_budget)
    if len(selected) != target_count:
        raise ValueError(f"DRAFT_CHOICES_UNDERFILLED:{position_id}:{len(selected)}")

    items = []
    for _, (resource_id, _, _, _) in selected:
        item_id = int(run.get("nextItemId", 910000000000) or 910000000000)
        run["nextItemId"] = item_id + 1
        item = module._native_player_item(module.STATE.build_player_item(resource_id, item_id, "none"))
        items.append(item)

    seen_assets = {int(value) for value in run.get("seenAssets", [])}
    seen_assets.update(asset_id for asset_id, _ in selected)
    run["seenAssets"] = sorted(seen_assets)
    run["choiceSerial"] = serial + 1
    elite_count = sum(rating >= ELITE_RATING for _, (_, rating, _, _) in selected)
    run["eliteOptionsShown"] = int(run.get("eliteOptionsShown", 0) or 0) + elite_count
    module.log.info(
        "DRAFT BALANCE pick=%s captain=%s count=%s ratings=%s eliteShown=%s/%s",
        min(22, len(run.get("picked", {}))), bool(captain), len(items),
        [int(item.get("rating", 0) or 0) for item in items],
        run["eliteOptionsShown"], ELITE_DRAFT_BUDGET,
    )
    return items


def install(module: Any) -> None:
    module._draft_player_choices = lambda run, position_id, captain=False: _balanced_player_choices(
        module, run, position_id, captain
    )
