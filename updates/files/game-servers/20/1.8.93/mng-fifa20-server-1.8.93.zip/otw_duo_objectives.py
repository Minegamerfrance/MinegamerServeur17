from __future__ import annotations

import json

from foundation_content import ARNAUTOVIC_ID
from foundation_objectives import group as reward_group
from otw_objectives import NDOMBELE_ID, match_context as original_match_context
from season_pass_custom_packs import OTW_MAX_85_PACK_ID


GROUP_ID = 18
CLAIMED_KEY = "otwDuoPackClaimed"
OBJECTIVES = (
    (1801, "Buteur à surveiller", "Marquez 10 buts avec Arnautović OTW, avec Ndombele OTW également titulaire.", "otw_duo_goals", 10, 25),
    (1802, "Passeur à surveiller", "Réalisez 10 passes décisives avec Ndombele OTW, avec Arnautović OTW également titulaire.", "otw_duo_assists", 10, 25),
    (1803, "Duo gagnant", "Gagnez 5 matchs FUT avec Arnautović OTW et Ndombele OTW titulaires.", "otw_duo_wins", 5, 25),
    (1804, "Duo fidèle", "Terminez 10 matchs FUT avec Arnautović OTW et Ndombele OTW titulaires.", "otw_duo_matches", 10, 25),
)
REWARD = {"type": "pack", "value": OTW_MAX_85_PACK_ID, "count": 1,
          "isUntradeable": True, "halId": 4, "loan": 0}
SIDE_REWARD = {"type": "pack", "value": 1010, "count": 1,
               "isUntradeable": True, "halId": 4, "loan": 0}
GROUP_XP = {"type": "xp", "value": 300, "count": 1,
            "isUntradeable": True, "halId": 0, "loan": 0}


def match_context(module, request):
    context = original_match_context(module, request)
    if context:
        return context
    squad_id = int(request.get("squadId", module.STATE.get("squad_id", 1)))
    if squad_id == 900001:
        return {}
    squad = module.STATE.get_squad(squad_id) or {}
    starters = []
    for slot in squad.get("players", []):
        if not 0 <= int(slot.get("index", -1)) < 11:
            continue
        item = module.STATE.get_item(int(slot.get("itemId", 0))) or {}
        resource = int(item.get("resourceId", 0))
        player = module.PLAYER_DB.get(resource, {})
        if player:
            starters.append(dict(
                resourceId=resource, assetId=player.get("assetId", 0),
                nation=player.get("nation", 0), leagueId=player.get("leagueId", 0),
                teamid=player.get("teamid", 0), preferredPosition=player.get("preferredPosition", ""),
            ))
    return {"mode": "fut", "starters": starters}


def match_increments(context, reason):
    if reason not in {"WIN", "DRAW", "LOSS"}:
        return {}
    starters = context.get("starters", [])
    resources = {player.get("resourceId") for player in starters}
    if not {ARNAUTOVIC_ID, NDOMBELE_ID}.issubset(resources):
        return {}
    result = {"otw_duo_matches": 1}
    if reason == "WIN":
        result["otw_duo_wins"] = 1
    stats = context.get("playerStats", [])
    if not isinstance(stats, list):
        return result
    for resource, field, counter in (
        (ARNAUTOVIC_ID, "goals", "otw_duo_goals"),
        (NDOMBELE_ID, "assists", "otw_duo_assists"),
    ):
        rows = [row for row in stats if isinstance(row, dict) and row.get("resourceId") == resource]
        if len(rows) != 1:
            continue
        amount = rows[0].get(field)
        if isinstance(amount, int) and not isinstance(amount, bool) and 0 < amount <= 100:
            result[counter] = amount
    return result


def attach_match_stats(season, match_key, payload):
    stats = payload.get("playerStats")
    if not match_key:
        return
    with season.state.lock, season.state.conn:
        row = season.state.conn.execute(
            "SELECT data FROM mng_pass_match_contexts WHERE match_key=?", (match_key,),
        ).fetchone()
        if row:
            context = json.loads(row[0])
            if not isinstance(stats, list):
                resources = {player.get("resourceId") for player in context.get("starters", [])}
                if {ARNAUTOVIC_ID, NDOMBELE_ID}.issubset(resources):
                    season.module.log.warning(
                        "OTW DUO match %s has no playerStats: goals/assists cannot be attributed; no estimated progress credited",
                        match_key,
                    )
                return
            context["playerStats"] = stats
            season.state.conn.execute(
                "UPDATE mng_pass_match_contexts SET data=? WHERE match_key=?",
                (json.dumps(context), match_key),
            )


def group(season, progress):
    result = reward_group(
        season, progress, OBJECTIVES, ARNAUTOVIC_ID, GROUP_ID, CLAIMED_KEY,
        "Duo OTW — Pack 85 max",
        "Terminez les quatre défis avec Arnautović OTW et Ndombele OTW : un pack de deux joueurs Or rares et 25 XP par défi ; un pack OTW 85 max garanti et 300 XP pour le groupe.", 1,
    )
    for objective in result["objectivesList"]:
        rewards = [dict(SIDE_REWARD)] + objective["rewardsList"]
        objective["rewardsList"] = objective["rewards"] = rewards
        objective["awardsList"] = [dict(season._native_award(reward), awardValue=reward["value"]) for reward in rewards]
        objective["awards"] = [dict(reward, **award) for reward, award in zip(rewards, objective["awardsList"])]
    rewards = [dict(REWARD), dict(GROUP_XP)]
    result["awardsList"] = [dict(season._native_award(reward), awardValue=reward["value"]) for reward in rewards]
    result["rewardsList"] = result["rewards"] = rewards
    return result


def grant_side_reward(season, cursor, progress, objective_id):
    if objective_id not in {entry[0] for entry in OBJECTIVES}:
        return []
    claimed = progress.setdefault("otwDuoSideRewardsClaimed", [])
    if objective_id in claimed:
        return []
    cursor.execute(
        "INSERT INTO unopened_packs(pack_id,data) VALUES(?,?)",
        (1010, json.dumps({"source": f"MNG FUT Duo OTW objective {objective_id}", "untradeable": True, "isUntradeable": True})),
    )
    claimed.append(objective_id)
    return [dict(season._native_award(SIDE_REWARD), awardValue=1010)]


def claim_group(season):
    def claim(cursor, progress):
        if progress.get(CLAIMED_KEY):
            return {"success": True, "alreadyClaimed": True, "itemData": [], "rewards": [], "awardedPrizes": []}
        if not all(progress["totals"].get(entry[3], 0) >= entry[4] for entry in OBJECTIVES):
            raise ValueError("OBJECTIVE_NOT_COMPLETE")
        if not all(season._objective_key(progress, entry[0]) in progress["claimedObjectives"] for entry in OBJECTIVES):
            raise ValueError("OBJECTIVES_NOT_CLAIMED")
        cursor.execute(
            "INSERT INTO unopened_packs(pack_id,data) VALUES(?,?)",
            (OTW_MAX_85_PACK_ID, json.dumps({"source": "MNG FUT Duo OTW", "untradeable": True, "isUntradeable": True})),
        )
        progress[CLAIMED_KEY] = True
        previous_xp = progress["xp"]
        progress["xp"] = min(40000, previous_xp + 300)
        rewards = [dict(REWARD), dict(GROUP_XP)]
        prizes = [dict(season._native_award(reward), awardValue=reward["value"]) for reward in rewards]
        return {"success": True, "alreadyClaimed": False, "itemData": [], "rewards": rewards,
                "awardedPrizes": prizes, "userXp": progress["xp"], "xpAwarded": progress["xp"] - previous_xp}
    return season._transaction(claim)
