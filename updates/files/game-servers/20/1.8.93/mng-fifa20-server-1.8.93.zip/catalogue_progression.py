import json
import threading
from urllib.parse import urlsplit


PACK_ID = 1046
BOOST_KEY = "easfc_catalog_500_coin_boost"
PACK_LEVELS = (2, 3, 4, 6, 7, 8, 9)


def reward(item_id, level, name, description, kind):
    return {
        "id": item_id, "itemId": item_id, "catalogId": 0, "name": name,
        "level": level, "requiredLevel": level, "rewardType": kind, "price": 0,
        "userLimit": 1, "prices": [{"currency": "pow_funds", "price": 0}],
        "attributes": [
            {"name": "itemName", "value": name},
            {"name": "itemDescription", "value": description},
            {"name": "unlockLevel", "value": str(level)},
            {"name": "typeId", "value": str(item_id)},
            {"name": "catalogueType", "value": "1"},
            {"name": "subCatalogueType", "value": "1"},
            {"name": "isConsumable", "value": "1"},
            {"name": "ungiftable", "value": "1"},
        ],
    }


REWARDS = {100 + level: reward(100 + level, level, "Pack 1 joueur Or rare",
                             "Recevez un pack contenant exactement un joueur Or rare. Récompense unique de ce niveau.", "pack")
           for level in PACK_LEVELS}
REWARDS[5] = reward(5, 5, "Boost de 500 crédits — 5 matchs",
                    "Gagnez 500 crédits FUT supplémentaires pour chacun des 5 prochains matchs terminés. Récupérable une seule fois.", "boost")


def claim_key(item_id):
    return f"easfc_catalog_reward_{item_id}_claimed"


def claim(state, item_id):
    entry = REWARDS[item_id]
    with state.lock:
        connection = state.conn
        connection.execute("BEGIN IMMEDIATE")
        try:
            if connection.execute("SELECT value FROM kv WHERE key=?", (claim_key(item_id),)).fetchone():
                connection.commit()
                return {"success": True, "alreadyClaimed": True, "message": "Récompense déjà récupérée."}
            if entry["rewardType"] == "pack":
                connection.execute("INSERT INTO unopened_packs(pack_id,data) VALUES(?,?)",
                                   (PACK_ID, json.dumps({"source": "easfc_catalogue", "level": entry["level"]})))
                message = "Pack 1 joueur Or rare récupéré. Retrouvez-le dans Mes packs de FUT."
            else:
                boost = {"remaining": 5, "amount": 500, "events": []}
                connection.execute("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                                   (BOOST_KEY, json.dumps(boost)))
                message = "Boost activé : +500 crédits pour vos 5 prochains matchs terminés."
            connection.execute("INSERT INTO kv(key,value) VALUES(?,?)", (claim_key(item_id), "1"))
            connection.commit()
            return {"success": True, "alreadyClaimed": False, "message": message}
        except Exception:
            connection.rollback()
            raise


def apply_boost(state, event_key):
    with state.lock:
        connection = state.conn
        connection.execute("BEGIN IMMEDIATE")
        try:
            saved = connection.execute("SELECT value FROM kv WHERE key=?", (BOOST_KEY,)).fetchone()
            boost = json.loads(saved[0]) if saved else None
            if not boost or boost["remaining"] <= 0 or event_key in boost["events"]:
                connection.commit()
                return 0
            row = connection.execute("SELECT value FROM kv WHERE key='credits'").fetchone()
            credits = int(json.loads(row[0])) if row else 0
            amount = int(boost["amount"])
            boost["remaining"] -= 1
            boost["events"].append(event_key)
            connection.execute("INSERT INTO kv(key,value) VALUES('credits',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                               (json.dumps(credits + amount),))
            connection.execute("UPDATE kv SET value=? WHERE key=?", (json.dumps(boost), BOOST_KEY))
            connection.commit()
            return amount
        except Exception:
            connection.rollback()
            raise


def install(module):
    if getattr(module, "_mng_catalogue_progression_installed", False):
        return
    import season_pass_custom_packs

    original_pool = season_pass_custom_packs._eligible
    season_pass_custom_packs.PACKS[PACK_ID] = {
        "name": "Pack 1 joueur Or rare", "bio": "Un joueur Or rare garanti, non échangeable."
    }

    def eligible(server, pack_id):
        if pack_id != PACK_ID:
            return original_pool(server, pack_id)
        return [int(resource) for resource, player in server.PLAYER_DB.items()
                if int(player.get("rating", 0)) >= 75 and int(player.get("rareflag", 0)) == 1
                and not player.get("special", False) and player.get("packEligible") is not False
                and player.get("obtainable") is not False
                and server._player_is_pack_safe(player)
                and not server._player_is_excluded_from_packs(resource, player)]

    season_pass_custom_packs._eligible = eligible
    original_record = module.State.record_global_match
    context = threading.local()

    def record_match(state, result, event_key=None):
        recorded = original_record(state, result, event_key)
        if recorded:
            amount = apply_boost(state, str(event_key))
            context.bonus = getattr(context, "bonus", 0) + amount
            if amount:
                module.log.info("EASFC coin boost applied amount=%d event=%s", amount, event_key)
        return recorded

    module.State.record_global_match = record_match
    original_route = module.route_fut

    def route(method, raw_path, headers, body):
        path = urlsplit(raw_path).path.lower().replace("/ut/ut/", "/ut/")
        match_end = method.upper() == "POST" and path == "/ut/game/fifa20/match/end"
        if match_end:
            context.bonus = 0
        response = original_route(method, raw_path, headers, body)
        if not match_end or response[0] != 200:
            return response
        payload = json.loads(response[2])
        if not isinstance(payload, dict):
            return response
        credits = module.STATE.credits()
        for field in ("credits", "coins", "totalCredits"):
            if field in payload:
                payload[field] = credits
        for currency in payload.get("currencies", []):
            if currency.get("name") == "coins":
                currency.update(funds=credits, finalFunds=credits)
        if context.bonus:
            payload["catalogueCoinBoost"] = context.bonus
        return response[0], response[1], module.json_bytes(payload)

    module.route_fut = route
    module._mng_catalogue_progression_installed = True
