from __future__ import annotations

import json
import urllib.parse
from typing import Any


DRAFT_SQUAD_ID = 900001


def _repair_squad(squad: dict[str, Any]) -> bool:
    players = squad.get("players")
    if not isinstance(players, list):
        return False
    player_ids = set()
    candidates = []
    for player in players:
        if not isinstance(player, dict):
            continue
        item = player.get("itemData")
        if not isinstance(item, dict):
            continue
        try:
            item_id = int(item.get("id", 0) or 0)
        except (TypeError, ValueError):
            continue
        if item_id <= 0:
            continue
        try:
            index = int(player.get("index", 99))
        except (TypeError, ValueError):
            index = 99
        if not 0 <= index < 11:
            continue
        player_ids.add(item_id)
        position = str(item.get("preferredPosition", "")).upper()
        candidates.append((0 if position in {"ST", "CF", "LW", "RW"} else 1, index, item_id))
    try:
        captain_id = int(squad.get("captain", 0) or 0)
    except (TypeError, ValueError):
        captain_id = 0
    if not candidates or captain_id in player_ids:
        return False
    squad["captain"] = min(candidates)[2]
    return True


def install(module: Any) -> None:
    if getattr(module, "_mng_draft_captain_safety_installed", False):
        return
    module._mng_draft_captain_safety_installed = True
    original_route = module.route_fut

    def route_fut(method: str, raw_path: str, headers: dict[str, str], body: bytes):
        status, response_headers, response_body = original_route(method, raw_path, headers, body)
        if int(status) != 200:
            return status, response_headers, response_body
        path = urllib.parse.urlsplit(raw_path).path
        while path.startswith("/ut/ut/"):
            path = path[3:]
        if path not in {
            "/ut/game/fifa20/squad/mode/draft/state",
            "/ut/game/fifa20/match",
        }:
            return status, response_headers, response_body
        if path.endswith("/match"):
            request = json.loads(body.decode("utf-8")) if body else {}
            if int(request.get("squadId", 0) or 0) != DRAFT_SQUAD_ID:
                return status, response_headers, response_body
        try:
            payload = json.loads(response_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return status, response_headers, response_body

        repaired = 0

        def visit(value: Any) -> None:
            nonlocal repaired
            if isinstance(value, dict):
                try:
                    squad_id = int(value.get("id", value.get("squadId", -1)) or -1)
                except (TypeError, ValueError):
                    squad_id = -1
                is_draft_squad = squad_id == DRAFT_SQUAD_ID or (
                    path.endswith("/match") and isinstance(value.get("players"), list)
                    and "captain" in value
                )
                if is_draft_squad:
                    repaired += int(_repair_squad(value))
                for child in value.values():
                    visit(child)
            elif isinstance(value, list):
                for child in value:
                    visit(child)

        visit(payload)
        if repaired:
            module.log.warning("DRAFT captain reference repaired in %d squad payload(s)", repaired)
            response_body = module.json_bytes(payload)
            response_headers = dict(response_headers)
            response_headers["Content-Length"] = str(len(response_body))
        return status, response_headers, response_body

    module.route_fut = route_fut
