from __future__ import annotations

import json
import hashlib
import os
import unicodedata
from pathlib import Path
from urllib.request import HTTPRedirectHandler, Request, build_opener


AUTH_API = "https://mng-fut-api.minegamerfrance.workers.dev"


class NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        return None


def open_profile(request, timeout):
    return build_opener(NoRedirects()).open(request, timeout=timeout)


def session_path() -> Path | None:
    configured = os.environ.get("MNG_CLOUD_SESSION_PATH", "").strip()
    if configured:
        return Path(configured).expanduser()
    local = os.environ.get("LOCALAPPDATA", "").strip()
    return Path(local) / "MNGFUTLauncher" / "mng-cloud-session.json" if local else None


def verified_identity(path: Path | None, opener=open_profile) -> tuple[str, str] | None:
    if path is None:
        return None
    try:
        if path.stat().st_size > 65536:
            return None
        session = json.loads(path.read_text(encoding="utf-8-sig"))
        token = session.get("token")
        if not isinstance(token, str) or not token or len(token) > 8192:
            return None
        if any(character in token for character in "\r\n"):
            return None
        base = str(session.get("apiBaseUrl") or AUTH_API).rstrip("/")
        if base != AUTH_API:
            return None
        request = Request(
            AUTH_API + "/api/me",
            headers={"Authorization": "Bearer " + token, "Accept": "application/json",
                     "User-Agent": "MNG-FUT-20/1.8.65"},
        )
        with opener(request, timeout=5) as response:
            if response.geturl() != AUTH_API + "/api/me":
                return None
            payload = response.read(65537)
        if len(payload) > 65536:
            return None
        result = json.loads(payload)
        if result.get("ok") is not True:
            return None
        username = result.get("profile", {}).get("username")
        if not isinstance(username, str):
            return None
        username = username.strip()
        if not 1 <= len(username) <= 32:
            return None
        if any(unicodedata.category(character).startswith("C") for character in username):
            return None
        return username, hashlib.sha256(token.encode("utf-8")).hexdigest()
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def verified_username(path: Path | None, opener=open_profile) -> str | None:
    identity = verified_identity(path, opener)
    return identity[0] if identity else None


def install(module, opener=open_profile) -> bool:
    identity = verified_identity(session_path(), opener)
    if identity is None:
        return False
    username, token_hash = identity
    module.CFG["display_name"] = username
    module._mng_launcher_account = {"username": username, "tokenHash": token_hash}
    module.log.info("MNG FUT 20 : identite du lanceur verifiee, pseudo=%s", username)
    return True
