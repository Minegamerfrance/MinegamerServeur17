import json
import urllib.parse


STATE_KEY = "mng_user_hub_flags"


def install(module):
    original = module.route_fut

    def route(method, raw_path, headers, body):
        status, response_headers, response_body = original(method, raw_path, headers, body)
        path = urllib.parse.urlsplit(raw_path).path.lower().replace("/ut/ut/", "/ut/")
        if path not in {"/ut/game/fifa20/clientdata/userhubdata", "/ut/game/fifa20/usermassinfo"} or status != 200:
            return status, response_headers, response_body
        payload = json.loads(response_body)
        hub = payload if path.endswith("/userhubdata") else payload.get("userHubClientData")
        if not isinstance(hub, dict):
            return status, response_headers, response_body
        submitted = json.loads(body).get("entries", []) if method.upper() in {"PUT", "POST"} and body else []
        with module.STATE.lock:
            flags = module.STATE.get(STATE_KEY, {})
            for entry in hub.get("entries", []) + submitted:
                key = str(int(entry["key"]))
                flags[key] = int(flags.get(key, 0)) | int(entry["value"])
            if submitted:
                module.STATE.set(STATE_KEY, flags)
        hub["entries"] = [{"key": int(key), "value": value} for key, value in sorted(flags.items(), key=lambda entry: int(entry[0]))]
        return status, {**response_headers, "Cache-Control": "no-store"}, module.json_bytes(payload)

    module.route_fut = route
