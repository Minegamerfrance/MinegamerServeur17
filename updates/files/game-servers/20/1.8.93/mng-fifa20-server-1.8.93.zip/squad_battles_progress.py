import copy
import json
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from zoneinfo import ZoneInfo


with (Path(__file__).parent / "assets/timezones/Europe-Paris").open("rb") as timezone_file:
    PARIS = ZoneInfo.from_file(timezone_file, key="Europe/Paris")


def weekly_window(timestamp):
    current = datetime.fromtimestamp(timestamp, PARIS)
    boundary = (current - timedelta(days=(current.weekday() + 1) % 7)).replace(hour=10, minute=0, second=0, microsecond=0)
    if current < boundary:
        boundary -= timedelta(days=7)
    return int(boundary.timestamp()), int((boundary + timedelta(days=7)).timestamp())


def install(module):
    original_new_state = module._sb_new_state
    original_generate = module._sb_generate_opponents
    original_select = module._sb_select
    original_end = module._sb_end_match
    original_hub = module._native_squad_battle_hub
    original_route = module.route_fut
    original_prize = module._sb_prize
    original_match = module._native_squad_battle_match_response
    module._SB_POINT_MATCH_LIMIT = 40

    def normalize(snapshot):
        regular = [entry for entry in snapshot.get("opponents", []) if entry.get("id") != 4]
        for slot, entry in enumerate(regular[:4]):
            old_id = entry.get("id")
            entry["id"] = slot
            if snapshot.get("selectedOpponentId") == old_id:
                snapshot["selectedOpponentId"] = slot

    def new_state(pending_prize=None):
        snapshot = original_new_state(pending_prize)
        start, finish = weekly_window(module.now_s())
        snapshot.update(competitionId=start, competitionStart=start, competitionEnd=finish, rewardSchedule="Europe/Paris:Sunday:10")
        return snapshot

    def state():
        with module._sb_lock:
            raw = module.STATE.get(module._SB_STATE_KEY, {})
            snapshot = dict(raw) if isinstance(raw, dict) and raw else new_state()
            changed = not raw
            if snapshot.get("rewardSchedule") != "Europe/Paris:Sunday:10":
                start, finish = weekly_window(module.now_s())
                snapshot.update(competitionStart=start, competitionEnd=finish, rewardSchedule="Europe/Paris:Sunday:10")
                changed = True
            if snapshot["competitionEnd"] <= module.now_s():
                pending = [snapshot["pendingPrize"]] if snapshot.get("pendingPrize") else []
                pending.extend(snapshot.get("queuedPrizes", []))
                if snapshot.get("matchesPlayed", 0) > 0:
                    tier_name, tier_level = module._sb_tier(snapshot.get("battlePoints", 0))
                    coins, packs = module._SB_REWARDS[tier_level]
                    pending.append(dict(tierName=tier_name, tierLevel=tier_level, coins=coins, packs=list(packs),
                                        competitionId=snapshot["competitionId"]))
                snapshot = new_state(pending[0] if pending else None)
                snapshot["queuedPrizes"] = pending[1:]
                changed = True
            if not isinstance(snapshot.get("opponents"), list) or not snapshot["opponents"]:
                generate(snapshot)
                changed = True
            old_ids = [entry.get("id") for entry in snapshot.get("opponents", [])]
            normalize(snapshot)
            if changed or old_ids != [entry.get("id") for entry in snapshot.get("opponents", [])]:
                module._sb_save(snapshot)
            return snapshot

    def prize(snapshot, claim):
        with module._sb_lock:
            result = original_prize(snapshot, claim)
            if claim and not snapshot.get("pendingPrize") and snapshot.get("queuedPrizes"):
                snapshot["pendingPrize"] = snapshot["queuedPrizes"].pop(0)
                module._sb_save(snapshot)
                result["isPrizeAvailable"] = True
            return result

    def match(slot):
        result = original_match(slot)
        opponent = result.get("opponentSquad", {})
        team_id = int(opponent.get("teamId", opponent.get("teamid", 0)))
        if team_id > 0:
            result["opponentTeamId"] = team_id
        module.log.info("SQUAD-BATTLES START_CONTRACT slot=%s team=%s formation=%s players=%s stadium=%s",
                        slot, result.get("opponentTeamId"), opponent.get("formation"),
                        [(entry.get("index"), entry.get("itemData", {}).get("assetId")) for entry in opponent.get("players", [])],
                        result.get("stadiumAssetId"))
        return result

    def generate(snapshot, refreshed=False):
        featured = [copy.deepcopy(entry) for entry in snapshot.get("opponents", []) if entry.get("id") == 4]
        original_generate(snapshot, refreshed)
        normalize(snapshot)
        snapshot["opponents"].extend(featured)

    def select(snapshot, payload, query=None):
        requested = module._sb_requested_opponent(payload, query)
        selected = next((entry for entry in snapshot.get("opponents", []) if entry.get("id") == requested), None)
        if selected is None or selected.get("played"):
            return None
        return original_select(snapshot, payload, query)

    def rank(points):
        scores = getattr(module, "_mng_online_scores", None)
        return scores.rank(points) if scores is not None else 101

    def end(payload):
        with module._sb_lock:
            before = state()
            result = original_end(payload)
            after = state()
            if not before.get("matchInProgress") or after.get("lastSettledMatchStart") != before.get("lastMatchStart"):
                return result
            opponent = module._sb_selected(after)
            if opponent is None:
                return result
            reason = str(payload.get("endReason", payload.get("result", ""))).upper()
            abandoned = reason in {"QUIT", "DNF", "DISCONNECT", "ABANDONED"}
            difficulty = max(0, min(6, int(before.get("selectedDifficulty", 3))))
            outcome = result.get("endReason", "LOSS")
            modifier = module._SB_DIFFICULTIES[difficulty][1 if outcome in {"WIN", "DRAW"} else 2]
            scored = max(0, int(opponent.get("score", 0)))
            conceded = max(0, int(opponent.get("oppScore", 0)))
            if opponent["id"] == 4:
                points = round((400 if outcome == "WIN" else 250) * modifier)
            else:
                base = {"WIN": 200, "DRAW": 75}.get(outcome, 50)
                performance = max(0, 200 + min(scored, 5) * 40 - min(conceded, 5) * 20)
                points = round((base + performance) * modifier)
            if abandoned or before.get("pointMatchesPlayed", 0) >= 40:
                points = 0
            after["battlePoints"] += points - int(result.get("squadBattlePoints", 0))
            opponent.update(played=True, pointsWon=points, result="DNF" if abandoned else outcome)
            tier_name, tier_level = module._sb_tier(after["battlePoints"])
            result.update(squadBattlePoints=points, battlePoints=after["battlePoints"], score=after["battlePoints"],
                          rank=rank(after["battlePoints"]), userTierLevel=tier_level, tierName=tier_name,
                          needsSquadBattleRefresh=True)
            after["lastMatchResponse"] = dict(result)
            module._sb_save(after)
            return result

    def hub():
        with module._sb_lock:
            result = original_hub()
            snapshot = state()
            progress = module._sb_hub_payload(snapshot)
            result.update({key: value for key, value in progress.items() if key != "sqbtOppSquadList"})
            regular = [entry for entry in snapshot["opponents"] if entry["id"] != 4]
            shared = dict(progress)
            shared.pop("sqbtOppSquadList", None)
            shared.update(id=snapshot["competitionId"], eventId=snapshot["competitionId"], competitionId=snapshot["competitionId"],
                          startTimeStamp=snapshot["competitionStart"], eventStartTime=snapshot["competitionStart"],
                          endTimeStamp=snapshot["competitionEnd"], eventEndTime=snapshot["competitionEnd"],
                          nextEventStartTime=snapshot["competitionEnd"] + 1, gamesPlayed=snapshot["matchesPlayed"],
                          numberOfMatchesPlayed=snapshot["matchesPlayed"], matchesPlayed=snapshot["matchesPlayed"],
                          gamesRemaining=max(0, 40 - snapshot["pointMatchesPlayed"]), remainingMatches=max(0, 40 - snapshot["pointMatchesPlayed"]),
                          squadsRemaining=sum(not entry.get("played", False) for entry in regular),
                          totalGames=40, maxMatches=40, maxNumberOfMatches=40, maxRegularGames=40,
                          userPoints=snapshot["battlePoints"], pointsWon=snapshot["battlePoints"], squadBattlesScore=snapshot["battlePoints"],
                          rank=rank(snapshot["battlePoints"]), tierName=module._sb_tier(snapshot["battlePoints"])[0])
            seconds = max(0, snapshot["competitionEnd"] - module.now_s())
            shared.update({key: seconds for key in ("secondsUntilEnd", "timeUntilEnd", "untilEndSeconds")})
            result.update({key: value for key, value in shared.items() if key not in {"id", "eventId", "competitionId"}})
            for key in ("sqbtEvent", "sqbt2data", "squadBattle"):
                result[key].update(shared)
            result["sqbtOppSquadList"]["nextSquadRefreshTimeStamp"] = snapshot["nextRefresh"]
            displayed = list(result["sqbtOppSquadList"]["sqbtOppSquads"]) + list(result.get("squads", []))
            for entry in displayed:
                recorded = next((recorded for recorded in regular if recorded["id"] == entry["id"]), {})
                for key in ("played", "pointsWon", "score", "oppScore", "penaltyScore", "oppPenaltyScore", "result"):
                    if key in recorded:
                        entry[key] = recorded[key]
            return result

    def route(method, raw_path, headers, body):
        path = urlsplit(raw_path).path.replace("/ut/ut/", "/ut/").lower()
        if method.upper() == "POST" and path == "/ut/game/fifa20/match":
            payload = json.loads(body or b"{}")
            query = parse_qs(urlsplit(raw_path).query)
            consumer = str(payload.get("featureConsumerId", query.get("featureConsumerId", [""])[0])).lower()
            featured = (module._sb_find_int(payload, ("featuredSquadId",), 0) == 1 or consumer == "sqbttotw"
                        or module._sb_requested_opponent(payload, query) == 4)
            if featured or module._sb_is_match_request(payload, query):
                with module._sb_lock:
                    snapshot = state()
                    requested = 4 if featured else module._sb_requested_opponent(payload, query)
                    if snapshot.get("matchInProgress"):
                        return 409, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "SQUAD_BATTLE_MATCH_IN_PROGRESS"})
                    selected = next((entry for entry in snapshot["opponents"] if entry["id"] == requested), None)
                    if selected is None and not featured:
                        return 409, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "SQUAD_BATTLE_OPPONENT_NOT_FOUND"})
                    if selected is not None and selected.get("played"):
                        return 409, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "SQUAD_BATTLE_OPPONENT_ALREADY_PLAYED"})
        if method.upper() in {"POST", "PUT"} and path.startswith("/ut/game/fifa20/sqbt/") and path.endswith("/refresh"):
            with module._sb_lock:
                if state().get("matchInProgress"):
                    return 409, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "SQUAD_BATTLE_MATCH_IN_PROGRESS"})
        return original_route(method, raw_path, headers, body)

    module._sb_generate_opponents = generate
    module._sb_new_state = new_state
    module._sb_prize = prize
    module._native_squad_battle_match_response = match
    module._sb_state = state
    module._sb_select = select
    module._sb_end_match = end
    module._sb_rank = rank
    module._native_squad_battle_hub = hub
    module.route_fut = route
