import copy


ASSET_ID = 208808
RESOURCE_ID = ASSET_ID + 21 * 16777216
SET_ID = 58
CHALLENGE_IMAGES = {
    5801: "200092-0b734bf8-50a6",
    5802: "330005-fb83431f-9d46",
}


def install_player(module):
    existing = module.PLAYER_DB.get(RESOURCE_ID)
    if existing and existing.get("assetId") != ASSET_ID:
        raise ValueError("Promes OTW resource collision")
    player = copy.deepcopy(module.PLAYER_DB[ASSET_ID])
    player.pop("wefutCard", None)
    player.update(resourceId=RESOURCE_ID, rareflag=21, rarityName="À surveiller",
                  rarityClass="ones_to_watch", special=True, untradeable=True,
                  packEligible=False, marketEligible=False, dynamicPortrait=True,
                  rewardEligible=True, obtainable=True, availability="player_sbc")
    module.PLAYER_DB[RESOURCE_ID] = player
    original_settings = module.load_pack_settings

    def settings():
        result = copy.deepcopy(original_settings())
        for identifier, name, description in (
            (1016, "Pack Or Premium Jumbo", "24 éléments Or, dont 7 rares : joueurs, entraîneurs, consommables et éléments de club."),
            (1013, "Pack de joueurs Or Premium", "12 joueurs Or, dont 3 rares."),
        ):
            result["packs"][str(identifier)]["name"] = name
            result["packs"][str(identifier)]["bio"] = description
        return result

    module.load_pack_settings = settings


def sbc():
    challenges = []
    for identifier, title, description, rating, chemistry, league_count, pack in (
        (5801, "Premier League", "Échangez une équipe comprenant au moins un joueur de Premier League.", 84, 75, 1, 1016),
        (5802, "Équipe notée 85", "Échangez une équipe notée au moins 85.", 85, 55, 0, 1013),
    ):
        rules = [
            {"kind": "player_count", "value": 11, "scope": "exact", "count": -1, "text": "Nombre de joueurs dans l'équipe : 11"},
            {"kind": "team_rating", "value": rating, "scope": "min", "count": -1, "text": f"Note d'équipe : minimum {rating}"},
            {"kind": "chemistry", "value": chemistry, "scope": "min", "count": -1, "text": f"Collectif d'équipe : minimum {chemistry}"},
        ]
        if league_count:
            rules.append({"kind": "league_players", "value": 13, "scope": "min", "count": 1,
                          "text": "Joueurs de Premier League : minimum 1"})
        challenges.append({"challenge_id": identifier, "name": title, "description": description,
                           "players": 11, "formation": "f442", "rules": rules,
                           "awards": [{"type": "PACK", "pack_id": pack, "count": 1}]})
    return {"set_id": SET_ID, "category_id": 4, "category": "Joueur", "priority": 8,
            "name": "Quincy Promes", "description": "Gagnez Quincy Promes À surveiller (OTW) en terminant ces deux défis.",
            "repeatable": False, "awards": [{"type": "PLAYER", "value": RESOURCE_ID, "count": 1}],
            "challenges": challenges}
