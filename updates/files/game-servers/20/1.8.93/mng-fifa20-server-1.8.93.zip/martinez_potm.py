import copy

from storyline_catalog import ATTRIBUTE_GROUPS, _adjust_group


ASSET_ID = 207877
RESOURCE_ID = ASSET_ID + 67 * 16777216
SET_ID = 55
CHALLENGE_IMAGES = {5501: "330004-1f4ce31f-188f", 5502: "220025-1f2d9d28-2e6a"}


def install_player(module):
    existing = module.PLAYER_DB.get(RESOURCE_ID)
    if existing and existing.get("assetId") != ASSET_ID:
        raise ValueError("Martinez POTM resource collision")
    base = module.PLAYER_DB[ASSET_ID]
    player = copy.deepcopy(base)
    face = [93, 85, 72, 85, 29, 79]
    for target, weights in zip(face, ATTRIBUTE_GROUPS):
        _adjust_group(player["attributes"], weights, target)
    player["attributes"]["composure"] = min(99, base["attributes"]["composure"] + face[3] - base["face"][3])
    player.pop("wefutCard", None)
    player.update(resourceId=RESOURCE_ID, rating=86, face=face, preferredPosition="ST",
                  rareflag=67, rarityName="POTM MLS", rarityClass="potm_mls", cardsubtypeid=0,
                  tier="gold", special=True, untradeable=True, packEligible=False, marketEligible=False,
                  dynamicPortrait=True, rewardEligible=True, obtainable=True, availability="player_sbc")
    module.PLAYER_DB[RESOURCE_ID] = player


def sbc():
    challenges = []
    for identifier, title, rating, chemistry, pack_id in (
        (5501, "Équipe notée 84", 84, 75, 1016),
        (5502, "Major League Soccer", 85, 65, 1013),
    ):
        rules = [
            {"kind": "player_count", "value": 11, "scope": "exact", "count": -1, "text": "Joueurs dans l'équipe : 11"},
            {"kind": "team_rating", "value": rating, "scope": "min", "count": -1, "text": f"Note d'équipe : min. {rating}"},
            {"kind": "chemistry", "value": chemistry, "scope": "min", "count": -1, "text": f"Collectif d'équipe : min. {chemistry}"},
        ]
        if identifier == 5502:
            rules.append({"kind": "league_players", "value": 39, "scope": "min", "count": 1,
                          "text": "Joueurs de Major League Soccer : min. 1"})
        challenges.append({"challenge_id": identifier, "name": title,
                           "description": "Échangez une équipe respectant les exigences pour gagner le pack indiqué.",
                           "players": 11, "formation": "f442", "rules": rules,
                           "awards": [{"type": "PACK", "pack_id": pack_id, "count": 1}]})
    return {"set_id": SET_ID, "category_id": 4, "category": "Joueur", "priority": 5,
            "name": "POTM MLS — Josef Martínez",
            "description": "Terminez les deux DCE pour gagner Josef Martínez POTM MLS 86 BU invendable. Chaque équipe soumise est échangée définitivement.",
            "repeatable": False, "awards": [{"type": "PLAYER", "value": RESOURCE_ID, "count": 1}],
            "challenges": challenges}
