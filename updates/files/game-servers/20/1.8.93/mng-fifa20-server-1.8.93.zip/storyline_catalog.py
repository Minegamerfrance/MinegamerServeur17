from __future__ import annotations

import copy
from typing import Any


STORYLINE_SPECS = (
    (39386, 50371034, 83, "LM", (88, 74, 76, 84, 80, 76)),
    (190813, 50522461, 85, "LW", (91, 83, 82, 89, 45, 67)),
    (5479, 50337127, 85, "GK", (87, 80, 66, 86, 57, 88)),
    (120533, 50452181, 86, "CB", (73, 56, 61, 66, 87, 87)),
    (165239, 50496887, 84, "CAM", (80, 81, 83, 85, 42, 64)),
)
DORMANT_STORYLINE_IDS = frozenset(entry[1] for entry in STORYLINE_SPECS)
ATTRIBUTE_GROUPS = (
    {"acceleration": 45, "sprintSpeed": 55},
    {"positioning": 5, "finishing": 45, "shotPower": 20, "longShots": 20, "volleys": 5, "penalties": 5},
    {"vision": 20, "crossing": 20, "freeKickAccuracy": 5, "shortPassing": 35, "longPassing": 15, "curve": 5},
    {"agility": 10, "balance": 5, "reactions": 5, "ballControl": 30, "dribbling": 50},
    {"interceptions": 20, "headingAccuracy": 10, "marking": 30, "standingTackle": 30, "slidingTackle": 10},
    {"jumping": 5, "stamina": 25, "strength": 50, "aggression": 20},
)


def _group_rating(attributes: dict[str, int], weights: dict[str, int]) -> int:
    return (sum(int(attributes[name]) * weight for name, weight in weights.items()) + 50) // 100


def _adjust_group(attributes: dict[str, int], weights: dict[str, int], target: int) -> None:
    difference = target - _group_rating(attributes, weights)
    adjusted = {name: max(1, min(99, int(attributes[name]) + difference)) for name in weights}
    if _group_rating(adjusted, weights) != target:
        raise ValueError("Storyline attribute group cannot match the supplied card")
    attributes.update(adjusted)


def install(module: Any) -> None:
    for asset_id, resource_id, rating, position, face in STORYLINE_SPECS:
        existing = module.PLAYER_DB.get(resource_id)
        if existing and (existing.get("assetId") != asset_id or existing.get("rarityClass") != "season_reward"):
            raise ValueError(f"Storyline resource collision: {resource_id}")
        base = module.PLAYER_DB[asset_id]
        player = copy.deepcopy(base)
        attributes = player["attributes"]
        if position == "GK":
            for index, name in ((0, "gkDiving"), (1, "gkHandling"), (2, "gkKicking"),
                                (3, "gkReflexes"), (5, "gkPositioning")):
                attributes[name] = face[index]
            _adjust_group(attributes, {"acceleration": 50, "sprintSpeed": 50}, face[4])
            attributes["gkSpeed"] = face[4]
            attributes["reactions"] = min(99, int(attributes["reactions"]) + rating - int(base["rating"]))
        else:
            for target, weights in zip(face, ATTRIBUTE_GROUPS):
                _adjust_group(attributes, weights, target)
            attributes["composure"] = max(1, min(99, int(attributes["composure"]) + face[3] - int(base["face"][3])))
        player.pop("wefutCard", None)
        player.update({
            "resourceId": resource_id, "rating": rating, "preferredPosition": position,
            "face": list(face), "rareflag": 91, "rarityName": "Season Reward",
            "rarityClass": "season_reward", "cardsubtypeid": 0, "tier": "gold",
            "special": True, "untradeable": True, "packEligible": False,
            "marketEligible": False, "rewardEligible": False, "obtainable": False,
            "availability": "catalogue_only", "baseResourceId": asset_id,
            "dynamicPortrait": True,
        })
        module.PLAYER_DB[resource_id] = player
