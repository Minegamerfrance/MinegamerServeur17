import copy

from storyline_catalog import ATTRIBUTE_GROUPS, _adjust_group


ASSET_ID = 190362
RESOURCE_ID = ASSET_ID + 3 * 16777216
SET_ID = 56
CHALLENGE_IMAGES = {
    5601: "200092-0b734bf8-50a6",
    5602: "330002-cd773665-1825",
}


def install_player(module):
    existing = module.PLAYER_DB.get(RESOURCE_ID)
    if existing and existing.get("assetId") != ASSET_ID:
        raise ValueError("Pukki POTM resource collision")
    base = module.PLAYER_DB[ASSET_ID]
    player = copy.deepcopy(base)
    face = [84, 84, 74, 80, 36, 76]
    for target, weights in zip(face, ATTRIBUTE_GROUPS):
        _adjust_group(player["attributes"], weights, target)
    player["attributes"]["composure"] = min(99, base["attributes"]["composure"] + face[3] - base["face"][3])
    player.pop("wefutCard", None)
    player.update(resourceId=RESOURCE_ID, rating=84, face=face, preferredPosition="ST",
                  rareflag=43, rarityName="POTM Premier League", rarityClass="potm_premier_league",
                  cardsubtypeid=0, tier="gold", special=True, untradeable=True,
                  packEligible=False, marketEligible=False, dynamicPortrait=True,
                  rewardEligible=True, obtainable=True, availability="player_sbc")
    module.PLAYER_DB[RESOURCE_ID] = player


def sbc():
    challenges = []
    for identifier, title, chemistry, league_count in (
        (5601, "Premier League", 75, 1),
        (5602, "82-Rated Squad", 65, 0),
    ):
        rules = [
            {"kind": "player_count", "value": 11, "scope": "exact", "count": -1,
             "text": "# of players in the Squad: 11"},
            {"kind": "team_rating", "value": 82, "scope": "min", "count": -1,
             "text": "Squad Rating: Min 82"},
            {"kind": "chemistry", "value": chemistry, "scope": "min", "count": -1,
             "text": f"Squad Total Chemistry Points: Min {chemistry}"},
        ]
        if league_count:
            rules.append({"kind": "league_players", "value": 13, "scope": "min", "count": league_count,
                          "text": "# of players from Premier League: Min 1"})
        challenges.append({"challenge_id": identifier, "name": title,
                           "description": "Exchange a squad meeting the requirements to earn a Premium Gold Pack.",
                           "players": 11, "formation": "f442", "rules": rules,
                           "awards": [{"type": "PACK", "pack_id": 1005, "count": 1}]})
    return {"set_id": SET_ID, "category_id": 4, "category": "Joueur", "priority": 6,
            "name": "Teemu Pukki",
            "description": "Earn the Premier League Player of the Month for August, Teemu Pukki",
            "repeatable": False,
            "awards": [{"type": "PLAYER", "value": RESOURCE_ID, "count": 1}],
            "challenges": challenges}
