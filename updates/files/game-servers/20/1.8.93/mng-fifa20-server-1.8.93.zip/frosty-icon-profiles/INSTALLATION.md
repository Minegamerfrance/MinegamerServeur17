# Biographies françaises de Robben et Juninho

Ce correctif remplace le texte manquant `*FUT_LEGEND_DESCR_9014` pour Robben,
et le texte équivalent pour Juninho. Il couvre leurs trois versions Icône.
Les autres légendes gardent leur description originale.

## Installation côté jeu

La mise à jour du serveur seule ne peut pas modifier ce texte natif.
Dans **Frosty Editor**, avec le profil FIFA 20 et votre projet habituel :

1. Ouvrir **Legacy Explorer** et retrouver
   `data/ui/external/ion_fut/screens/futPlayerBio.big`.
2. Importer sur cette ressource le fichier du même chemin dans ce dossier.
3. Enregistrer le projet, exporter le mod et l'activer dans Frosty Mod Manager.
4. Relancer le jeu par Frosty, puis ouvrir **Profil Icône** sur Robben ou Juninho.

Si un autre mod remplace déjà cet écran, intégrer ce correctif au même projet
ou lui donner la priorité pour cette ressource. Une copie originale est dans
`sauvegarde/futPlayerBio.big` pour revenir en arrière.

Les photos de Juninho sont corrigées séparément par les portraits du serveur
1.8.47, avec le même positionnement que Robben. Aucun changement de note,
d'effectifs, de carte possédée ou de récompense n'est nécessaire.

## Vérification

Le correctif vise uniquement la description du profil ; il ne remplit pas les
tableaux de statistiques de carrière. Les textes sont rédigés en français et
vérifiés auprès du [Bayern Munich](https://fcbayern.com/en/club/history/mile-stones/2010-to-2013-the-historic-treble)
et de l'[Olympique Lyonnais](https://www.ol.fr/en/news/inoubliable-juninho-23123-2).
Les tests vérifient la sélection des deux joueurs, le maintien des descriptions
des autres Icônes et l'intégrité des modèles de l'écran après réencodage.
L'affichage réel doit encore être confirmé en jeu après l'import Frosty.
