from __future__ import annotations

from foundation_content import BOJAN_ID
from foundation_objectives import group as reward_group, claim_group as claim_reward_group


CATEGORY_ID = 5
GROUP_ID = 17
OBJECTIVES = (
    (1701, "Fierté espagnole", "Terminez 2 matchs Clash d'équipes avec au moins 1 joueur espagnol titulaire, difficulté Semi-pro minimum.", "bojan_nation_matches", 2, 25),
    (1702, "Victoire de la Roja", "Gagnez 3 matchs Clash d'équipes avec au moins 2 joueurs espagnols titulaires, difficulté Semi-pro minimum.", "bojan_nation_wins", 3, 25),
    (1703, "Découverte de LaLiga", "Terminez 3 matchs Clash d'équipes avec au moins 3 joueurs de LaLiga titulaires, difficulté Semi-pro minimum.", "bojan_league_matches", 3, 25),
    (1704, "Maîtrise du championnat", "Gagnez 4 matchs Clash d'équipes avec au moins 5 joueurs de LaLiga titulaires, difficulté Semi-pro minimum.", "bojan_league_wins", 4, 25),
    (1705, "Bienvenue au Barça", "Terminez 2 matchs Clash d'équipes avec au moins 1 joueur du FC Barcelone titulaire, difficulté Semi-pro minimum.", "bojan_club_matches", 2, 25),
    (1706, "Les Blaugrana", "Gagnez 3 matchs Clash d'équipes avec au moins 2 joueurs du FC Barcelone titulaires, difficulté Semi-pro minimum.", "bojan_club_wins", 3, 25),
)


def match_increments(context, reason):
    if reason not in {"WIN", "DRAW", "LOSS"} or context.get("mode") != "squad_battles" or int(context.get("difficulty", -1)) < 2:
        return {}
    starters = context.get("starters", [])
    counts = {
        "nation": sum(player.get("nation") == 45 for player in starters),
        "league": sum(player.get("leagueId") == 53 for player in starters),
        "club": sum(player.get("teamid") == 241 for player in starters),
    }
    result = {}
    for kind, minimum in (("nation", 1), ("league", 3), ("club", 1)):
        if counts[kind] >= minimum:
            result[f"bojan_{kind}_matches"] = 1
        if reason == "WIN" and counts[kind] >= (5 if kind == "league" else 2):
            result[f"bojan_{kind}_wins"] = 1
    return result


def group(season, progress):
    return reward_group(season, progress, OBJECTIVES, BOJAN_ID, GROUP_ID, "bojanFlashbackClaimed",
                        "Flashback — Bojan",
                        "Terminez les six défis liés au FC Barcelone, à LaLiga et à l'Espagne pour gagner Bojan Flashback 83 AT invendable et 150 XP au total.", GROUP_ID)


def claim_group(season):
    return claim_reward_group(season, OBJECTIVES, BOJAN_ID, "bojanFlashbackClaimed")
