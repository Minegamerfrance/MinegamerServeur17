from __future__ import annotations

from typing import Any


def install(module: Any) -> None:
    if getattr(module, "_mng_draft_match_safety_installed", False):
        return
    module._mng_draft_match_safety_installed = True
    original_match = module._native_draft_match_response

    def draft_match(run: dict[str, Any]) -> dict[str, Any]:
        payload = original_match(run)
        squad = payload.get("squad")
        opponent = payload.get("opponentSquad")
        if not isinstance(squad, dict) or not isinstance(opponent, dict):
            return payload
        is_home = bool(payload.get("isHomeTeam", payload.get("home", True)))
        payload["home"] = payload["isHomeTeam"] = is_home
        squad["home"] = squad["isHomeTeam"] = is_home
        opponent["home"] = opponent["isHomeTeam"] = not is_home
        payload["homeSquad"] = squad if is_home else opponent
        payload["awaySquad"] = opponent if is_home else squad
        module.log.info(
            "DRAFT MATCH sides verified homeSquad=%s awaySquad=%s userHome=%s",
            payload["homeSquad"].get("id"), payload["awaySquad"].get("id"), is_home,
        )
        return payload

    module._native_draft_match_response = draft_match
