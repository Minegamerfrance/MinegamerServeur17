from __future__ import annotations

import copy
import json
from pathlib import Path


CARDS = tuple(json.loads((Path(__file__).parent / "assets/foundation/league-players.json").read_text(encoding="utf-8"))["cards"])
REWARD_IDS = {card["resourceId"] for card in CARDS}
TROSSARD_ID = 1426270781
TROSSARD_PRIME_ID = 1443047997
CLUB_NAMES = {1808: "Brighton & Hove Albion", 44: "Inter", 48: "Napoli", 31: "1. FC Köln", 483: "Villarreal CF", 1809: "Toulouse FC", 697: "LA Galaxy", 673: "KRC Genk", 232: "Standard de Liège", 247: "PSV", 246: "Feyenoord", 112678: "Atlético de San Luis", 1879: "América"}
LEAGUE_NAMES = {13: "Premier League", 31: "Serie A", 19: "Bundesliga", 53: "LaLiga", 16: "Ligue 1", 39: "Major League Soccer", 4: "Championnat belge", 10: "Eredivisie", 341: "Liga MX"}
NATION_NAMES = {7: "Belgique", 27: "Italie", 45: "Espagne", 163: "Japon", 36: "Norvège", 83: "Mexique", 13: "Danemark", 129: "Maroc", 34: "Pays-Bas", 52: "Argentine"}


def install_players(module):
    for card in CARDS:
        resource = card["resourceId"]
        asset = card["assetId"]
        existing = module.PLAYER_DB.get(resource)
        if existing and existing.get("assetId") != asset:
            raise ValueError("League Player reward resource collision")
        player = copy.deepcopy(module.PLAYER_DB[asset])
        player.pop("wefutCard", None)
        player["attributes"].update(card["attributes"])
        player.update(resourceId=resource, rating=card["rating"], face=list(card["face"]),
                      preferredPosition=card["position"], teamid=card["teamid"], teamName=CLUB_NAMES[card["teamid"]],
                      leagueId=card["leagueId"], leagueName=LEAGUE_NAMES[card["leagueId"]], nation=card["nation"],
                      rareflag=85, rarityName="Joueur de championnat", rarityClass="league_player", cardsubtypeid=0,
                      tier="gold", special=True, untradeable=True, packEligible=False, marketEligible=False,
                      dynamicPortrait=True, rewardEligible=True, obtainable=True, availability="foundation_objective",
                      objectiveSource=card["sourceUrl"])
        if asset == 206590:
            player.update(name="Moi Gómez", firstName="Moisés", lastName="Gómez Bordonado")
        if card.get("displayName"):
            player["name"] = card["displayName"]
        module.PLAYER_DB[resource] = player
