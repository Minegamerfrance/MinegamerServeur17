# Clashs d'équipes — suivi local

À partir de la version 1.8.63, la semaine se termine le dimanche à 10 h dans le fuseau Europe/Paris, heure d'été et heure d'hiver incluses. Les récompenses du palier atteint deviennent disponibles à la première connexion après cette échéance. Les récompenses non récupérées restent disponibles, même après plusieurs semaines. La migration du calendrier conserve les points et les résultats de la semaine en cours.

Le lancement d'un match transmet désormais le véritable identifiant de club adverse, au lieu de son numéro d'emplacement (qui pouvait valoir zéro). Le journal détaille la composition transmise pour diagnostiquer une éventuelle fermeture du jeu ; cette fermeture ne peut pas être attribuée avec certitude aux erreurs de connexion qui suivent dans le journal serveur.

La version 1.8.62 synchronise les résultats persistés avec le menu natif : points, palier, rang, rencontres restantes et adversaire déjà affronté. Les anciens identifiants d'adversaires sont migrés vers les quatre emplacements affichés, sans effacer les points ni les résultats existants.

À partir de la version 1.8.65, le top 100 ne contient plus de comptes LocalCPU. Les scores FIFA 20 sont envoyés au service MNG dédié avec la session vérifiée du lanceur ; le pseudo et l'identifiant sont issus du compte authentifié. Seuls les comptes ayant synchronisé leurs résultats apparaissent. La semaine précédente reste distincte. Les paliers et récompenses existants sont conservés ; un rang indisponible n'est pas inventé. Le premier compte vérifié lie le club à son pseudo pour empêcher l'envoi des scores sous un autre compte. Il s'agit de statistiques MNG, pas du classement EA ni d'une sauvegarde complète du club. Les rencontres ordinaires contre l'IA ne sont pas remplacées par des matchs en ligne.

Les requêtes de classement n'attendent pas le réseau : elles utilisent un cache actualisé en arrière-plan et après les sauvegardes des résultats. Sans session, ou avant le premier téléchargement de la semaine, la liste est vide plutôt que simulée. Une fermeture du jeu ne supprime pas les points locaux, qui restent disponibles pour une prochaine synchronisation.

L'écran général « Mon club → Classements » répond désormais HTTP 200 avec des options vides, au lieu de l'erreur HTTP 404 observée dans les journaux. Le contrat natif de cet écran reste à établir : ses catégories ne sont pas encore implémentées et la disparition du crash doit être vérifiée en jeu.

Le barème local des rencontres ordinaires tient compte du résultat, de la difficulté et des buts transmis au serveur (bonus/malus plafonné à cinq buts). Si le client ne transmet que le résultat, aucun score détaillé n'est inventé. La TOTW utilise les points fixes annoncés pour chaque difficulté. Les abandons et déconnexions donnent zéro point et zéro crédit, mais marquent l'adversaire comme affronté. Les premières 40 rencontres sont éligibles aux points.

Les nouvelles tentatives d'envoi d'un même résultat ne récompensent pas une seconde fois le match. Un adversaire déjà affronté ne redirige plus silencieusement vers une autre équipe. Le renouvellement des quatre adversaires reste une action distincte ; il ne réinitialise ni le classement ni le résultat de la TOTW. Un renouvellement ou un nouveau match pendant une rencontre est refusé.

La bannière TOTW utilise le PNG existant, au lieu du DDS employé par l'écran de chargement. La disparition effective de l'erreur DirectX doit être confirmée dans le jeu après mise à jour et redémarrage.
