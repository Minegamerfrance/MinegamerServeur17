# Joueurs de championnat — 1.8.51

- Falcao : SL League Player (86), puis SL League Upgrade (88).
- Trossard : PL League Player (85), puis PL League Upgrade (87).
- Politano : SA League Player (87, Inter), puis SA League Upgrade (89, Napoli).
- Verstraete : BL League Player (86), puis BL League Upgrade (88).
- Moi Gómez : LL League Player (86), puis LL League Upgrade (88).
- Shoji 86 et Gabrielsen 88 : deux groupes L1 League Player indépendants. Ce ne sont pas deux versions du même joueur.

Chaque défi rapporte 25 XP. Les groupes Baby et indépendants ont six défis. Les améliorations ont trois défis, sauf Falcao qui en a six. La carte Baby reste au club : elle n'est ni échangée ni consommée. L'amélioration se débloque après récupération de la récompense Baby, et ne progresse que dans les matchs commencés après ce déblocage, avec la version Baby exacte titulaire.

Les cinq groupes Upgrade sont visibles dès le départ, avec leur carte Prime en aperçu. Ils utilisent l'état SCMP natif 5 (verrouillé/cadenas) jusqu'à récupération de la Baby, puis l'état 1 (actif), 2 (récompense disponible) et 4 (récompense récupérée). Consulter les détails d'un groupe verrouillé est autorisé ; faire progresser ses défis ou réclamer ses récompenses reste bloqué côté serveur. La récupération des XP Baby seule ne suffit pas : il faut aussi récupérer la récompense du groupe. L'affichage du cadenas dans FIFA reste à confirmer après redémarrage.

Les défis personnalisés utilisent les Clash d'équipes : Semi-pro minimum pour la Baby, Professionnel minimum pour l'amélioration. Le serveur ne propose pas Rivals et ne valide pas encore les buts individuels, centres ou tirs en finesse. Les trois défis Trossard d'origine (6 victoires avec but de Trossard et 11 titulaires PL, 7 passes décisives sur centre, 3 buts en finesse) sont donc remplacés explicitement par :

1. Gagner 6 matchs avec Trossard 85 et 11 titulaires de Premier League.
2. Terminer 7 matchs avec Trossard 85 et au moins 2 titulaires de Brighton.
3. Gagner 3 matchs avec Trossard 85 et au moins 3 titulaires belges.

Ces trois défis donnent chacun 25 XP et un pack de deux joueurs Or rares invendables. Ils ne sont pas présentés comme une reproduction exacte des objectifs EA.

Les données des dix cartes FIFA 20 (faces, attributs détaillés, postes, pays, clubs) proviennent des fiches FUTWIZ référencées dans league-players.json, à partir de la liste demandée : https://www.futwiz.com/fifa20/players?page=0&release=objectiveplayer . Les portraits Trossard et Falcao fournis par l'utilisateur sont conservés sans retouche ; les autres portraits sont ceux liés par les fiches FUTWIZ. Les DDS natifs sont des conversions au format du jeu.

Les aperçus DCE de récompense joueur incluent désormais la carte complète sans créer d'élément possédé. Les récompenses pack et choix de joueurs gardent leur propre aperçu. L'affichage final dans FIFA doit être vérifié après redémarrage du serveur et du jeu.
