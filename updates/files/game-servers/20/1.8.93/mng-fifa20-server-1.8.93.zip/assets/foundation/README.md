# Fondation et DCE Joueur — serveur 1.8.50

## Fondation : Joueur de championnat — Falcao Baby

Falcao **86 BU**, Galatasaray, Süper Lig, Colombie. Statistiques de face :
**76 / 86 / 73 / 83 / 48 / 78**. Les attributs détaillés sont ajustés à partir
de sa carte normale FIFA 20 ; cette dernière reste inchangée. La rareté native
**85** utilise le fond Joueur de championnat vérifié dans les ressources FIFA 20.
Ce numéro est l'identifiant du fond, pas la note globale. La version 86 remplace
la version 85 avec la même identité de récompense et la nouvelle carte de référence.

Chaque objectif rapporte **25 XP**, soit **150 XP pour les six défis** :

| Défi | Condition en Clash d'équipes, difficulté Semi-pro minimum |
| --- | --- |
| Fierté colombienne | Terminer 2 matchs avec 1 Colombien titulaire minimum |
| Victoire des Cafeteros | Gagner 3 matchs avec 2 Colombiens titulaires minimum |
| Découverte de la Süper Lig | Terminer 3 matchs avec 3 joueurs de Süper Lig titulaires minimum |
| Maîtrise du championnat | Gagner 4 matchs avec 5 joueurs de Süper Lig titulaires minimum |
| Bienvenue à Galatasaray | Terminer 2 matchs avec 1 joueur de Galatasaray titulaire minimum |
| Les Lions d'Istanbul | Gagner 3 matchs avec 2 joueurs de Galatasaray titulaires minimum |

Les compositions sont prises au début du match à partir des exemplaires possédés.
Les remplaçants et joueurs concept ne comptent pas. Les victoires, nuls et défaites
comptent pour les matchs terminés ; abandon, difficulté inférieure et mode non
pris en charge ne comptent pas. Un résultat reçu plusieurs fois ne crédite pas
plusieurs fois les mêmes compteurs. Aucun but ou passe décisive non vérifiable
n'est inventé. Un même match peut avancer plusieurs objectifs.

Récupérer les six récompenses XP puis celle du groupe pour obtenir Falcao
**invendable**, placé dans les éléments non attribués. Attribution unique,
transactionnelle et protégée contre les clics simultanés. La progression est
conservée dans le passe de saison existant et ne se réinitialise pas chaque jour.
Les XP habituels de fin de match restent distincts des 150 XP des défis.

## Joueur : À surveiller — David Luiz

David Luiz **83 DC**, Arsenal, Premier League, Brésil. Statistiques :
**61 / 65 / 74 / 71 / 82 / 77** ; attributs détaillés de sa carte normale.

| DCE | Note min. | Collectif min. | Condition supplémentaire |
| --- | --- | --- | --- |
| Les Gunners | 80 | 80 | 1 joueur d'Arsenal minimum |
| La Seleção | 80 | 80 | 2 Brésiliens minimum |
| Premier League | 81 | 75 | 3 joueurs de Premier League minimum |
| De Chelsea à Arsenal | 81 | 75 | 1 joueur de chaque club minimum |
| Équipe compétitive | 82 | 70 | 5 joueurs rares minimum |
| À surveiller | 83 | 65 | 1 joueur de l'Équipe de la semaine minimum |

Chaque DCE demande **11 joueurs possédés**, définitivement échangés à la
soumission. La récompense du groupe est David Luiz OTW invendable, une seule
fois et uniquement après les six DCE. Aucun pack intermédiaire n'est promis.
Un redémarrage permet de récupérer une récompense validée mais interrompue
avant son attribution, sans doublon. Conditions, titres, résumés et la rubrique
**Joueur** sont en français ; les autres rubriques DCE sont aussi libellées en français.

## Cartes et vérification

Les cinq portraits dynamiques fournis sont convertis au format DDS natif,
sans génération ni retouche créative. Les PNG sources et cartes de référence
sont conservés à l'identique avec les définitions dans `catalog.json`.

Les cartes spéciales ne sont disponibles ni dans les packs, choix de joueur,
ni au marché. Les aperçus concept sont autorisés sans attribution. Leurs cartes
normales, les cinq cartes Histoire en réserve, les anciennes récompenses et les
données du compte sont conservées. Les quatre joueurs existent déjà dans les
effectifs natifs **2048**, qui restent inchangés.

Installer le serveur **1.8.50**, puis redémarrer serveur et jeu. Vérifier en jeu
les rubriques Fondation, One to Watch et Joueur, les portraits et les défis.
Les tests isolés vérifient les données, les routes et
les attributions ; le rendu client reste à confirmer.

## One to Watch : Ndombele puis Arnautović

Ndombele reste le premier groupe. Ses huit objectifs, récompenses et progression
existante sont conservés. Arnautović **82 BU** est le deuxième groupe avec sa
photo fournie et les statistiques **80 / 79 / 77 / 81 / 47 / 82**.

Ses huit défis donnent chacun **25 XP**, soit **200 XP** :

| Défi | Condition en Clash d'équipes, difficulté Semi-pro minimum |
| --- | --- |
| Bienvenue à Shanghai | Terminer 2 matchs avec 1 joueur de Shanghai SIPG titulaire minimum |
| Les Aigles rouges | Gagner 3 matchs avec 2 joueurs de Shanghai SIPG titulaires minimum |
| Découverte de la CSL | Terminer 3 matchs avec 3 joueurs de CSL titulaires minimum |
| Maîtrise du championnat | Gagner 4 matchs avec 5 joueurs de CSL titulaires minimum |
| Fierté autrichienne | Terminer 2 matchs avec 1 Autrichien titulaire minimum |
| Victoire de l'Autriche | Gagner 3 matchs avec 2 Autrichiens titulaires minimum |
| À la pointe | Terminer 3 matchs avec 1 joueur de poste d'origine BU titulaire minimum |
| Duo de buteurs | Gagner 4 matchs avec 2 joueurs de poste d'origine BU titulaires minimum |

Récupérer les huit récompenses XP, puis Arnautović invendable. Les conditions
utilisent la composition possédée au début du match, pas les remplaçants,
changements de poste ou données envoyées à la récupération de récompense.
Les résultats Clash d'équipes natifs, y compris l'équipe à l'affiche, sont suivis
directement : abandon et répétition d'un résultat ne donnent aucun progrès.

## Joueur : À surveiller — Jasper Cillessen

Cillessen **83 G**, Valence CF, LaLiga, Pays-Bas. Statistiques de gardien :
**82 DIV / 83 HAN / 78 KIC / 83 REF / 50 SPE / 81 POS**. Sa vitesse détaillée
est ajustée à 50 sans modifier sa carte normale.

| DCE | Note min. | Collectif min. | Condition supplémentaire |
| --- | --- | --- | --- |
| Bienvenue à Valence | 79 | 80 | 1 joueur de Valence CF minimum |
| Les Oranje | 80 | 75 | 2 Néerlandais minimum |
| LaLiga | 80 | 75 | 3 joueurs de LaLiga minimum |
| Équipe compétitive | 81 | 70 | 5 joueurs rares minimum |
| À surveiller | 82 | 65 | 1 joueur de l'Équipe de la semaine minimum |

Cinq équipes de 11 joueurs définitivement échangées, puis un seul Cillessen OTW
invendable. Même protection contre les doublons et exclusions de packs/marché
que David Luiz, sans récompense intermédiaire ni modification des autres DCE.

## Fondation : deuxième étape — Falcao Prime

La Baby reste **86 BU**, avec la même identité, photo et progression. Après
les six défis Baby, récupérez les six récompenses XP puis sa carte : cela
débloque le groupe **Falcao Prime** dans Fondation. Le groupe Prime n'est pas
publié au client tant que la Baby n'est pas récupérée ; toute demande anticipée
de détails, d'XP ou de récompense Prime est refusée par le serveur.

Falcao Prime **88 BU**, Galatasaray, Süper Lig, Colombie. Statistiques exactes :
**81 VIT / 88 TIR / 76 PAS / 85 DRI / 54 DÉF / 80 PHY**. Les attributs détaillés
sont ajustés depuis sa carte normale FIFA 20. La rareté native reste **85**
(fond Joueur de championnat) ; la nouvelle identité distingue bien les deux
versions sans remplacer la Baby. Photo : `falcao88.png`. Références fournies :
`FALCAO (8).png` avec les stats et `FALCAO (7).png` pour la disposition.

Les six nouveaux défis rapportent **25 XP chacun**, soit **150 XP** de plus.
Tous exigent **Falcao Baby 86 titulaire** en Clash d'équipes, difficulté
**Professionnel minimum** :

| Défi | Condition supplémentaire |
| --- | --- |
| L'héritage colombien | Terminer 4 matchs avec 2 Colombiens titulaires minimum |
| La force des Cafeteros | Gagner 5 matchs avec 3 Colombiens titulaires minimum |
| Les couleurs de la Süper Lig | Terminer 5 matchs avec 5 joueurs de Süper Lig titulaires minimum |
| Domination du championnat | Gagner 6 matchs avec 7 joueurs de Süper Lig titulaires minimum |
| Au cœur de Galatasaray | Terminer 4 matchs avec 2 joueurs de Galatasaray titulaires minimum |
| Le règne des Lions | Gagner 5 matchs avec 4 joueurs de Galatasaray titulaires minimum |

La progression Prime est distincte : seuls les matchs **commencés après** la
récupération Baby sont comptés. Un match déjà lancé au moment du déblocage ne
compte pas. La composition possédée et la bonne version de Falcao sont figées
au départ ; une Baby sur le banc, un Falcao régulier, la Prime, une carte concept
ou un champ de déblocage fourni par le client ne remplacent pas cette condition.
Les matchs à l'affiche sont pris en charge, les abandons et répétitions ignorés.

Après les six nouveaux défis, récupérez leurs XP puis la Prime **invendable**,
une seule fois, dans les éléments non attribués. **La Baby n'est pas échangée
ni supprimée.** Les comptes ayant déjà reçu la Baby avant cette mise à jour
débloqueront immédiatement le groupe Prime, sans refaire les anciens défis et
sans recevoir d'XP ou de progression Prime rétroactive. Les deux cartes restent
exclues des packs, choix de joueurs et marché ; leurs aperçus concept restent
consultables. Tester en jeu l'apparition du groupe après récupération Baby.
