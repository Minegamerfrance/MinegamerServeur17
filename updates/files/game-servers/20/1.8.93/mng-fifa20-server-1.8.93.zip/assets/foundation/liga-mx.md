# Liga MX — Fondation

Joaquín Laso 84, DC/CB, Atlético de San Luis, Argentine : six défis en
Clashs d'équipes, difficulté Semi-pro minimum, pour un total de 150 XP.
Statistiques fournies : 76 VIT, 49 TIR, 63 PAS, 66 DRI, 79 DÉF, 89 PHY.

Après récupération de Laso, le groupe Liga MX League Upgrade — Guillermo
Ochoa se débloque. Ses trois défis exigent Laso 84 titulaire et une difficulté
Professionnel minimum. Ils concernent la Liga MX, América et le Mexique.
Ils rapportent 75 XP puis Guillermo Ochoa 86, G/GK, América, Mexique :
85 PLG, 77 JMA, 83 DÉG, 89 RÉF, 58 VIT, 85 POS.

Les deux cartes sont invendables et disponibles uniquement via les objectifs.
Laso reste au club après récupération d'Ochoa. Les portraits et références
PNG fournis sont conservés sans modification ; les portraits natifs DDS sont
convertis au format attendu par le jeu. Les attributs détaillés sont ajustés
depuis les fiches locales pour reproduire les six statistiques fournies,
sans prétendre à des sous-statistiques officielles EA. Ochoa utilise les
attributs de gardien, et non ceux d'un joueur de champ.
