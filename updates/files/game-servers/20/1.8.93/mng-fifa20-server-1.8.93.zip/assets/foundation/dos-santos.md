# MLS — Jonathan dos Santos

Deux cartes Fondation à LA Galaxy, Mexique, invendables et exclues des packs et du marché :

- MLS League Player — Dos Santos : 84 MC, 78 / 76 / 84 / 84 / 74 / 76.
- MLS League Upgrade — Dos Santos : 87 MOC, 83 / 80 / 87 / 87 / 79 / 82.

Les notes, postes et portraits proviennent des quatre images fournies. Les attributs détaillés sont adaptés à partir de la carte de base pour correspondre à ces six statistiques, et ne sont pas présentés comme les sous-statistiques officielles d'une carte EA.

Le groupe 84 suit les six conditions des autres League Players : matchs/victoires avec des titulaires mexicains, MLS et LA Galaxy, en Clashs d'équipes Semi-pro minimum (150 XP). Le groupe 87 suit les trois conditions League Upgrade : 6 victoires avec 11 MLS, 7 matchs avec 2 LA Galaxy, 3 victoires avec 3 Mexicains, Professionnel minimum (75 XP).

L'upgrade est verrouillée jusqu'à récupération de la 84 et exige cette carte titulaire pendant les matchs. La 84 est conservée après obtention de la 87.
