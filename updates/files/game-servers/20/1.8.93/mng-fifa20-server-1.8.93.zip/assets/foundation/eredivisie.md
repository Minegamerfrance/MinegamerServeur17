# Eredivisie — Fondation

Ibrahim Afellay 84, AG/LW, PSV, Pays-Bas : six défis en Clashs d'équipes,
difficulté Semi-pro minimum, pour un total de 150 XP.
Statistiques fournies : 87 VIT, 78 TIR, 81 PAS, 86 DRI, 62 DÉF, 66 PHY.

Après récupération d'Afellay, le groupe Eredivisie League Upgrade — Leroy Fer
se débloque. Ses trois défis exigent Afellay 84 titulaire et une difficulté
Professionnel minimum. Ils concernent l'Eredivisie, Feyenoord et les Pays-Bas.
Ils rapportent 75 XP puis Leroy Fer 86, MDC/CDM, Feyenoord, Pays-Bas :
75 VIT, 77 TIR, 80 PAS, 82 DRI, 82 DÉF, 90 PHY.

Les deux cartes sont invendables et disponibles uniquement via les objectifs.
Afellay reste au club après récupération de Fer. Les portraits et références
PNG fournis sont conservés sans modification ; les portraits natifs DDS sont
convertis au format attendu par le jeu. Les attributs détaillés sont ajustés
depuis les fiches locales pour reproduire les six statistiques fournies,
sans prétendre à des sous-statistiques officielles EA.
