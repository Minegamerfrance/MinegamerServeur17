# Championnat belge — Fondation

Mæhle 84, DD/RB, KRC Genk, Danemark : six défis de championnat en Clashs
d'équipes, difficulté Semi-pro minimum, pour un total de 150 XP.
Statistiques fournies : 93 VIT, 66 TIR, 74 PAS, 78 DRI, 81 DÉF, 84 PHY.

Après récupération de Mæhle, le groupe BEL League Upgrade — Carcela-González
se débloque. Ses trois défis exigent Mæhle 84 titulaire et une difficulté
Professionnel minimum. Ils concernent le championnat belge, le Standard de
Liège et le Maroc. Ils rapportent 75 XP puis Carcela-González 86, MOC/CAM,
Standard de Liège, Maroc : 88 VIT, 84 TIR, 84 PAS, 88 DRI, 46 DÉF, 70 PHY.

Les deux récompenses sont invendables, disponibles uniquement via les objectifs.
La carte Mæhle reste au club après obtention de Carcela-González.
Les portraits et références PNG fournis sont conservés sans modification ; seuls
les portraits natifs DDS sont convertis au format attendu par le jeu.
Les attributs détaillés sont ajustés depuis les fiches locales pour reproduire les
six statistiques fournies, sans prétendre à des sous-statistiques officielles EA.
