# Identité native Alex Hunter — effectifs 2050

La version 2050 ajoute le joueur natif 26501 avec les références de noms FUT Alex / Hunter et son lien à Manchester United. La carte spéciale et son portrait restent inchangés. Le serveur annonce la mise à jour des effectifs à l'entrée FUT; acceptez-la dans le jeu. Le téléchargement est vérifié, l'application en jeu doit être confirmée après installation. Tous les joueurs et données de compte déjà présents sont conservés.

# Effectifs FUT FIFA 20 — version 1.8.61

## Identités et recherche des icônes — effectifs 2049

Les effectifs 2049 conservent Adil Rami et ajoutent quatre identités natives de
recherche pour les versions Mid et Prime de Robben et Juninho. Chaque icône
dispose désormais de trois fiches de recherche notées 86, 88 et 90. Les six
identifiants de cartes du serveur, les cartes possédées et leurs portraits sont
inchangés. Les nouveaux identifiants natifs sont 500001 à 500004.

Le serveur annonce cette mise à jour à chaque connexion. Les anciens marqueurs
de téléchargement ne la désactivent plus : avoir reçu le manifeste ne prouve
pas que le jeu a installé les effectifs. Le jeu compare sa version locale à
2049. Acceptez sa proposition de mise à jour des joueurs après redémarrage.
L'application effective dans FIFA doit encore être vérifiée en jeu.

## Correctif Adil Rami — effectifs 2048

La carte normale 78 DC existait dans le catalogue serveur, mais son joueur
**183280** manquait dans les deux bases natives vérifiées et dans les effectifs
2046. Le jeu affichait donc la fiche de repli de Ryan Allsop, y compris sur la
carte Histoire 84. La version 2048 ajoute une fiche physique pour Adil Rami,
avec les références de noms du dictionnaire FUT : Adil, Rami et nom de maillot
Rami. Aucun ancien joueur n'est remplacé.

- Carte normale **78 DC** : **47 / 48 / 53 / 60 / 76 / 81**, attributs détaillés
  du catalogue FIFA 20, Fenerbahçe **326**, Süper Lig **68**, France **18**.
- Biographie : **27/12/1985**, **190 cm**, **90 kg**, droitier, **2 étoiles**
  techniques, **3 étoiles** mauvais pied, contributions moyennes/moyennes.
- Un seul joueur et un seul lien au club sont ajoutés. Les **22 694** fiches
  natives de 2046, tous leurs noms et liens restent strictement identiques.
- La carte Histoire **50514928**, note **84**, portrait et statistiques propres
  reste la même récompense exclusive. Les deux cartes partagent désormais la
  bonne identité native. La normale est disponible normalement et au marché.
- Portrait normal DDS repris à l'identique des ressources FIFA 20. Aucune tête
  3D ajoutée : repli générique natif, comme pour les ajouts précédents.

Fermer le jeu, installer le serveur **1.8.48**, redémarrer serveur et jeu, puis
accepter la mise à jour des effectifs dans FUT. Vérifier les deux cartes Rami,
leur nom et biographie ainsi que les recherches de joueurs concept. Les tests
servent des données valides ; l'application et le rendu en jeu restent à confirmer.
Ne pas supprimer de sauvegardes.

L'annonce dure une session. Le nouveau marqueur est
`runtime/data/roster-update-test-1.8.48.done` ; les anciens marqueurs ne bloquent
pas 2048. En cas d'échec, annuler et redémarrer serveur et jeu pour désactiver
l'annonce. Cela ne supprime pas les effectifs déjà acceptés.

## Historique conservé — effectifs 2046

Les versions 1.8.42 et 1.8.43 reprenaient les joueurs du mode classique : la traduction des références de noms corrigeait les noms courants, mais conservait les mauvaises notes et excluait les icônes. La version 1.8.44 a rétabli les joueurs FUT. Il manquait cependant le club des icônes, sa ligue et leurs liens : les détails de Ballack affichaient `undefined` et `*LeagueName_0`. La version 1.8.45 rétablit ces dépendances natives, sans utiliser Frosty Mod Manager pour lancer le jeu.

- Effectifs natifs **2046**, supérieurs aux versions précédentes pour remplacer leur téléchargement. Serveur **1.8.46**.
- **Robben et Juninho personnalisés** : leurs cartes existaient uniquement dans le serveur, sans fiche physique dans les effectifs FIFA 20. Le jeu affichait donc une identité vide et des données de gardien de repli. Deux fiches natives sont ajoutées, avec les identifiants existants **9014** et **30**, sans renommer ou remplacer les cartes déjà possédées.
- Prénoms, noms, surnoms, dates de naissance, tailles, poids, nationalités, pieds préférés, étoiles, postes de champ, attributs de base et appartenance au club Icons proviennent des définitions personnalisées déjà installées. Les **six variantes 86/88/90** gardent leurs identifiants, notes, portraits et données serveur propres. Les variantes partagent la fiche native de leur joueur, comme les autres cartes spéciales ; le détail des variantes en jeu reste à vérifier.
- Aucune nouvelle tête 3D n'est installée : les modèles utilisent le repli générique natif. Les portraits des cartes ne changent pas. Ce correctif concerne l'identité, la biographie et les attributs, pas la création de nouveaux modèles de visage.
- Club des icônes **112658**, ligue **2118**, lien club–ligue et **267 liens joueur–club** rétablis depuis la base FUT originale. Ils couvrent les 89 icônes du catalogue et leurs versions natives. Le libellé de repli est `Icons`, identique au catalogue serveur, au lieu des noms techniques internes de la base. Les clés des nouveaux liens sont uniques et ne remplacent pas les liens existants.
- **18 804 fiches FUT** copiées intégralement depuis la base FIFA 20 vérifiée : notes, attributs, identités et apparences. Lewandowski retrouve sa note de base **89**, au lieu des 91 du mode classique.
- **2 647 fiches natives manquantes** sont réintroduites, dont les **89 icônes** du catalogue serveur, avec leurs prénoms et noms. Les variantes de cartes conservent leurs données serveur propres.
- **129 cartes de base supplémentaires**, absentes de la base FUT mais présentes dans les effectifs classiques, reprennent leur note du catalogue FUT. Seuls les attributs connus et non nuls sont repris. Pour **46 anciennes cartes** absentes des deux bases natives, aucune fiche physique ou statistique n'est inventée : leurs données serveur sont conservées. Leurs identifiants sont recensés dans le fichier de contrôle.
- Les **22 692 fiches natives déjà présentes** restent strictement identiques. Seules les deux fiches personnalisées, deux liens au club Icons, deux noms dynamiques et la version des effectifs sont ajoutés. Les autres clubs, ligues et liens, les objectifs, les récompenses et les données du compte sont inchangés.
- Les 47 tables natives, les en-têtes, l'index, les lignes et le contrôle natif d'effectifs sont vérifiés. Aucun fichier du jeu ou aucune sauvegarde n'est modifié par la préparation. Le jeu gère lui-même l'installation des effectifs téléchargés.

## Essai en jeu

Fermer le jeu, installer la version du serveur, puis redémarrer le serveur et FIFA 20. Entrer dans Ultimate Team et accepter la nouvelle mise à jour. Vérifier Robben et Juninho sur les trois onglets : noms présents, biographie correcte, quatre étoiles de gestes techniques, Robben gaucher, Club et Ligue Icons, détail des attributs de joueur de champ au lieu de gardien. Vérifier également les variantes 86/88/90 et les noms et notes des anciens joueurs. Les données, le téléchargement et la conservation du contenu serveur sont testés ; leur rendu en jeu reste à confirmer. Ne pas supprimer les sauvegardes.

Le test est annoncé durant une seule session serveur. Après la première demande du manifeste, `runtime/data/roster-update-test-1.8.46.done` empêche une nouvelle annonce au prochain démarrage du serveur. Les marqueurs précédents ne bloquent pas 2046. En cas d'échec, annuler puis redémarrer **le serveur et le jeu** pour revenir à l'entrée FUT sans demande forcée. Ce mécanisme désactive l'annonce ; il ne supprime pas des effectifs déjà acceptés par le jeu.

Pour réarmer volontairement le test, arrêter le serveur puis retirer uniquement ce marqueur, avant de redémarrer le serveur et le jeu. Les marqueurs et sauvegardes ne font pas partie du paquet distribué.
