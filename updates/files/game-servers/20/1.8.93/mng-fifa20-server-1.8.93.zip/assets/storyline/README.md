# Cartes Histoire en réserve — 1.8.48

Ces cinq cartes existent uniquement dans le catalogue serveur. Elles ne sont pas
obtenables : aucun pack, choix de joueur, marché, DCE, objectif ou attribution.
La création d'un exemplaire est bloquée tant que leur disponibilité n'est pas
explicitement activée dans une prochaine version.

Les aperçus des joueurs concept restent autorisés : afficher une carte ou l'utiliser
dans une équipe concept ne crée aucun exemplaire possédé. Le blocage s'applique à
la création persistante d'un joueur, pas à la construction de son aperçu. Cela
corrige l'erreur serveur 500 de la version 1.8.47 lors des recherches concept.

| Joueur | Identifiant de carte | Note | Poste | Statistiques de face |
| --- | --- | --- | --- | --- |
| Beasley | 50371034 | 83 | MG | 88 / 74 / 76 / 84 / 80 / 76 |
| El Shaarawy | 50522461 | 85 | AG | 91 / 83 / 82 / 89 / 45 / 67 |
| Casillas | 50337127 | 85 | G | 87 / 80 / 66 / 86 / 57 / 88 |
| Pepe | 50452181 | 86 | DC | 73 / 56 / 61 / 66 / 87 / 87 |
| Nasri | 50496887 | 84 | MOC | 80 / 81 / 83 / 85 / 42 / 64 |

Ordre joueurs de champ : vitesse, tirs, passes, dribbles, défense, physique.
Ordre gardien : plongeon, mains, dégagement, réflexes, vitesse, placement.
Les attributs détaillés conservent le profil des cartes normales FIFA 20, avec
des ajustements par groupe pour correspondre aux statistiques fournies.
Les noms, clubs, nations, pieds, étoiles et biographies proviennent des versions
normales. Beasley change de DG à MG sur sa version Histoire uniquement.

`storyline_catalog.py` installe les variantes au démarrage dans `PLAYER_DB`.
`catalog.json` conserve leurs définitions et attributs détaillés ; les PNG
conservent les cartes de référence et les cinq portraits fournis par l'utilisateur.
Les portraits DDS utilisent le format natif des cartes Histoire existantes.
Les cinq cartes normales correspondantes restent inchangées. La mise à jour
native 2048 ajoute uniquement la fiche manquante d'Adil Rami, indépendamment
de ces cinq cartes Histoire en réserve.
