# Serveur FIFA 20 v1.8.74

Ajoute le DCE POTM Teemu Pukki 84 : deux défis reprenant les exigences des
captures, un Premium Gold Pack pour chaque défi terminé et Pukki comme
récompense du groupe. Les trois badges et le portrait Pukki viennent des
fichiers fournis ou installés par l'utilisateur. Le portrait personnalisé
`p50522010.png` fourni par l'utilisateur est converti en texture du joueur.

L'écusson Flashback de la version 1.8.70 reste actif. Le chargement du
catalogue EAS FC reste à diagnostiquer.

Les titres et résumés des DCE POTM Josef Martinez et Teemu Pukki sont
localisés en français ou en anglais selon la langue envoyée par le client.
Le badge fourni pour les DCE OTW est appliqué aux sets récompensant une carte
OTW.

Ajoute aussi le DCE POTM Bundesliga Robert Lewandowski 90, avec trois défis
reprenant les exigences et packs des captures, ses badges et son portrait.
La rareté POTM de Lewandowski utilise l'identifiant 42; celle de Pukki utilise
l'identifiant 43.

## Notes historiques sur le catalogue EAS FC

Le client demande `/pow/store/game/fifa20/catalog/list` lorsqu’il ouvre
le catalogue EAS FC. Le serveur renvoyait deux catalogues « FUT Store »
et « FIFAPoints », et `{}` pour les informations de niveau.

L’overlay `easfc_catalog.py` reprend le format de listes et de niveaux
du serveur FIFA 17 pour une première vérification dans FIFA 20.
Les champs affichés par POWCatalogue et POWExperience ont été contrôlés
dans les fichiers BIG de l’export Frosty fourni par l’utilisateur.

Ce n’est pas encore un catalogue complet ni un protocole FIFA 20 validé.
Les listes d’articles, de cadeaux et d’inventaire sont explicitement vides.
Aucun bonus fictif, achat, ancien niveau ou solde n’est attribué.
Les crédits et l’XP FUT ne sont ni lus ni modifiés par cet overlay.

Le profil EAS FC, s’il existe, est lu depuis
`runtime/data/easfc-profile.json`, jamais réinitialisé. En son absence,
le démarrage provisoire utilise niveau 1, XP 0 et intervalle 0–1000.
Ces valeurs ne prétendent pas restaurer un ancien profil EA ni reproduire
la table complète officielle des niveaux.

Prochaine vérification : redémarrer le serveur et le jeu, ouvrir le panier,
contrôler l’écran et les requêtes `/pow/` suivantes. Ne pas publier
ce prototype comme un catalogue complet avant cette validation.
