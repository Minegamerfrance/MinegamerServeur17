import copy

from storyline_catalog import ATTRIBUTE_GROUPS, _adjust_group


ASSET_ID = 188545
RESOURCE_ID = ASSET_ID + 4 * 16777216
SET_ID = 57
CHALLENGE_IMAGES = {
    5701: "400056-84b35551-f466",
    5702: "100063-9029001e-9afc",
    5703: "330005-fb83431f-9d46",
}


def install_player(module):
    existing = module.PLAYER_DB.get(RESOURCE_ID)
    if existing and existing.get("assetId") != ASSET_ID:
        raise ValueError("Lewandowski POTM resource collision")
    base = module.PLAYER_DB[ASSET_ID]
    player = copy.deepcopy(base)
    face = [78, 89, 77, 86, 42, 83]
    for target, weights in zip(face, ATTRIBUTE_GROUPS):
        _adjust_group(player["attributes"], weights, target)
    player["attributes"]["composure"] = min(99, base["attributes"]["composure"] + face[3] - base["face"][3])
    player.pop("wefutCard", None)
    player.update(resourceId=RESOURCE_ID, rating=90, face=face, preferredPosition="ST",
                  rareflag=42, rarityName="POTM Bundesliga", rarityClass="potm_bundesliga",
                  cardsubtypeid=0, tier="gold", special=True, untradeable=True,
                  packEligible=False, marketEligible=False, dynamicPortrait=True,
                  rewardEligible=True, obtainable=True, availability="player_sbc")
    module.PLAYER_DB[RESOURCE_ID] = player


def sbc():
    challenges = [
        {
            "challenge_id": 5701,
            "name": "Bundesliga",
            "description": "Exchange a squad featuring Bundesliga players",
            "players": 11,
            "formation": "f442",
            "rules": [
                {"kind": "player_count", "value": 11, "scope": "exact", "count": -1,
                 "text": "# of players in the Squad: 11"},
                {"kind": "league_players", "value": 19, "scope": "min", "count": 1,
                 "text": "# of players from Bundesliga: Min 1"},
                {"kind": "team_rating", "value": 84, "scope": "min", "count": -1,
                 "text": "Squad Rating: Min 84"},
                {"kind": "chemistry", "value": 75, "scope": "min", "count": -1,
                 "text": "Squad Total Chemistry Points: Min 75"},
            ],
            "awards": [{"type": "PACK", "pack_id": 1040, "count": 1}],
        },
        {
            "challenge_id": 5702,
            "name": "Germany",
            "description": "Exchange a Squad featuring players from Germany",
            "players": 11,
            "formation": "f442",
            "rules": [
                {"kind": "player_count", "value": 11, "scope": "exact", "count": -1,
                 "text": "# of players in the Squad: 11"},
                {"kind": "nation_players", "value": 14, "scope": "min", "count": 1,
                 "text": "# of players from Germany: Min 1"},
                {"kind": "team_rating", "value": 85, "scope": "min", "count": -1,
                 "text": "Squad Rating: Min 85"},
                {"kind": "chemistry", "value": 70, "scope": "min", "count": -1,
                 "text": "Squad Total Chemistry Points: Min 70"},
            ],
            "awards": [{"type": "PACK", "pack_id": 1017, "count": 1}],
        },
        {
            "challenge_id": 5703,
            "name": "85-Rated Squad",
            "description": "Exchange an 85 Rated Squad",
            "players": 11,
            "formation": "f442",
            "rules": [
                {"kind": "player_count", "value": 11, "scope": "exact", "count": -1,
                 "text": "# of players in the Squad: 11"},
                {"kind": "totw_count", "value": 3, "scope": "min", "count": 2,
                 "text": "IF Players: Min 2"},
                {"kind": "team_rating", "value": 85, "scope": "min", "count": -1,
                 "text": "Squad Rating: Min 85"},
                {"kind": "chemistry", "value": 65, "scope": "min", "count": -1,
                 "text": "Squad Total Chemistry Points: Min 65"},
            ],
            "awards": [{"type": "PACK", "pack_id": 1041, "count": 1}],
        },
    ]
    return {
        "set_id": SET_ID,
        "category_id": 4,
        "category": "Joueur",
        "priority": 7,
        "name": "Robert Lewandowski",
        "description": "Earn Robert Lewandowski, Bundesliga Player of the Month.",
        "repeatable": False,
        "awards": [{"type": "PLAYER", "value": RESOURCE_ID, "count": 1}],
        "challenges": challenges,
    }
