from __future__ import annotations

import copy
import json
from typing import Any

from otw_rewards import next_item_id, persist_item


ICON_MAX_85_PACK_ID = 1043
OTW_GUARANTEED_PACK_ID = 1044
OTW_MAX_85_PACK_ID = 1045
PACKS = {
    ICON_MAX_85_PACK_ID: {
        "name": "Pack Icône 85 max",
        "bio": "Une Icône aléatoire avec une note générale maximale de 85.",
    },
    OTW_GUARANTEED_PACK_ID: {
        "name": "Pack OTW garanti",
        "bio": "Un élément spécial OTW garanti.",
    },
    OTW_MAX_85_PACK_ID: {
        "name": "Pack OTW 85 max garanti",
        "bio": "Un élément OTW garanti avec une note générale maximale de 85.",
    },
}


def _eligible(module: Any, pack_id: int) -> list[int]:
    pool = []
    for resource, player in module.PLAYER_DB.items():
        rarity = str(player.get("rarityClass", "")).lower()
        if not module._player_is_pack_safe(player):
            continue
        if module._player_is_excluded_from_packs(resource, player):
            continue
        if player.get("obtainable") is False or player.get("packEligible") is False:
            continue
        if pack_id == ICON_MAX_85_PACK_ID:
            if int(player.get("rareflag", -1)) != 12 or int(player.get("rating", 0)) > 85:
                continue
            if rarity not in {"legend", "icon"}:
                continue
        else:
            if int(player.get("rareflag", -1)) != 21 or rarity not in {"otw", "ones_to_watch"}:
                continue
            if player.get("availability") == "season_pass":
                continue
            if pack_id == OTW_MAX_85_PACK_ID and not 1 <= int(player.get("rating", 0)) <= 85:
                continue
        pool.append(int(resource))
    return pool


def install(module: Any) -> None:
    if getattr(module, "_mng_season_pass_custom_packs_installed", False):
        return
    module._mng_season_pass_custom_packs_installed = True
    original_load = module.load_pack_settings
    original_create = module.State.create_pack
    otw_ids = {int(resource) for resource, player in module.PLAYER_DB.items()
               if int(player.get("rareflag", -1)) == 21
               and str(player.get("rarityClass", "")).lower() in {"otw", "ones_to_watch"}
               and player.get("availability") != "season_pass"}

    def settings():
        result = copy.deepcopy(original_load())
        for pack_id, details in PACKS.items():
            result["packs"][str(pack_id)] = dict(
                details, size=1, rare_slots=1, gold_weight=100, silver_weight=0,
                bronze_weight=0, special_chance=0, guaranteed_specials=0,
                enabled=False, reward_only=True, price=0, pack_asset_id=4,
                content_type="players",
            )
        result["next_pack_id"] = max(int(result.get("next_pack_id", 0)), max(PACKS) + 1)
        return result

    def create_pack(state, pack_id=1):
        pack_id = int(pack_id)
        if pack_id not in PACKS:
            return original_create(state, pack_id)
        pool = _eligible(module, pack_id)
        if not pool:
            raise ValueError("SEASON_PASS_GUARANTEED_PACK_POOL_EMPTY")
        resource = module.random.choice(pool)
        with state.lock:
            state.conn.execute("BEGIN IMMEDIATE")
            try:
                cursor = state.conn.cursor()
                item_id = next_item_id(cursor)
                item = state.build_player_item(resource, item_id, "unassigned")
                item.update(untradeable=True, discardValue=0)
                owned = cursor.execute(
                    "SELECT id FROM items WHERE resource_id=? AND pile IN ('club','squad') LIMIT 1",
                    (resource,),
                ).fetchone()
                duplicates = []
                if owned:
                    item["duplicateId"] = int(owned[0])
                    duplicates.append({"itemId": item_id, "duplicateItemId": int(owned[0])})
                persist_item(cursor, item)
                state.conn.commit()
            except Exception:
                state.conn.rollback()
                raise
        return {"packId": pack_id, "purchasedPackId": pack_id, "packType": "CUSTOM_PACK",
                "itemList": [item], "itemData": [item], "items": [item], "newcards": 1,
                "numberItems": 1, "duplicateItemIdList": duplicates, "credits": state.credits()}

    module.load_pack_settings = settings
    module.State.create_pack = create_pack

