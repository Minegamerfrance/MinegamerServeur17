from __future__ import annotations

import copy
from typing import Any


HUNTER_ASSET_ID = 26501
HUNTER_RESOURCE_ID = HUNTER_ASSET_ID + 91 * 16777216
HUNTER_LEVEL = 5
HUNTER_REFERENCE_ID = 211300
HUNTER_FACE = [80, 82, 70, 78, 52, 75]
HUNTER_ATTRIBUTES = {
    "acceleration": 79, "sprintSpeed": 81, "positioning": 82, "finishing": 82,
    "shotPower": 83, "longShots": 80, "volleys": 86, "penalties": 89,
    "vision": 70, "crossing": 62, "freeKickAccuracy": 80, "shortPassing": 75,
    "longPassing": 65, "curve": 74, "agility": 74, "balance": 79,
    "reactions": 79, "ballControl": 80, "dribbling": 78, "composure": 0,
    "interceptions": 57, "headingAccuracy": 80, "marking": 35,
    "standingTackle": 53, "slidingTackle": 48, "jumping": 72, "stamina": 86,
    "strength": 72, "aggression": 71,
}


def install(module: Any) -> None:
    existing = module.PLAYER_DB.get(HUNTER_RESOURCE_ID)
    if existing and (existing.get("assetId") != HUNTER_ASSET_ID
                     or existing.get("rarityClass") != "season_reward"):
        raise ValueError(f"Alex Hunter resource collision: {HUNTER_RESOURCE_ID}")
    template = module.PLAYER_DB.get(HUNTER_REFERENCE_ID)
    if template is None:
        raise ValueError(f"Alex Hunter player template missing: {HUNTER_REFERENCE_ID}")
    player = copy.deepcopy(template)
    player["attributes"].update(HUNTER_ATTRIBUTES)
    player.update({
        "name": "Hunter", "firstName": "Alex", "lastName": "Hunter",
        "commonName": "Alex Hunter", "assetId": HUNTER_ASSET_ID,
        "resourceId": HUNTER_RESOURCE_ID, "rating": 82,
        "preferredPosition": "ST", "teamid": 11, "teamName": "Manchester United",
        "leagueId": 13, "leagueName": "England Premier League (1)",
        "nation": 14, "nationName": "England", "height": 180, "weight": 75,
        "preferredFoot": "Right", "skillMoves": 3, "weakFoot": 3,
        "workRateAttack": "High", "workRateDefense": "Low",
        "face": list(HUNTER_FACE), "rareflag": 91,
        "rarityName": "Season Reward", "rarityClass": "season_reward",
        "cardsubtypeid": 0, "tier": "gold", "special": True,
        "untradeable": True, "packEligible": False, "marketEligible": False,
        "rewardEligible": True, "obtainable": True, "availability": "season_pass",
        "baseResourceId": HUNTER_ASSET_ID, "dynamicPortrait": True,
        "seasonPassLevel": HUNTER_LEVEL,
    })
    module.PLAYER_DB[HUNTER_RESOURCE_ID] = player
