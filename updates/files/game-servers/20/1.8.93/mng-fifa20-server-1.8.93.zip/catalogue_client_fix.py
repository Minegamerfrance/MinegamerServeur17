import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path


ORIGINAL_SHA256 = "6e9ebed6160d4a1121eaf13b952f0afc4b74ab2044120021bf9880c68a781eb6"
PATCH_OFFSET = 354089
ORIGINAL_BRANCH = bytes.fromhex("0f855c010000")
REPLACEMENT = b"\x90" * 6


def game_running():
    if os.name != "nt":
        return False
    result = subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-Command",
         "if (Get-Process FIFA20 -ErrorAction SilentlyContinue) { exit 1 } else { exit 0 }"],
        capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=15)
    if result.returncode not in {0, 1}:
        raise RuntimeError("Cannot safely determine FIFA process state")
    return result.returncode == 1


def patched_bytes(original):
    if hashlib.sha256(original).hexdigest() != ORIGINAL_SHA256:
        raise ValueError("Unsupported FIFA catalogue library; no changes made")
    if original[PATCH_OFFSET:PATCH_OFFSET + 6] != ORIGINAL_BRANCH:
        raise ValueError("Catalogue ownership filter signature mismatch")
    return original[:PATCH_OFFSET] + REPLACEMENT + original[PATCH_OFFSET + 6:]


def install(runtime_root):
    root = Path(runtime_root)
    config = root / "data/catalogue-client-fix.json"
    if not config.is_file():
        return "not_configured"
    settings = json.loads(config.read_text(encoding="utf-8"))
    target = Path(settings["libraryPath"]).resolve()
    if target.name != "powdll_Win64_retail.dll" or not (target.parent / "FIFA20.exe").is_file():
        raise ValueError("Invalid FIFA catalogue library location")
    data = target.read_bytes()
    current = hashlib.sha256(data).hexdigest()
    if current == settings["patchedSha256"]:
        return "already_installed"
    replacement = patched_bytes(data)
    if hashlib.sha256(replacement).hexdigest() != settings["patchedSha256"]:
        raise ValueError("Prepared catalogue fix checksum mismatch")
    if game_running():
        return "pending_game_exit"
    backup = root / "data/native-catalogue-backups" / (ORIGINAL_SHA256 + ".dll")
    backup.parent.mkdir(parents=True, exist_ok=True)
    if backup.exists() and hashlib.sha256(backup.read_bytes()).hexdigest() != ORIGINAL_SHA256:
        raise ValueError("Catalogue backup integrity mismatch")
    if not backup.exists():
        backup.write_bytes(data)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix=".mng-catalogue-", suffix=".tmp", delete=False) as output:
            temporary = Path(output.name)
            output.write(replacement)
            output.flush()
            os.fsync(output.fileno())
        if game_running():
            return "pending_game_exit"
        os.replace(temporary, target)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    if hashlib.sha256(target.read_bytes()).hexdigest() != settings["patchedSha256"]:
        raise ValueError("Installed catalogue fix verification failed")
    return "installed"
