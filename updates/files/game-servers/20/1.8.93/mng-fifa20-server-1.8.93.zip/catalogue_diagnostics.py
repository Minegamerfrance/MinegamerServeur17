from __future__ import annotations

import json
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlsplit


MAX_BYTES = 2 * 1024 * 1024


def shape(value, depth=0):
    if depth >= 4:
        return type(value).__name__
    if isinstance(value, dict):
        return {str(key)[:80]: shape(child, depth + 1) for key, child in list(value.items())[:40]}
    if isinstance(value, list):
        return {"type": "list", "count": len(value), "sampleShape": shape(value[0], depth + 1) if value else None}
    if value is None:
        return "null"
    return type(value).__name__


def document_shape(data):
    if len(data) > MAX_BYTES:
        return {"type": "large-body", "bytes": len(data)}
    try:
        value = json.loads(data)
    except (ValueError, UnicodeDecodeError):
        return {"type": "non-json", "bytes": len(data)}
    return {"shape": shape(value), "empty": value in ({}, [], None)}


def install(module):
    if getattr(module, "_mng_catalogue_diagnostics_installed", False):
        return
    module._mng_catalogue_diagnostics_installed = True
    original = module.route_fut
    config = Path(module.RUNTIME_ROOT) / "data/catalogue-diagnostic.json"
    destination = Path(module.RUNTIME_ROOT) / "logs/catalogue-diagnostic.jsonl"
    lock = threading.Lock()

    def record(entry):
        try:
            if not config.exists() or json.loads(config.read_text(encoding="utf-8-sig")).get("enabled") is not True:
                return
            with lock:
                destination.parent.mkdir(parents=True, exist_ok=True)
                if destination.exists() and destination.stat().st_size >= MAX_BYTES:
                    destination.replace(destination.with_suffix(".previous.jsonl"))
                with destination.open("a", encoding="utf-8") as handle:
                    handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            module.log.exception("Catalogue diagnostic write failed; normal response preserved")

    def route(method, raw_path, headers, body):
        normalized = raw_path[1:] if raw_path.startswith("//pow/") else raw_path
        parsed = urlsplit(normalized)
        if not parsed.path.lower().startswith("/pow/"):
            return original(method, raw_path, headers, body)
        entry = {
            "timeUtc": datetime.now(timezone.utc).isoformat(), "method": method,
            "path": re.sub(r"(?<=/)[0-9]{6,}(?=/|$)", "{id}", parsed.path)[:256],
            "queryKeys": sorted(parse_qs(parsed.query))[:40],
            "requestBytes": len(body), "request": document_shape(body) if body else None,
        }
        try:
            status, response_headers, response_body = original(method, raw_path, headers, body)
        except Exception as error:
            entry["exceptionType"] = type(error).__name__
            record(entry)
            raise
        entry.update(status=int(status), responseBytes=len(response_body), response=document_shape(response_body))
        record(entry)
        return status, response_headers, response_body

    module.route_fut = route
