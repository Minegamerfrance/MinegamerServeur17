def pending_items(module):
    with module.STATE.lock:
        items = module.STATE.list_items("unassigned")
        items.sort(key=lambda item: (-int(item.get("rating", 0)), -int(item["id"])))
        duplicates = []
        for item in items:
            if item.get("itemType", "player") != "player":
                continue
            owned = module.STATE.owned_player_item_by_resource_id(int(item["resourceId"]))
            if owned and int(owned["id"]) != int(item["id"]):
                duplicates.append({"itemId": int(item["id"]), "duplicateItemId": int(owned["id"])})
        native = [module._native_pack_item(item) for item in items]
    return {"numberItems": len(native), "duplicateItemIdList": duplicates, "itemData": native}


def install(module):
    if getattr(module, "_mng_unassigned_entry_installed", False):
        return
    original = module.user_mass_info

    def user_mass_info():
        payload = original()
        purchased = pending_items(module)
        payload["purchasedItems"] = purchased
        if isinstance(payload.get("userInfo"), dict):
            payload["userInfo"].update(purchased=bool(purchased["numberItems"]), pilePack=purchased["numberItems"])
        module.log.info("FUT entry unassigned payload items=%d duplicates=%d",
                        purchased["numberItems"], len(purchased["duplicateItemIdList"]))
        return payload

    module.user_mass_info = user_mass_info
    module._mng_unassigned_entry_installed = True
