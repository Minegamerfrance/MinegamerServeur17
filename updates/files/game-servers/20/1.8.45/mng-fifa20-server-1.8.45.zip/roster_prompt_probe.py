from __future__ import annotations

import threading
import urllib.parse
import xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path


PROBE_VERSION = 2147483646
DOWNLOAD_PATH = "/fifa/fifalive/squads/mng-popup-test/fut-squads.bin"
MARKER_NAME = "roster-popup-test-1.8.41.done"
NATIVE_SCHEMA_CRC = "366c98dae36dac79a6feec3e3e29e42aa94492b4"


def probe_manifest(original):
    root = ET.fromstring(original)
    squad_set = root.find("squadInfoSet")
    template = next(squad for squad in squad_set.findall("squadInfo") if squad.get("platform") == "pc64")
    squad = deepcopy(template)
    squad.find("dbSchemaCRC").text = NATIVE_SCHEMA_CRC
    squad.find("dbFUTVer").text = str(PROBE_VERSION)
    squad.find("dbFUTLoc").text = DOWNLOAD_PATH.lstrip("/")
    squad_set.append(squad)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def apply(module, marker_directory=None):
    if getattr(module, "_mng_roster_prompt_probe_applied", False):
        return
    marker_directory = Path(marker_directory) if marker_directory is not None else Path(__file__).resolve().parent / "runtime" / "data"
    marker = marker_directory / MARKER_NAME
    armed = not marker.exists()
    manifest = probe_manifest(module.EaswHandler.ROSTER_XML)
    original_get = module.EaswHandler.do_GET
    original_config = module._blaze_osdk_core_config
    original_route = module.route_fut
    lock = threading.Lock()
    served = False

    def core_config():
        entries = original_config()
        if not armed:
            return entries
        base_url = dict(entries)["ROSTER_URL"].rsplit("/", 1)[0]
        settings = {
            "FUT_SQUAD_UPDATE": "1",
            "FUT/ROSTERUPDATE_URL": base_url + "/roster",
            "LIVE_CONTENT_HOST": base_url,
        }
        return [(key, value) for key, value in entries if key not in settings] + list(settings.items())

    def roster_get(self):
        nonlocal armed, served
        path = urllib.parse.urlsplit(self.path).path.rstrip("/")
        if path == DOWNLOAD_PATH:
            module.log.warning("FIFA20 roster popup TEST: download refused (no squad data); return to menu, restart server AND game to restore normal FUT entry")
            self._send(410, b"", content_type="application/octet-stream", extra={"Cache-Control": "no-store"})
            return
        if path != "/roster" or not armed:
            return original_get(self)
        with lock:
            if not served:
                try:
                    marker.parent.mkdir(parents=True, exist_ok=True)
                    with marker.open("x", encoding="utf-8") as destination:
                        destination.write("Native popup diagnostic only. No squad data. Disabled after server restart.\n")
                except OSError as error:
                    armed = False
                    module.log.warning("FIFA20 roster popup TEST not armed: %s", error)
                    return original_get(self)
                served = True
        original_send = self._send

        def send(status, body, content_type="text/xml", extra=None):
            return original_send(status, body, content_type=content_type, extra={**(extra or {}), "Cache-Control": "no-store"})

        self.ROSTER_XML = manifest
        self._send = send
        try:
            module.log.warning("FIFA20 roster popup TEST manifest: schemaCRC=%s dbFUTVer=%d; no real update; BACK exits FUT, next server/game restart restores baseline", NATIVE_SCHEMA_CRC, PROBE_VERSION)
            return original_get(self)
        finally:
            del self.ROSTER_XML
            del self._send

    def route(method, raw_path, headers, body):
        if urllib.parse.urlsplit(raw_path).path.rstrip("/") == DOWNLOAD_PATH:
            return 410, {"Content-Type": "application/octet-stream", "Cache-Control": "no-store"}, b""
        return original_route(method, raw_path, headers, body)

    module.EaswHandler.do_GET = roster_get
    module._blaze_osdk_core_config = core_config
    module.route_fut = route
    module._mng_roster_prompt_probe_applied = True
    module.log.warning("FIFA20 roster popup diagnostic: %s; no database/save edits", "armed for this server session" if armed else "disabled, normal roster manifest")
