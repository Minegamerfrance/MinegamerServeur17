# Première mise à jour native — test 1.8.42

Le serveur propose au jeu un vrai fichier d'effectifs, à la place du téléchargement de diagnostic qui répondait sans données.

- Version d'effectifs : **2042**. Version du serveur : **1.8.42**.
- Le fichier reprend les 47 tables du groupe natif `squads`, lues sans modification dans le jeu ouvert : 20 045 joueurs, 792 équipes.
- Seules la version et l'indication d'effectifs en ligne changent. Aucun transfert, note de joueur ou composition d'équipe n'est ajouté. Les cartes spéciales du serveur sont conservées, mais ce premier fichier n'ajoute pas encore leurs variantes dans la base native.
- Le fichier est au format de base natif, emballé en RefPack. Ses contrôles d'intégrité incluent les en-têtes, l'index, chaque table et le contrôle natif des lignes triées. Le serveur ne le propose pas si sa validation échoue.
- La fenêtre et le téléchargement sont natifs : aucun changement de FIFA20.exe, aucune injection et aucun besoin de Frosty Mod Manager.

## Essai en jeu

Fermer le jeu, installer la version du serveur, redémarrer le serveur puis FIFA 20. Entrer dans Ultimate Team et accepter la mise à jour. Vérifier que le téléchargement aboutit et que le menu FUT reste accessible. Le fait que le serveur envoie les données ne suffit pas à confirmer que le jeu les applique correctement.

Le test est annoncé durant une seule session serveur. Après la première demande du manifeste, `runtime/data/roster-update-test-1.8.42.done` empêche une nouvelle annonce au prochain démarrage du serveur. En cas d'échec, annuler puis redémarrer **le serveur et le jeu** pour revenir à l'entrée FUT sans demande forcée. Le serveur ne supprime aucune sauvegarde. Ce mécanisme désactive l'annonce ; il ne supprime pas des effectifs déjà acceptés et enregistrés par le jeu.

Pour réarmer volontairement le test, arrêter le serveur puis retirer uniquement ce marqueur, avant de redémarrer le serveur et le jeu. Les marqueurs et sauvegardes ne font pas partie du paquet distribué.
