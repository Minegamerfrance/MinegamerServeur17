import json
import re
from pathlib import Path
from urllib.parse import urlsplit


CATALOG_PATH = "/pow/store/game/fifa20/catalog/list"
LEVEL_PATH = "/pow/lvl/user/tiergp/businessunit/tiertp/fifa"
WEIGHT_PATH = "/pow/lvl/weight/tiergp/businessunit/tiertp/fifa"
ITEM_LIST = re.compile(r"^/pow/store/game/fifa20/catalog/(\d+)/item/list$")
REWARD_CLAIM = re.compile(r"^/pow/store/game/fifa20/catalog/(\d+)/item/(\d+)(?:/(?:claim|purchase|redeem))?$")
CATALOG_ID = 0
FUT_COIN_REWARD_ID = 1
FUT_COIN_REWARD = {
    "id": FUT_COIN_REWARD_ID,
    "itemId": FUT_COIN_REWARD_ID,
    "catalogId": CATALOG_ID,
    "name": "500 crédits FUT",
    "description": "Récompense du niveau 1",
    "level": 1,
    "requiredLevel": 1,
    "rewardType": "coin",
    "awardType": "coin",
    "awardValue": 500,
    "awardCount": 1,
    "currency": "FUT",
    "price": 0,
    "cost": 0,
}
CLAIM_KEY = "easfc_catalog_level_1_500_fut_credits_claimed"


def read_profile(path):
    profile = {"level": 1, "xp": 0, "currLevelExpMin": 0, "currLevelExpMax": 1000}
    if path.exists():
        saved = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(saved, dict):
            raise ValueError("Invalid EAS FC profile document")
        for field in profile:
            value = saved.get(field, profile[field])
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"Invalid EAS FC profile field: {field}")
            profile[field] = value
        if profile["level"] < 1 or profile["currLevelExpMax"] <= profile["currLevelExpMin"]:
            raise ValueError("Invalid EAS FC level range")
    return profile


def install(module):
    if getattr(module, "_mng_easfc_catalog_installed", False):
        return
    original_route = module.route_fut
    profile_path = Path(module.RUNTIME_ROOT) / "data" / "easfc-profile.json"

    def reply(payload, status=200):
        return status, {"Content-Type": "application/json", "Cache-Control": "no-store"}, module.json_bytes(payload)

    def claim_level_one_reward():
        state = module.STATE
        with state.lock:
            connection = state.conn
            connection.execute("BEGIN IMMEDIATE")
            try:
                claimed = connection.execute("SELECT value FROM kv WHERE key=?", (CLAIM_KEY,)).fetchone()
                credits_row = connection.execute("SELECT value FROM kv WHERE key='credits'").fetchone()
                try:
                    credits = int(json.loads(credits_row[0])) if credits_row else 0
                except (TypeError, ValueError, json.JSONDecodeError):
                    credits = int(credits_row[0]) if credits_row else 0
                if claimed:
                    connection.commit()
                    return {"success": True, "alreadyClaimed": True, "credits": credits,
                            "totalCredits": credits, "coins": credits}
                connection.execute(
                    "INSERT INTO kv(key,value) VALUES('credits',?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (json.dumps(credits + FUT_COIN_REWARD["awardValue"]),),
                )
                connection.execute("INSERT INTO kv(key,value) VALUES(?,?)", (CLAIM_KEY, "1"))
                connection.commit()
                credits += FUT_COIN_REWARD["awardValue"]
                return {"success": True, "alreadyClaimed": False,
                        "awardedPrizes": [dict(FUT_COIN_REWARD)], "credits": credits,
                        "totalCredits": credits, "coins": credits}
            except Exception:
                connection.rollback()
                raise

    def route(method, raw_path, headers, body):
        normalized = raw_path[1:] if raw_path.startswith("//pow/") else raw_path
        path = urlsplit(normalized).path
        if not path.startswith("/pow/"):
            return original_route(method, raw_path, headers, body)
        payload = None
        if method == "GET" and path == CATALOG_PATH:
            catalogs = [{"id": CATALOG_ID, "catalogId": CATALOG_ID, "name": "Catalogue FIFA 20"}]
            payload = {"catalogList": catalogs, "catalogs": catalogs, "totalCount": 1}
        elif method == "GET" and (match := ITEM_LIST.fullmatch(path)):
            reward = dict(FUT_COIN_REWARD)
            items = [reward] if int(match.group(1)) == CATALOG_ID else []
            payload = {"itemList": items, "items": items, "totalCount": len(items), "endOfList": True}
        elif method in {"POST", "PUT"} and (match := REWARD_CLAIM.fullmatch(path)):
            if int(match.group(1)) != CATALOG_ID or int(match.group(2)) != FUT_COIN_REWARD_ID:
                return reply({"success": False, "error": "CATALOG_ITEM_NOT_FOUND"}, 404)
            try:
                profile = read_profile(profile_path)
            except (ValueError, OSError):
                module.log.error("EASFC profile rejected; saved data was not changed")
                return reply({"error": "EASFC_PROFILE_INVALID"}, 503)
            if profile["level"] < FUT_COIN_REWARD["requiredLevel"]:
                return reply({"success": False, "error": "LEVEL_REQUIREMENT_NOT_MET"}, 403)
            result = claim_level_one_reward()
            module.log.info("EASFC catalogue reward level=%d amount=%d alreadyClaimed=%s",
                            FUT_COIN_REWARD["requiredLevel"], FUT_COIN_REWARD["awardValue"],
                            result["alreadyClaimed"])
            return reply(result)
        elif method == "GET" and path in {"/pow/store/gift/list", "/pow/inventory/item/list"}:
            payload = {"itemList": [], "items": [], "totalCount": 0, "endOfList": True}
            if path == "/pow/store/gift/list":
                payload["giftList"] = []
        elif method == "GET" and path in {LEVEL_PATH, WEIGHT_PATH}:
            try:
                profile = read_profile(profile_path)
            except (ValueError, OSError):
                module.log.error("EASFC profile rejected; saved data was not changed")
                return reply({"error": "EASFC_PROFILE_INVALID"}, 503)
            if path == LEVEL_PATH:
                payload = dict(profile, user=dict(profile), tier=profile["level"], isMaxLevel=False)
            else:
                tier = {"level": profile["level"], "minXp": profile["currLevelExpMin"],
                        "maxXp": profile["currLevelExpMax"] - 1, "weight": 1}
                payload = {"weightList": [tier], "tierList": [tier], "totalCount": 1}
        if payload is None:
            return original_route(method, raw_path, headers, body)
        module.log.info("EASFC catalogue bootstrap method=%s path=%s items=%s clientValidation=pending",
                        method, path, payload.get("totalCount", "profile"))
        return reply(payload)

    module.route_fut = route
    module._mng_easfc_catalog_installed = True
    module.log.warning("EASFC catalogue installed: level 1 reward enabled (500 FUT credits)")
