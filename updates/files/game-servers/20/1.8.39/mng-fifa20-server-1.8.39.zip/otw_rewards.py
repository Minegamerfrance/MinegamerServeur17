from __future__ import annotations

import copy
import json


SMALL_ELECTRUM_ID = 1041
RARE_CONSUMABLES_ID = 1042
OTW_KIT_ID = 6310217
SHADOW_ID = 5003113
SIDE_REWARDS = {
    301: ("kit", OTW_KIT_ID, 0),
    302: ("pack", SMALL_ELECTRUM_ID, 4),
    303: ("pack", 1005, 1),
    304: ("pack", 1024, 1),
    305: ("pack", RARE_CONSUMABLES_ID, 4),
    306: ("pack", 1015, 1),
    307: ("pack", 14, 1),
    308: ("consumable", SHADOW_ID, 0),
}
PACKS = {
    SMALL_ELECTRUM_ID: {"name": "Petit pack de joueurs Électrum", "bio": "Six joueurs : trois Or et trois Argent, dont un Rare.",
                       "size": 6, "rare_slots": 1, "gold_weight": 50, "silver_weight": 50, "bronze_weight": 0},
    RARE_CONSUMABLES_ID: {"name": "Pack de consommables rares", "bio": "Douze consommables Or rares.",
                          "size": 12, "rare_slots": 12, "content_type": "consumables",
                          "gold_weight": 100, "silver_weight": 0, "bronze_weight": 0},
}
FRENCH_PACK_NAMES = {1005: "Pack Or Premium", 1024: "Pack Or", 1015: "Pack Or Jumbo", 14: "Pack de joueurs Or"}


def side_reward(objective_id):
    kind, value, hal_id = SIDE_REWARDS[objective_id]
    return {"type": kind, "value": value, "count": 1, "isUntradeable": True, "loan": 0, "halId": hal_id}


def build_item(state, reward, item_id):
    if reward["type"] == "kit":
        item = state.build_club_item(reward["value"], item_id, "unassigned", "free")
        item.update(name="Maillot À surveiller", displayName="Maillot À surveiller")
    else:
        item = state.build_consumable_item(reward["value"], item_id, "unassigned")
        item["untradeableCount"] = 1
        if reward["value"] == SHADOW_ID:
            item.update(name="Ombre", displayName="Ombre")
    item.update(untradeable=True, discardValue=0)
    return item


def next_item_id(cursor):
    row = cursor.execute("SELECT value FROM kv WHERE key='next_item_id'").fetchone()
    maximum = cursor.execute("SELECT COALESCE(MAX(id),0) FROM items").fetchone()[0]
    return max(int(json.loads(row[0])) if row else 900000000000, maximum) + 1


def persist_item(cursor, item):
    cursor.execute("INSERT INTO items(id,resource_id,pile,data) VALUES(?,?,?,?)",
                   (item["id"], item["resourceId"], "unassigned", json.dumps(item)))
    cursor.execute("INSERT INTO kv(key,value) VALUES('next_item_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                   (json.dumps(item["id"]),))


def grant(season, cursor, progress, objective_id):
    claimed = progress.setdefault("otwSideRewardsClaimed", [])
    if objective_id in claimed:
        return [], []
    reward = side_reward(objective_id)
    items = []
    if reward["type"] == "pack":
        cursor.execute("INSERT INTO unopened_packs(pack_id,data) VALUES(?,?)",
                       (reward["value"], json.dumps({"source": f"MNG OTW objective {objective_id}", "untradeable": True, "isUntradeable": True})))
    else:
        item = build_item(season.state, reward, next_item_id(cursor))
        persist_item(cursor, item)
        items.append(item)
    claimed.append(objective_id)
    prize = season._native_award(reward)
    prize["awardValue"] = reward["value"]
    if items:
        prize["itemData"] = items[0]
    return items, [prize]


def install(module):
    if getattr(module, "_mng_otw_rewards_installed", False):
        return
    module._mng_otw_rewards_installed = True
    original_load = module.load_pack_settings
    original_create = module.State.create_pack

    def settings():
        result = copy.deepcopy(original_load())
        for pack_id, name in FRENCH_PACK_NAMES.items():
            if str(pack_id) in result["packs"]:
                result["packs"][str(pack_id)]["name"] = name
        for pack_id, specification in PACKS.items():
            result["packs"][str(pack_id)] = dict(specification, enabled=False, reward_only=True, price=0,
                                                special_chance=0, guaranteed_specials=0, pack_asset_id=4)
        result["next_pack_id"] = max(int(result.get("next_pack_id", 0)), RARE_CONSUMABLES_ID + 1)
        return result

    def create_pack(state, pack_id=1):
        if int(pack_id) not in PACKS:
            return original_create(state, pack_id)
        with state.lock:
            selected = []
            if int(pack_id) == SMALL_ELECTRUM_ID:
                rare_tier = module.random.choice(("gold", "silver"))
                used = set()
                for tier in ("gold", "silver"):
                    for slot in range(3):
                        rare = int(tier == rare_tier and slot == 0)
                        pool = [resource for resource, player in module.PLAYER_DB.items()
                                if player.get("tier") == tier and int(player.get("rareflag", -1)) == rare
                                and player.get("assetId") not in used and module._player_is_pack_safe(player)
                                and not module._player_is_excluded_from_packs(resource, player)]
                        if not pool:
                            raise ValueError("OTW_REWARD_PACK_POOL_EMPTY")
                        resource = module.random.choice(pool)
                        used.add(module.PLAYER_DB[resource]["assetId"])
                        selected.append(("player", resource))
            else:
                pool = [resource for resource, definition in module.CONSUMABLE_DB.items()
                        if int(definition.get("rareflag", 0)) > 0 and int(definition.get("rating", 0)) >= 75]
                if len(pool) < 12:
                    raise ValueError("OTW_REWARD_PACK_POOL_EMPTY")
                selected = [("consumable", resource) for resource in module.random.sample(pool, 12)]
            state.conn.execute("BEGIN IMMEDIATE")
            try:
                cursor = state.conn.cursor()
                items = []
                duplicates = []
                for kind, resource in selected:
                    item_id = next_item_id(cursor)
                    if kind == "player":
                        item = state.build_player_item(resource, item_id, "unassigned")
                        item.update(untradeable=True, discardValue=0)
                        owned = cursor.execute("SELECT id FROM items WHERE resource_id=? AND pile IN ('club','squad') LIMIT 1", (resource,)).fetchone()
                        if owned:
                            item["duplicateId"] = int(owned[0])
                            duplicates.append({"itemId": item_id, "duplicateItemId": int(owned[0])})
                    else:
                        item = build_item(state, {"type": kind, "value": resource}, item_id)
                    persist_item(cursor, item)
                    items.append(item)
                state.conn.commit()
            except Exception:
                state.conn.rollback()
                raise
            return {"packId": int(pack_id), "purchasedPackId": int(pack_id), "packType": "CUSTOM_PACK",
                    "itemList": items, "itemData": items, "items": items,
                    "newcards": len(items), "numberItems": len(items),
                    "duplicateItemIdList": duplicates, "credits": state.credits()}

    module.load_pack_settings = settings
    module.State.create_pack = create_pack
