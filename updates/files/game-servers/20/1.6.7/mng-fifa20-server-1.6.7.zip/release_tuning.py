from __future__ import annotations
import copy
import json
import math
import threading
import time
import urllib.parse
from typing import Any

MIXED_PACKS = {
    1: (1, 6, 1),
    2: (1, 6, 1),
    3: (1, 6, 1),
    8: (1, 6, 1),
    9: (2, 12, 2),
    10: (1, 6, 1),
    11: (2, 12, 2),
    12: (1, 6, 1),
    13: (2, 12, 2),
    1005: (1, 6, 1),
    1008: (2, 13, 3),
    1009: (2, 13, 3),
    1015: (2, 12, 2),
    1016: (2, 12, 2),
    1017: (1, 4, 2),
    1024: (1, 6, 1),
    1026: (2, 12, 2),
    1027: (1, 6, 1),
}

REMOVED_STORE_PACKS = {4, 5, 6, 7, 23, 24, 1031, 1033, 1034, 1035, 1037}
REMOVED_SBC_SET_IDS = {33, 34, 35, 36, 40, 41}
ADVANCED_GROUP_REWARD_PACK_ID = 1028
PROMO_STORE_ORDER = {15: 1, 1008: 2, 16: 3, 17: 4, 1009: 5, 18: 6}
MARKET_LIVE_BASE = 1180000
MARKET_LIVE_SWING = 90000
FEATURE_DISABLED_MESSAGE = "This online mode is not available in MNG FUT 20 local mode."
JAMES_FLASHBACK_REAL_ID = 839059510
JAMES_FLASHBACK_BAYERN_ID = 855836726
JAMES_FLASHBACK_PORTO_ID = 872613942
JAMES_FLASHBACK_MONACO_ID = 889391158

TOTW1_SPECS = (
    (167495, 89), (211256, 84), (165229, 84), (197853, 82), (193283, 84),
    (228702, 86), (139068, 83), (208093, 84), (208722, 89), (165153, 88),
    (175943, 88), (173426, 82), (177604, 82), (228251, 82), (41236, 86),
    (215061, 82), (231447, 81), (231352, 81), (223982, 71), (239768, 75),
    (239085, 79), (212228, 76), (236474, 75),
)

OTW_SPECS = (
    (229880, 79), (235243, 85), (220814, 84), (203263, 82), (228702, 86),
    (231866, 85), (224232, 80), (212194, 84), (198950, 83), (226110, 83),
    (203486, 82), (221992, 82), (183277, 91), (189242, 86), (227796, 79),
    (242444, 80), (194765, 89), (201399, 85), (192505, 85), (232432, 83),
    (205693, 83), (199451, 83), (223334, 78), (235569, 81), (184941, 82),
    (208808, 82), (192883, 81), (216388, 79),
)

UCL_BASE_RARITIES = {47, 48}
UCL_2019_20_TEAM_IDS = {
    5, 9, 10, 18, 21, 22, 32, 39, 44, 48, 65, 66, 73, 191, 211,
    231, 234, 240, 241, 243, 245, 266, 280, 325, 461, 673, 100765,
    101059, 112172, 114153,
}


def _promotional_player(base: dict[str, Any], rating: int, rareflag: int, rarity_name: str, rarity_class: str) -> dict[str, Any]:
    player = copy.deepcopy(base)
    asset_id = int(player.get("assetId", player.get("resourceId", 0)) or 0)
    old_rating = int(player.get("rating", 0) or 0)
    increase = max(0, int(rating) - old_rating)
    player["resourceId"] = asset_id + rareflag * 16777216
    player["rating"] = int(rating)
    player["rareflag"] = rareflag
    player["rarityName"] = rarity_name
    player["rarityClass"] = rarity_class
    player["tier"] = "gold" if rating >= 75 else ("silver" if rating >= 65 else "bronze")
    player["special"] = True
    if increase:
        player["face"] = [min(99, int(value) + increase * 2) for value in player.get("face", [])]
        attributes = player.get("attributes", {})
        for key, value in list(attributes.items()):
            if key != "gkSpeed":
                attributes[key] = min(99, int(value) + increase * 2)
    return player


def _install_launch_promotions(module: Any) -> None:
    for asset_id, rating in TOTW1_SPECS:
        base = module.PLAYER_DB.get(asset_id)
        if base:
            player = _promotional_player(base, rating, 3, "Team of the Week", "totw")
            module.PLAYER_DB[int(player["resourceId"])] = player
    for asset_id, rating in OTW_SPECS:
        base = module.PLAYER_DB.get(asset_id)
        if base:
            player = _promotional_player(base, rating, 21, "Ones to Watch", "otw")
            module.PLAYER_DB[int(player["resourceId"])] = player
    if isinstance(getattr(module, "_special_pool_counts", None), dict):
        module._special_pool_counts[3] = len(TOTW1_SPECS)
        module._special_pool_counts[21] = len(OTW_SPECS)


def _install_base_ucl_cards(module: Any) -> dict[int, int]:
    counts = {47: 0, 48: 0}
    for resource_id, base in list(module.PLAYER_DB.items()):
        asset_id = int(base.get("assetId", resource_id) or resource_id)
        base_rarity = int(base.get("rareflag", 0) or 0)
        if int(resource_id) != asset_id or base_rarity not in {0, 1}:
            continue
        if int(base.get("teamid", 0) or 0) not in UCL_2019_20_TEAM_IDS:
            continue
        ucl_rarity = 48 if base_rarity == 1 else 47
        player = copy.deepcopy(base)
        player["resourceId"] = asset_id + ucl_rarity * 16777216
        player["rareflag"] = ucl_rarity
        player["rarityName"] = "UEFA Champions League Rare" if ucl_rarity == 48 else "UEFA Champions League Common"
        player["rarityClass"] = "ucl_rare" if ucl_rarity == 48 else "ucl_common"
        player["special"] = True
        module.PLAYER_DB[int(player["resourceId"])] = player
        counts[ucl_rarity] += 1
    if isinstance(getattr(module, "_special_pool_counts", None), dict):
        module._special_pool_counts.update(counts)
    if isinstance(getattr(module, "DEFAULT_SPECIAL_WEIGHTS", None), dict):
        module.DEFAULT_SPECIAL_WEIGHTS.setdefault("47", 4)
    if isinstance(getattr(module, "PROMO_SPECIAL_WEIGHTS", None), dict):
        module.PROMO_SPECIAL_WEIGHTS.setdefault("47", 5)
    return counts


def _boost_base_ucl_cards(module: Any) -> int:
    boosted = 0
    for player in module.PLAYER_DB.values():
        if int(player.get("rareflag", 0) or 0) not in UCL_BASE_RARITIES:
            continue
        if player.get("_mngFifa19UclBoost"):
            continue
        player["rating"] = min(99, int(player.get("rating", 0) or 0) + 1)
        player["face"] = [min(99, int(value) + 1) for value in player.get("face", [])]
        attributes = player.get("attributes")
        if isinstance(attributes, dict):
            for key, value in list(attributes.items()):
                numeric_value = int(value)
                if numeric_value > 0:
                    attributes[key] = min(99, numeric_value + 1)
        player["_mngFifa19UclBoost"] = True
        boosted += 1
    return boosted


def _james_flashback_player(
    resource_id: int,
    team_id: int,
    team_name: str,
    league_id: int,
    league_name: str,
    rating: int = 88,
    position: str = "CAM",
    face: list[int] | None = None,
) -> dict[str, Any]:
    face = face or [77, 86, 89, 86, 56, 70]
    player = {
        "name": "Rodríguez",
        "firstName": "James",
        "lastName": "Rodríguez",
        "commonName": "James Rodríguez",
        "rating": rating,
        "preferredPosition": position,
        "preferredFoot": "Left",
        "workRateAttack": "High",
        "workRateDefense": "Medium",
        "weakFoot": 4,
        "skillMoves": 4,
        "dateOfBirth": "1991-07-12",
        "height": 180,
        "weight": 75,
        "leagueId": league_id,
        "leagueName": league_name,
        "teamid": team_id,
        "teamName": team_name,
        "nation": 56,
        "nationName": "Colombia",
        "assetId": 198710,
        "resourceId": resource_id,
        "cardsubtypeid": 0,
        "rareflag": 51,
        "rarityName": "Flashback",
        "rarityClass": "flashback",
        "tier": "gold",
        "special": True,
        "face": face,
        "attributes": {
            "acceleration": 77, "sprintSpeed": 74, "positioning": 87,
            "finishing": 86, "shotPower": 88, "longShots": 89,
            "volleys": 86, "penalties": 82, "vision": 91,
            "crossing": 89, "freeKickAccuracy": 90, "shortPassing": 90,
            "longPassing": 89, "curve": 91, "agility": 86,
            "balance": 84, "reactions": 88, "ballControl": 88,
            "dribbling": 86, "composure": 89, "interceptions": 56,
            "headingAccuracy": 66, "marking": 56, "standingTackle": 55,
            "slidingTackle": 48, "jumping": 69, "stamina": 70,
            "strength": 72, "aggression": 63,
            "gkDiving": 0, "gkHandling": 0, "gkKicking": 0,
            "gkReflexes": 0, "gkSpeed": 0, "gkPositioning": 0,
        },
    }
    if rating == 85:
        pace, shooting, passing, dribbling, defending, physical = face
        player["attributes"].update({
            "acceleration": min(99, pace + 2), "sprintSpeed": max(1, pace - 1),
            "positioning": shooting + 2, "finishing": shooting, "shotPower": shooting + 2,
            "longShots": shooting + 2, "volleys": shooting, "penalties": shooting - 2,
            "vision": passing + 3, "crossing": passing + 1, "freeKickAccuracy": passing + 2,
            "shortPassing": passing + 2, "longPassing": passing + 1, "curve": passing + 3,
            "agility": dribbling + 1, "balance": dribbling - 1, "reactions": dribbling,
            "ballControl": dribbling + 1, "dribbling": dribbling, "composure": dribbling + 1,
            "interceptions": defending, "headingAccuracy": defending + 5, "marking": defending,
            "standingTackle": defending - 1, "slidingTackle": defending - 6,
            "jumping": physical, "stamina": physical + 2, "strength": physical + 1,
            "aggression": physical - 3,
        })
    return player



def _market_live_count(actual: int = 0) -> int:
    tick = int(time.time() // 45)
    span = MARKET_LIVE_SWING * 2 + 1
    offset = ((tick * 7919 + 104729) % span) - MARKET_LIVE_SWING
    return max(1000000, int(actual or 0), MARKET_LIVE_BASE + offset)


def _route_path(raw_path: str) -> str:
    path = urllib.parse.urlsplit(str(raw_path or "")).path.lower()
    if path.startswith("/ut/ut/"):
        path = "/ut/" + path[7:]
    return path


def _disabled_mode(path: str) -> str:
    low = str(path or "").lower()
    if "/rivals/" in low or low.endswith("/rivals"):
        return "Division Rivals"
    if "/champion/" in low or "/champions/" in low or low.endswith("/champion") or low.endswith("/champions"):
        return "FUT Champions"
    if any(token in low for token in ("sqbt", "squadbattle", "squad/battle", "squad_battle", "featuredsquad")):
        return "Squad Battles"
    return ""

def _round_half_up(value: float) -> int:
    return int(math.floor(float(value) + 0.5))


def fifa20_player_quick_sell(module: Any, resource_id: int) -> int:
    rid = module.canonical_player_resource_id(int(resource_id))
    meta = module.player_meta(rid) or {}
    rating = max(0, int(meta.get("rating", 0) or 0))
    rareflag = int(meta.get("rareflag", 0) or 0)
    special = bool(meta.get("special", False)) or rareflag > 1
    rarity_name = str(meta.get("rarityName", "") or "").strip().lower()
    rarity_class = str(meta.get("rarityClass", "") or "").strip().lower()
    if not special:
        if rating >= 75:
            return int(rating * (8 if rareflag == 1 else 4))
        if rating >= 65:
            return _round_half_up(rating * (3.5 if rareflag == 1 else 1.5))
        return _round_half_up(rating * (0.75 if rareflag == 1 else 0.30))
    if rarity_class == "toty" or rarity_name == "team of the year":
        return int(rating * 800)
    if rareflag in {12, 84} or rarity_name == "icon" or rarity_name.startswith("icon moments"):
        return int(rating * 750)
    if rating >= 75:
        return int(rating * 122)
    if rating >= 65:
        return int(rating * 70)
    return int(rating * 20)


def _regular_rating_weight(rating: int) -> float:
    table = {81: 0.90, 82: 0.80, 83: 0.65, 84: 0.50, 85: 0.36, 86: 0.25, 87: 0.17, 88: 0.11, 89: 0.07, 90: 0.045, 91: 0.028, 92: 0.017, 93: 0.010, 94: 0.006}
    if rating <= 80:
        return 1.0
    if rating >= 95:
        return 0.003
    return table.get(int(rating), 0.003)


def _special_rating_weight(rating: int) -> float:
    table = {85: 0.85, 86: 0.72, 87: 0.60, 88: 0.48, 89: 0.38, 90: 0.29, 91: 0.22, 92: 0.16, 93: 0.115, 94: 0.080, 95: 0.055, 96: 0.038, 97: 0.025, 98: 0.016, 99: 0.010}
    if rating <= 84:
        return 1.0
    return table.get(int(rating), 0.010 if rating >= 99 else 1.0)


def _tier(rating: int) -> str:
    rating = int(rating or 0)
    if rating >= 75:
        return "gold"
    if rating >= 65:
        return "silver"
    return "bronze"


def _is_special(module: Any, item: dict[str, Any]) -> bool:
    rid = int(item.get("resourceId", item.get("assetId", 0)) or 0)
    meta = module.PLAYER_DB.get(rid, {}) or module.player_meta(rid) or {}
    return bool(meta.get("special", False)) or int(item.get("rareflag", meta.get("rareflag", 0)) or 0) > 1


def _pool(module: Any, kind: str, tier: str, rare: bool) -> list[int]:
    if kind == "manager":
        return [int(rid) for rid, meta in module.MANAGER_DB.items() if _tier(int(meta.get("rating", 0) or 0)) == tier and (int(meta.get("rareflag", 0) or 0) > 0) == rare]
    if kind == "consumable":
        return [int(rid) for rid, meta in module.CONSUMABLE_DB.items() if _tier(int(meta.get("rating", 0) or 0)) == tier and (int(meta.get("rareflag", 0) or 0) > 0) == rare]
    if kind == "club_kit":
        native = list(dict.fromkeys(list(getattr(module, "_NATIVE_HOME_KITS", [])) + list(getattr(module, "_NATIVE_AWAY_KITS", []))))
        return [int(rid) for rid in native if int(rid) in module.CLUB_ITEM_DB and (int(module.CLUB_ITEM_DB[int(rid)].get("rareflag", 0) or 0) > 0) == rare]
    if kind == "club_badge":
        native = list(dict.fromkeys(list(getattr(module, "_NATIVE_BADGES", []))))
        return [int(rid) for rid in native if int(rid) in module.CLUB_ITEM_DB and (int(module.CLUB_ITEM_DB[int(rid)].get("rareflag", 0) or 0) > 0) == rare]
    return []


def _pick_resource(module: Any, original_choice, kind: str, tier: str, rare: bool, used: set[int]) -> int | None:
    candidates = [rid for rid in _pool(module, kind, tier, rare) if rid not in used]
    if not candidates:
        candidates = [rid for rid in _pool(module, kind, tier, not rare) if rid not in used]
    if not candidates:
        return None
    return int(original_choice(candidates))


def _pick_consumable(module: Any, original_choice, original_shuffle, tier: str, rare: bool, used: set[int], used_groups: set[int]) -> int | None:
    groups = [list(group) for group in module._consumable_pack_groups()]
    group_indexes = list(range(len(groups)))
    original_shuffle(group_indexes)
    for wanted_rare in (rare, not rare):
        for gi in group_indexes:
            if gi in used_groups:
                continue
            candidates = []
            for rid in groups[gi]:
                rid = int(rid)
                meta = module.CONSUMABLE_DB.get(rid, {})
                if rid in used or _tier(int(meta.get("rating", 0) or 0)) != tier:
                    continue
                if (int(meta.get("rareflag", 0) or 0) > 0) != wanted_rare:
                    continue
                candidates.append(rid)
            if candidates:
                used_groups.add(gi)
                return int(original_choice(candidates))
    positions = []
    for rid, meta in module.CONSUMABLE_DB.items():
        rid = int(rid)
        if rid in used or str(meta.get("sourceMember", "")) != "consumablesPosition":
            continue
        if _tier(int(meta.get("rating", 0) or 0)) != tier:
            continue
        positions.append(rid)
    exact = [rid for rid in positions if (int(module.CONSUMABLE_DB[rid].get("rareflag", 0) or 0) > 0) == rare]
    if exact:
        return int(original_choice(exact))
    if positions:
        return int(original_choice(positions))
    return _pick_resource(module, original_choice, "consumable", tier, rare, used)


def _make_non_player(module: Any, state: Any, original_choice, original_shuffle, kind: str, source: dict[str, Any], used: set[int], used_groups: set[int]) -> dict[str, Any] | None:
    tier = _tier(int(source.get("rating", 0) or 0))
    rare = int(source.get("rareflag", 0) or 0) > 0
    if kind == "consumable":
        rid = _pick_consumable(module, original_choice, original_shuffle, tier, rare, used, used_groups)
    else:
        if kind.startswith("club"):
            tier = "gold"
            rare = True
        rid = _pick_resource(module, original_choice, kind, tier, rare, used)
    if rid is None:
        return None
    if kind == "manager":
        item = state.make_manager_item(rid, "unassigned")
    elif kind == "consumable":
        item = state.make_consumable_item(rid, "unassigned")
    else:
        item = state.make_club_item(rid, "unassigned", "free")
    used.add(rid)
    return item


def _mixed_pack(module: Any, state: Any, pack_id: int, pack: dict[str, Any], original_choice, original_shuffle) -> dict[str, Any]:
    plan = MIXED_PACKS.get(int(pack_id))
    if not plan:
        return pack
    items = list(pack.get("itemData") or [])
    if not items:
        return pack
    manager_count, consumable_count, club_count = plan
    normal = [(idx, item) for idx, item in enumerate(items) if str(item.get("itemType", "player")).lower() == "player" and not _is_special(module, item)]
    normal.sort(key=lambda pair: (int(pair[1].get("rating", 0) or 0), int(pair[1].get("rareflag", 0) or 0), int(pair[1].get("id", 0) or 0)))
    chosen: list[tuple[int, str]] = []
    remaining = list(normal)
    club_kinds = []
    if club_count == 1:
        club_kinds = [original_choice(["club_kit", "club_badge"])]
    elif club_count > 1:
        club_kinds = ["club_kit", "club_badge"] + [original_choice(["club_kit", "club_badge"]) for _ in range(club_count - 2)]
    for club_kind in club_kinds:
        pos = next((i for i, pair in enumerate(remaining) if int(pair[1].get("rareflag", 0) or 0) > 0), None)
        if pos is None:
            break
        idx, _item = remaining.pop(pos)
        chosen.append((idx, club_kind))
    for kind, count in (("manager", manager_count), ("consumable", consumable_count)):
        for _ in range(count):
            if not remaining:
                break
            idx, _item = remaining.pop(0)
            chosen.append((idx, kind))
    used = {int(item.get("resourceId", item.get("assetId", 0)) or 0) for item in items}
    used_groups: set[int] = set()
    for idx, kind in sorted(chosen, key=lambda pair: pair[0], reverse=True):
        source = items[idx]
        replacement = _make_non_player(module, state, original_choice, original_shuffle, kind, source, used, used_groups)
        if replacement is None:
            continue
        try:
            state.delete_item(int(source.get("id", 0) or 0))
        except Exception:
            try:
                state.delete_item(int(replacement.get("id", 0) or 0))
            except Exception:
                pass
            continue
        items[idx] = replacement
    order = {"player": 0, "manager": 1, "development": 2, "kit": 3, "custom": 3, "stadium": 3, "ball": 3}
    items.sort(key=lambda item: order.get(str(item.get("itemType", "player")).lower(), 4))
    pack["itemData"] = items
    pack["itemList"] = items
    pack["items"] = items
    pack["numberItems"] = len(items)
    pack["newcards"] = len(items)
    native_duplicates = list(pack.get("duplicateItemIdList") or [])
    remaining_ids = {int(item.get("id", 0) or 0) for item in items}
    duplicate_pairs = []
    for entry in native_duplicates:
        if not isinstance(entry, dict):
            continue
        item_id = int(entry.get("itemId", 0) or 0)
        if item_id not in remaining_ids:
            continue
        pair = {"itemId": item_id}
        duplicate_id = int(entry.get("duplicateItemId", 0) or 0)
        if duplicate_id:
            pair["duplicateItemId"] = duplicate_id
        duplicate_pairs.append(pair)
    pack["duplicateItemIdList"] = duplicate_pairs
    try:
        detail = []
        for item in items:
            rid = int(item.get("resourceId", item.get("assetId", 0)) or 0)
            kind = str(item.get("itemType", "player")).lower()
            source_member = str(module.CONSUMABLE_DB.get(rid, {}).get("sourceMember", ""))
            family = str(module.CLUB_ITEM_DB.get(rid, {}).get("family", ""))
            detail.append((kind, rid, source_member or family))
        module.log.warning("MNG FUT 20 MIXED PACK id=%d items=%s", int(pack_id), detail)
    except Exception:
        pass
    return pack

def _repair_existing_discard_values(module: Any) -> int:
    state = getattr(module, "STATE", None)
    if state is None:
        return 0
    changed = 0
    try:
        items = list(state.list_items())
    except Exception:
        return 0
    for item in items:
        if str(item.get("itemType", "player")).lower() != "player":
            continue
        iid = int(item.get("id", 0) or 0)
        rid = int(item.get("resourceId", item.get("assetId", 0)) or 0)
        if not iid or not rid:
            continue
        value = fifa20_player_quick_sell(module, rid)
        if int(item.get("discardValue", -1) or 0) == value:
            continue
        try:
            state.update_item_fields(iid, {"discardValue": value})
            changed += 1
        except Exception:
            pass
    return changed


def apply(module: Any) -> None:
    original_create_pack = module.State.create_pack
    original_choice = module.random.choice
    original_shuffle = module.random.shuffle
    original_get_pack_cfg = module.get_pack_cfg
    original_store_purchasegroups = module._store_purchasegroups
    original_route_fut = module.route_fut
    original_generate_player_pick_resources = module._generate_player_pick_resources
    pack_lock = threading.RLock()
    for resource_id, player in list(module.PLAYER_DB.items()):
        asset_id = int(player.get("assetId", resource_id) or resource_id)
        rareflag = int(player.get("rareflag", 0) or 0)
        if int(resource_id) != asset_id and rareflag <= 1:
            module.PLAYER_DB.pop(resource_id, None)
    module.PLAYER_DB[JAMES_FLASHBACK_REAL_ID] = _james_flashback_player(
        JAMES_FLASHBACK_REAL_ID, 243, "Real Madrid", 53, "LaLiga Santander"
    )
    module.PLAYER_DB[JAMES_FLASHBACK_BAYERN_ID] = _james_flashback_player(
        JAMES_FLASHBACK_BAYERN_ID, 21, "Bayern München", 19, "Bundesliga"
    )
    module.PLAYER_DB[JAMES_FLASHBACK_PORTO_ID] = _james_flashback_player(
        JAMES_FLASHBACK_PORTO_ID, 236, "FC Porto", 308, "Liga NOS", 85, "LW", [83, 82, 82, 85, 55, 66]
    )
    module.PLAYER_DB[JAMES_FLASHBACK_MONACO_ID] = _james_flashback_player(
        JAMES_FLASHBACK_MONACO_ID, 69, "AS Monaco", 16, "Ligue 1 Conforama", 85, "RW", [82, 81, 83, 85, 55, 66]
    )
    _install_launch_promotions(module)
    ucl_counts = _install_base_ucl_cards(module)
    boosted_ucl = _boost_base_ucl_cards(module)
    module.SBC_CATALOG = [entry for entry in module.SBC_CATALOG if int(entry.get("set_id", 0) or 0) not in REMOVED_SBC_SET_IDS]
    for entry in module.SBC_CATALOG:
        if int(entry.get("set_id", 0) or 0) in {20, 21, 22}:
            entry["awards"] = [{"type": "PACK", "pack_id": ADVANCED_GROUP_REWARD_PACK_ID, "count": 1}]
            entry["description"] = {
                20: "Solve four escalating league puzzles for a Jumbo Premium Gold Players Pack.",
                21: "Solve four escalating nation puzzles for a Jumbo Premium Gold Players Pack.",
                22: "Master mixed league-and-nation squads for a Jumbo Premium Gold Players Pack.",
            }[int(entry.get("set_id", 0) or 0)]

    module.SBC_CATALOG.insert(0, {
        "set_id": 50,
        "category_id": 2,
        "category": "ADVANCED",
        "priority": 0,
        "name": "Flashback PRIME : James Rodríguez",
        "description": "Complete the challenge and choose James Flashback: Real Madrid or Bayern München.",
        "repeatable": False,
        "awards": [{"type": "PLAYER_PICK", "pool": "james_flashback", "options": 2, "count": 1}],
        "challenges": [{
            "challenge_id": 5001,
            "name": "Two Clubs, One Maestro",
            "description": "Exchange an 84-rated squad to unlock the James Rodríguez Flashback Player Pick.",
            "players": 11,
            "formation": "f442",
            "rules": [
                {"kind": "player_count", "value": 11, "scope": "exact", "count": -1, "text": "Players in the Squad: 11"},
                {"kind": "team_rating", "value": 84, "scope": "min", "count": -1, "text": "Team Rating: Min. 84"},
                {"kind": "rare_count", "value": 3, "scope": "min", "count": -1, "text": "Rare Players: Min. 3"},
                {"kind": "chemistry", "value": 60, "scope": "min", "count": -1, "text": "Team Chemistry: Min. 60"},
            ],
            "awards": [],
        }],
    })

    module.SBC_CATALOG.insert(1, {
        "set_id": 51,
        "category_id": 2,
        "category": "ADVANCED",
        "priority": 1,
        "name": "Flashback BABY : James Rodríguez",
        "description": "Complete the challenge and choose James Flashback BABY: FC Porto or AS Monaco.",
        "repeatable": False,
        "awards": [{"type": "PLAYER_PICK", "pool": "james_flashback_baby", "options": 2, "count": 1}],
        "challenges": [{
            "challenge_id": 5101,
            "name": "The Young Maestro",
            "description": "Exchange an 82-rated squad to unlock the James Rodríguez Flashback BABY Player Pick.",
            "players": 11,
            "formation": "f442",
            "rules": [
                {"kind": "player_count", "value": 11, "scope": "exact", "count": -1, "text": "Players in the Squad: 11"},
                {"kind": "team_rating", "value": 82, "scope": "min", "count": -1, "text": "Team Rating: Min. 82"},
                {"kind": "rare_count", "value": 2, "scope": "min", "count": -1, "text": "Rare Players: Min. 2"},
                {"kind": "chemistry", "value": 55, "scope": "min", "count": -1, "text": "Team Chemistry: Min. 55"},
            ],
            "awards": [],
        }],
    })

    def tuned_generate_player_pick_resources(pool: str, options: int, min_rating: int = 0):
        if str(pool or "").lower() == "james_flashback":
            return [JAMES_FLASHBACK_REAL_ID, JAMES_FLASHBACK_BAYERN_ID]
        if str(pool or "").lower() == "james_flashback_baby":
            return [JAMES_FLASHBACK_PORTO_ID, JAMES_FLASHBACK_MONACO_ID]
        return original_generate_player_pick_resources(pool, options, min_rating)

    module._generate_player_pick_resources = tuned_generate_player_pick_resources

    def tuned_get_pack_cfg(pack_id: int):
        try:
            if int(pack_id) in REMOVED_STORE_PACKS:
                return {}
        except Exception:
            pass
        return original_get_pack_cfg(pack_id)

    def tuned_store_purchasegroups():
        payload = original_store_purchasegroups()
        if isinstance(payload, dict) and isinstance(payload.get("purchase"), list):
            payload = dict(payload)
            rows = [row for row in payload["purchase"] if int(row.get("packId", row.get("id", 0)) or 0) not in REMOVED_STORE_PACKS]
            for row in rows:
                pid = int(row.get("packId", row.get("id", 0)) or 0)
                if pid in PROMO_STORE_ORDER:
                    order = PROMO_STORE_ORDER[pid]
                    row["categoryList"] = {"categoryId": 4, "orderInCategory": order}
                    row["displayGroup"] = {"value": "special", "priority": 4}
                    row["purchaseGroup"] = "special"
                    row["group"] = "special"
                    row["sortPriority"] = order
                    row["isPromo"] = True
            payload["purchase"] = rows
        return payload

    def tuned_route_fut(method: str, raw_path: str, headers: dict[str, str], body: bytes):
        path = _route_path(raw_path)
        mode = _disabled_mode(path)
        if mode:
            payload = {
                "reason": FEATURE_DISABLED_MESSAGE,
                "code": "FEATURE_DISABLED",
                "message": FEATURE_DISABLED_MESSAGE,
                "error": FEATURE_DISABLED_MESSAGE,
                "errorMessage": FEATURE_DISABLED_MESSAGE,
                "localizedMessage": FEATURE_DISABLED_MESSAGE,
                "title": mode,
            }
            try:
                module.log.info("MNG FUT 20 disabled mode blocked mode=%s path=%s", mode, path)
            except Exception:
                pass
            return 409, {"Cache-Control": "no-store"}, module.json_bytes(payload)
        status, response_headers, response_body = original_route_fut(method, raw_path, headers, body)
        if int(status) == 200 and path == "/ut/game/fifa20/hub":
            try:
                decoded = json.loads(response_body.decode("utf-8"))
                if isinstance(decoded, dict):
                    actual = max(
                        int(decoded.get("auctionCount", 0) or 0),
                        int(decoded.get("liveAuctions", 0) or 0),
                        int(decoded.get("liveTransfers", 0) or 0),
                    )
                    live = _market_live_count(actual)
                    decoded["auctionCount"] = live
                    decoded["liveAuctions"] = live
                    decoded["liveTransfers"] = live
                    response_body = module.json_bytes(decoded)
                    try:
                        module.log.info("MNG FUT 20 market population liveTransfers=%d activeLocal=%d", live, actual)
                    except Exception:
                        pass
            except Exception:
                pass
        return status, response_headers, response_body

    def quick_sell(self, resource_id: int) -> int:
        return fifa20_player_quick_sell(module, resource_id)

    def weighted_player_choice(seq):
        try:
            values = list(seq)
            if len(values) >= 2 and all(isinstance(x, int) for x in values):
                sample = values[: min(16, len(values))]
                if sample and all(int(x) in module.PLAYER_DB for x in sample):
                    weights = []
                    for rid in values:
                        meta = module.PLAYER_DB.get(int(rid), {}) or {}
                        rating = int(meta.get("rating", 0) or 0)
                        special = bool(meta.get("special", False)) or int(meta.get("rareflag", 0) or 0) > 1
                        weights.append(_special_rating_weight(rating) if special else _regular_rating_weight(rating))
                    total = sum(weights)
                    if total > 0:
                        return module.random.choices(values, weights=weights, k=1)[0]
        except Exception:
            pass
        return original_choice(seq)

    def weighted_player_shuffle(seq):
        try:
            if isinstance(seq, list) and len(seq) >= 2 and all(isinstance(x, int) for x in seq[: min(16, len(seq))]):
                sample = seq[: min(16, len(seq))]
                if sample and all(int(x) in module.PLAYER_DB for x in sample):
                    keyed = []
                    for rid in seq:
                        meta = module.PLAYER_DB.get(int(rid), {}) or {}
                        rating = int(meta.get("rating", 0) or 0)
                        special = bool(meta.get("special", False)) or int(meta.get("rareflag", 0) or 0) > 1
                        weight = _special_rating_weight(rating) if special else _regular_rating_weight(rating)
                        weight = max(float(weight), 0.000001)
                        keyed.append((module.random.random() ** (1.0 / weight), rid))
                    keyed.sort(key=lambda pair: pair[0])
                    seq[:] = [rid for _, rid in keyed]
                    return None
        except Exception:
            pass
        return original_shuffle(seq)

    def tuned_create_pack(self, pack_id: int = 1):
        with pack_lock:
            module.random.choice = weighted_player_choice
            module.random.shuffle = weighted_player_shuffle
            try:
                pack = original_create_pack(self, pack_id)
                return _mixed_pack(module, self, int(pack_id), pack, original_choice, original_shuffle)
            finally:
                module.random.choice = original_choice
                module.random.shuffle = original_shuffle

    module.get_pack_cfg = tuned_get_pack_cfg
    module._store_purchasegroups = tuned_store_purchasegroups
    module.route_fut = tuned_route_fut
    module.State.player_discard_value = quick_sell
    module.State.create_pack = tuned_create_pack
    repaired = _repair_existing_discard_values(module)
    try:
        module.log.warning("MNG FUT 20 release tuning active: mixed packs, rating weights, discard values, million-plus market, disabled online modes, removedSBCs=%d, repairedItems=%d, uclCommon=%d, uclRare=%d, boostedUcl=%d", len(REMOVED_SBC_SET_IDS), repaired, ucl_counts[47], ucl_counts[48], boosted_ucl)
    except Exception:
        pass
