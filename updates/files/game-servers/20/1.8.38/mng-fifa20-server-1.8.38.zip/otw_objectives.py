from __future__ import annotations

import json
from pathlib import Path


GROUP_ID = 3
NDOMBELE_ID = 352557105
OBJECTIVES = (
    (301, "Debut Mark", "Marquez un but en finesse avec un joueur lors de son premier match en Clash d'équipes, difficulté Professionnel minimum.", "otw_debut", 1, 100),
    (302, "Summer Moves", "Gagnez 4 matchs Clash d'équipes avec au moins un joueur néerlandais, un Français et un Belge, difficulté Champion minimum.", "otw_summer", 4, 100),
    (303, "All In", "Marquez avec un joueur de Premier League dans 4 victoires distinctes en Rivals ou Clash d'équipes.", "otw_premier", 4, 100),
    (304, "Parisian Talent", "Gagnez 4 matchs Rivals ou Clash d'équipes avec au moins 2 joueurs français titulaires.", "otw_paris", 4, 100),
    (305, "Back Again", "Marquez 20 buts dans n'importe quel mode FUT cette semaine.", "otw_goals", 20, 100),
    (306, "Origin Story", "Marquez 2 buts avec des joueurs de Ligue 1 dans 3 matchs distincts en Rivals ou Clash d'équipes.", "otw_ligue1", 3, 100),
    (307, "Midfield Maestro", "Faites une passe décisive dans 10 matchs distincts en Rivals ou Clash d'équipes avec un milieu de terrain de poste d'origine, avant changement de poste.", "otw_midfield", 10, 100),
    (308, "Pinpoint Accuracy", "Marquez sur un centre dans 3 matchs Clash d'équipes distincts, difficulté Semi-pro minimum.", "otw_cross", 3, 100),
)


def match_context(module, request):
    if not module._sb_is_match_request(request):
        return {}
    squad = module.STATE.get_squad(int(module.STATE.get("squad_id", 1))) or {}
    players = []
    for entry in squad.get("players", []):
        if not 0 <= int(entry.get("index", -1)) <= 10:
            continue
        item = module.STATE.get_item(int(entry.get("itemId", 0))) or {}
        player = module.PLAYER_DB.get(int(item.get("resourceId", 0)), {})
        if player:
            players.append({"nation": int(player["nation"]), "leagueId": int(player["leagueId"]),
                            "assetId": int(player["assetId"]), "preferredPosition": player["preferredPosition"]})
    return {"mode": "squad_battles", "difficulty": int(module._sb_state()["selectedDifficulty"]), "starters": players}


def win_increments(context):
    if context.get("mode") not in {"squad_battles", "rivals"}:
        return {}
    nations = [player["nation"] for player in context.get("starters", [])]
    result = {}
    if nations.count(18) >= 2:
        result["otw_paris"] = 1
    if context["mode"] == "squad_battles" and context.get("difficulty", -1) >= 4 and {34, 18, 7}.issubset(nations):
        result["otw_summer"] = 1
    return result


def group(season, progress):
    objectives = []
    for objective_id, title, description, counter, target, xp in OBJECTIVES:
        actual = min(target, progress["totals"].get(counter, 0))
        claimed = season._objective_key(progress, objective_id) in progress["claimedObjectives"]
        completed = actual >= target
        reward = {"type": "xp", "value": xp, "count": 1, "isUntradeable": True, "halId": 0, "loan": 0}
        objectives.append({"objectiveId": objective_id, "objectiveName": title, "name": title,
                           "objectiveDescription": description, "description": description,
                           "shortDescription": title, "currentProgress": actual, "ruleTargetValue": target,
                           "xp": xp, "xpReward": xp, "progress": actual, "target": target,
                           "currentValue": actual, "targetValue": target,
                           "completed": completed, "isCompleted": completed, "isClaimed": claimed,
                           "state": 2 if claimed else 1 if completed else 0,
                           "awardsList": [season._native_award(reward)],
                           "awards": [dict(reward, **season._native_award(reward))],
                           "rewardsList": [reward], "rewards": [reward]})
    reward = {"type": "player", "value": NDOMBELE_ID, "count": 1, "isUntradeable": True, "halId": 0, "loan": 0}
    claimed = bool(progress.get("otwGroupClaimed"))
    completed = all(entry["isCompleted"] for entry in objectives)
    return {"groupId": GROUP_ID, "name": "Ones To Watch", "groupName": "Ones To Watch",
            "description": "Terminez les huit défis pour gagner Ndombele OTW 81 invendable.",
            "groupDescription": "Terminez les huit défis pour gagner Ndombele OTW 81 invendable.",
            "groupType": 1, "priority": 1, "startTime": progress["startedAt"], "endTime": 2145916800,
            "objectivesList": objectives, "objectives": objectives,
            "awardsList": [season._native_award(reward)], "rewardsList": [reward], "rewards": [reward],
            "completed": completed, "isCompleted": completed, "isClaimed": claimed,
            "groupState": 2 if claimed else 1 if completed else 0,
            "state": 2 if claimed else 1 if completed else 0}


def claim_group(season):
    def claim(cursor, progress):
        if progress.get("otwGroupClaimed"):
            return {"success": True, "alreadyClaimed": True, "itemData": [], "rewards": [], "awardedPrizes": []}
        if not all(progress["totals"].get(entry[3], 0) >= entry[4] for entry in OBJECTIVES):
            raise ValueError("OBJECTIVE_NOT_COMPLETE")
        if not all(season._objective_key(progress, entry[0]) in progress["claimedObjectives"] for entry in OBJECTIVES):
            raise ValueError("OBJECTIVES_NOT_CLAIMED")
        row = cursor.execute("SELECT value FROM kv WHERE key='next_item_id'").fetchone()
        maximum = cursor.execute("SELECT COALESCE(MAX(id),0) FROM items").fetchone()[0]
        item_id = max(int(json.loads(row[0])) if row else 900000000000, maximum) + 1
        item = season.state.build_player_item(NDOMBELE_ID, item_id, "unassigned")
        item.update(untradeable=True, discardValue=0)
        owned = cursor.execute("SELECT id FROM items WHERE resource_id=? AND pile IN ('club','squad') LIMIT 1", (NDOMBELE_ID,)).fetchone()
        if owned:
            item["duplicateId"] = int(owned[0])
        cursor.execute("INSERT INTO items(id,resource_id,pile,data) VALUES(?,?,?,?)", (item_id, NDOMBELE_ID, "unassigned", json.dumps(item)))
        cursor.execute("INSERT INTO kv(key,value) VALUES('next_item_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(item_id),))
        progress["otwGroupClaimed"] = True
        prize = {"awardType": "item", "awardCount": 1, "awardValue": NDOMBELE_ID, "halId": 0,
                 "loan": 0, "untradeable": True, "itemData": item}
        return {"success": True, "alreadyClaimed": False, "itemData": [item], "awardedPrizes": [prize],
                "rewards": [group(season, progress)["rewardsList"][0]], "userXp": progress["xp"]}
    return season._transaction(claim)


def install_report_capture(module, destination=None):
    if getattr(module, "_mng_otw_report_capture", False):
        return
    module._mng_otw_report_capture = True
    original = module._blaze_game_report_result_payload
    destination = Path(destination) if destination is not None else Path(__file__).resolve().parent / "runtime" / "objective-reports"

    def capture(request):
        result = original(request)
        try:
            if len(request) <= 2 * 1024 * 1024:
                destination.mkdir(parents=True, exist_ok=True)
                with module.STATE.lock:
                    (destination / "latest-offline-report.bin").write_bytes(request)
                    (destination / "latest-offline-report.txt").write_text(module._tdf_debug_summary(request), encoding="utf-8")
                module.log.info("OTW objective report captured: bytes=%s; detailed goal conditions remain unverified", len(request))
        except Exception:
            module.log.exception("OTW report capture failed; native game result preserved")
        return result
    module._blaze_game_report_result_payload = capture
