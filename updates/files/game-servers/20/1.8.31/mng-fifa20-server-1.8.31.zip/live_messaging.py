from __future__ import annotations

import json
import re
import urllib.parse
from pathlib import Path


POSTERS = ((200101, "otw1.png", "OTW 1"), (200102, "totw1.png", "TOTW 1"))
ASSET_PATH = "/fut/livemessaging/"
HUB_DATA_KEY = "mng_fifa20_user_hub_client_data"
INTRO_SEEN_BIT = 1024


def hub_client_data(module):
    return module.STATE.get(HUB_DATA_KEY, {"entries": [{"key": 0, "value": 13}, {"key": 1, "value": 12}]})


def messages(module):
    host = str(module.CFG.get("local_host", "127.0.0.1"))
    port = int(module.CFG.get("fut_port", 8080))
    result = []
    for priority, (message_id, filename, title) in enumerate(POSTERS):
        poster = Path(__file__).resolve().parent / "assets" / "livemessaging" / filename
        if not poster.is_file():
            continue
        result.append({
            "messageId": message_id,
            "messageType": 1,
            "screenID": 0,
            "screen": "futlivemsggen4",
            "priority": priority,
            "displayTime": 5,
            "doNotDisplay": False,
            "trackingTag": "mng-fifa20-" + filename[:-4],
            "renders": [
                {"name": "MESSAGE_TITLE", "type": "TEXT", "value": title},
                {"name": "BODY_IMAGE", "type": "IMAGE",
                 "value": "http://" + host + ":" + str(port) + ASSET_PATH + filename},
            ],
        })
    return result


def apply(module):
    original_route = module.route_fut

    def route(method, raw_path, headers, body):
        method = method.upper()
        parsed = urllib.parse.urlsplit(raw_path)
        path = re.sub(r"^/ut/ut/", "/ut/", parsed.path).rstrip("/")
        api_path = path.lower()
        query = urllib.parse.parse_qs(parsed.query)
        if api_path == "/ut/game/fifa20/clientdata/userhubdata" and method in {"GET", "PUT", "POST"}:
            if method != "GET":
                try:
                    request = json.loads(body.decode("utf-8")) if body else {}
                    entries = request["entries"]
                    if not isinstance(entries, list):
                        raise ValueError("Invalid entries")
                    for entry in entries:
                        if not isinstance(entry, dict) or type(entry.get("key")) is not int or type(entry.get("value")) is not int:
                            raise ValueError("Invalid entry")
                        if not 0 <= entry["key"] <= 65535 or not 0 <= entry["value"] <= 0xffffffff:
                            raise ValueError("Invalid client flags")
                    with module.STATE.lock:
                        values = {entry["key"]: entry["value"] for entry in hub_client_data(module)["entries"]}
                        intro_seen = bool(values.get(1, 0) & INTRO_SEEN_BIT)
                        values.update({entry["key"]: entry["value"] for entry in entries})
                        if intro_seen:
                            values[1] = values.get(1, 0) | INTRO_SEEN_BIT
                        module.STATE.set(HUB_DATA_KEY, {"entries": [{"key": key, "value": value} for key, value in sorted(values.items())]})
                except (ValueError, TypeError, AttributeError, KeyError):
                    return 400, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "invalidHubClientData"})
            result = hub_client_data(module)
            module.log.info("FIFA20 user hub client data: introSeen=%s", bool(next((entry["value"] for entry in result["entries"] if entry["key"] == 1), 0) & INTRO_SEEN_BIT))
            return 200, {"Cache-Control": "no-store"}, module.json_bytes(result)
        if method == "GET" and path.startswith(ASSET_PATH):
            filename = path[len(ASSET_PATH):]
            if filename not in {entry[1] for entry in POSTERS}:
                return 404, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "unknownPoster"})
            poster = Path(__file__).resolve().parent / "assets" / "livemessaging" / filename
            if not poster.is_file():
                return 404, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "missingPoster"})
            module.log.info("FIFA20 live message poster served: %s", filename)
            return 200, {"Content-Type": "image/png", "Cache-Control": "no-store"}, poster.read_bytes()
        if method in {"PUT", "POST"} and path == "/ut/game/fifa20/livemessage":
            try:
                request = json.loads(body.decode("utf-8")) if body else {}
                requested = request.get("idList", [])
                known = {entry[0] for entry in POSTERS}
                if not isinstance(requested, list) or any(type(message_id) is not int or message_id not in known for message_id in requested):
                    raise ValueError("Invalid message IDs")
            except (ValueError, TypeError, AttributeError):
                return 400, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "invalidLiveMessages"})
            module.log.info("FIFA20 live messages acknowledged: %s", requested)
            return 200, {"Cache-Control": "no-store"}, module.json_bytes({"success": True})
        live_screen = query.get("screen", [""])[0].lower() == "futlivemsggen4"
        if method == "GET" and api_path in {"/ut/game/fifa20/livemessage/template", "/ut/game/fifa20/template"} and live_screen:
            entries = messages(module)
            module.log.info("FIFA20 live message template supplied: posters=%d", len(entries))
            return 200, {"Cache-Control": "no-store"}, module.json_bytes({
                "messageList": entries, "messagesAvailable": len(entries), "messagesRead": 0,
            })
        response = original_route(method, raw_path, headers, body)
        if response[0] != 200 or method != "GET":
            return response
        if api_path == "/ut/game/fifa20/usermassinfo":
            result = json.loads(response[2])
            result["userHubClientData"] = hub_client_data(module)
            result.setdefault("hub", {})["liveMessagesAvailable"] = bool(messages(module))
            module.log.info("FIFA20 entry bootstrap: persisted hub flags and live messaging availability supplied")
            return response[0], response[1], module.json_bytes(result)
        if path == "/ut/game/fifa20/settings":
            result = json.loads(response[2])
            configs = result.setdefault("configs", [])
            existing = next((entry for entry in configs if entry.get("type") == "enableLiveMessaging"), None)
            if existing is None:
                configs.append({"type": "enableLiveMessaging", "value": "1"})
            else:
                existing["value"] = "1"
            return response[0], response[1], module.json_bytes(result)
        if path == "/ut/game/fifa20/hub":
            result = json.loads(response[2])
            entries = messages(module)
            result["liveMessagesAvailable"] = bool(entries)
            if live_screen:
                result.update({"messageList": entries, "messagesAvailable": len(entries), "messagesRead": 0})
                module.log.info("FIFA20 entry announcements supplied: posters=%d", len(entries))
            return response[0], response[1], module.json_bytes(result)
        return response

    module.route_fut = route
