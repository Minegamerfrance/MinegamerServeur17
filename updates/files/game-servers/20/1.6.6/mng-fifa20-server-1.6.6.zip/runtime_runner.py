from __future__ import annotations

import base64
import importlib.abc
import importlib.util
import json
import marshal
import os
import sys
import types
import zlib
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT = Path(__file__).resolve().parent
PAYLOAD = ROOT / "runtime" / "secure_payload.f20"
CATALOG_RESET_VERSION = "1.6.6-james-flashback-baby"
CATALOG_RESET_MARKER = ROOT / "runtime" / "data" / f"catalog-reset-{CATALOG_RESET_VERSION}.done"

A = (93,83,63,32,147,238,98,141,219,191,159,246,7,174,26,169,54,11,13,207,141,186,163,75,13,253,49,242,55,150,58,221)
B = (153,232,211,233,232,93,238,36,212,244,8,76,153,49,4,139,185,89,204,59,177,195,187,136,228,24,86,55,4,222,1,215)
C = (126,215,12,204,34,161,178,99,63,230,87,222,191,106,0,10,8,101,70,155,44,138,25,141,112,221,152,225,222,25,119,171)

ALIASES = {
    "auth_guard": "localfut20.auth_guard",
    "config_loader": "localfut20.config_loader",
    "sbc_catalog": "localfut20.sbc_catalog",
}
ENTRY_ALIASES = {
    "offline_data": "localfut20.offline_data",
    "control_server": "localfut20.control_server",
    "server": "localfut20.server",
}


def _key() -> bytes:
    return bytes(x ^ y ^ z for x, y, z in zip(A, B, C))


def _load_entries() -> dict[str, dict]:
    raw = PAYLOAD.read_bytes()
    if raw[:8] != b"F20P1\x00\x00\x00":
        raise SystemExit("MNG FUT 20 runtime payload is invalid.")
    clear = AESGCM(_key()).decrypt(
        raw[8:20], raw[20:], b"FUT20-PRIVATE-PAYLOAD-v1"
    )
    return json.loads(zlib.decompress(clear).decode("utf-8"))["entries"]


ENTRIES = _load_entries()


def _database_candidates() -> list[Path]:
    candidates = [ROOT / "runtime" / "data" / "localfut20.sqlite3"]
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        candidates.append(Path(local_app_data) / "FUT20LocalFUT" / "localfut20.sqlite3")
    try:
        settings = json.loads((ROOT / "launcher-settings.json").read_text(encoding="utf-8"))
        configured = str(settings.get("database_path", "") or "").strip()
        if configured:
            candidates.append(Path(configured).expanduser())
    except Exception:
        pass
    return list(dict.fromkeys(path.resolve() for path in candidates))


def _reset_legacy_database_once() -> None:
    if CATALOG_RESET_MARKER.exists():
        return
    CATALOG_RESET_MARKER.parent.mkdir(parents=True, exist_ok=True)
    removed = []
    for database in _database_candidates():
        for path in (database, Path(f"{database}-wal"), Path(f"{database}-shm")):
            try:
                if path.is_file():
                    path.unlink()
                    removed.append(str(path))
            except OSError as error:
                raise SystemExit(f"Unable to reset obsolete FIFA 20 database {path}: {error}") from error
    CATALOG_RESET_MARKER.write_text(
        json.dumps({"version": CATALOG_RESET_VERSION, "removed": removed}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _code(name: str):
    return marshal.loads(base64.b64decode(ENTRIES[name]["code"]))


class _Loader(importlib.abc.Loader):
    def __init__(self, full: str, target: str):
        self.full = full
        self.target = target

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        meta = ENTRIES[self.target]
        module.__file__ = str(ROOT / meta["file"])
        module.__package__ = self.full.rpartition(".")[0]
        module.__loader__ = self
        exec(_code(self.target), module.__dict__, module.__dict__)


class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        mapped = ALIASES.get(fullname, fullname)
        if mapped in ENTRIES and mapped not in {
            "launcher",
            "legacy_launcher",
            "launcher_pre_save",
            "redirector_tls",
            "trust_patch",
            "localfut20.server",
        }:
            return importlib.util.spec_from_loader(
                fullname,
                _Loader(fullname, mapped),
                origin=str(ROOT / ENTRIES[mapped]["file"]),
            )
        return None


for p in (ROOT, ROOT / "localfut20", ROOT / "runtime-source"):
    s = str(p)
    if s not in sys.path:
        sys.path.insert(0, s)

sys.meta_path.insert(0, _Finder())


def run(name: str, args: list[str]) -> None:
    _reset_legacy_database_once()
    name = ENTRY_ALIASES.get(name, name)
    if name not in ENTRIES:
        raise SystemExit(f"Unknown MNG FUT 20 component: {name}")

    meta = ENTRIES[name]
    old_argv = sys.argv[:]
    sys.argv = [str(ROOT / meta["file"])] + list(args)
    try:
        if name == "localfut20.server":
            module = types.ModuleType(name)
            module.__file__ = str(ROOT / meta["file"])
            module.__package__ = "localfut20"
            module.__loader__ = None
            sys.modules[name] = module
            exec(_code(name), module.__dict__, module.__dict__)
            from release_tuning import apply as apply_release_tuning
            apply_release_tuning(module)
            raise SystemExit(int(module.main()))

        ns = {
            "__name__": "__main__",
            "__file__": str(ROOT / meta["file"]),
            "__package__": None,
            "__cached__": None,
            "__loader__": None,
            "__builtins__": __builtins__,
        }
        exec(_code(name), ns, ns)
    finally:
        sys.argv = old_argv


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("Usage: py -3.13 runtime_runner.py <component> [args]")
    run(sys.argv[1], sys.argv[2:])
