import argparse
import signal
import socket
import struct
import threading


FIFA_HOSTS = {
    "spring18.gosredirector.ea.com",
    "utas.external.s2.fut.ea.com",
    "utas.external.s3.fut.ea.com",
    "utas.external.fut.ea.com",
    "utas.s2.fut.ea.com",
    "utas.s3.fut.ea.com",
    "utas.fut.ea.com",
    "fut.ea.com",
}


def parse_question(packet):
    offset = 12
    labels = []
    while offset < len(packet):
        length = packet[offset]
        offset += 1
        if length == 0:
            break
        if length & 0xC0 or offset + length > len(packet):
            raise ValueError("invalid DNS question")
        labels.append(packet[offset : offset + length].decode("ascii"))
        offset += length
    if offset + 4 > len(packet):
        raise ValueError("truncated DNS question")
    query_type, query_class = struct.unpack("!HH", packet[offset : offset + 4])
    return ".".join(labels).lower(), query_type, query_class, offset + 4


def build_response(packet):
    if len(packet) < 12:
        return None
    name, query_type, query_class, question_end = parse_question(packet)
    transaction_id = packet[:2]
    question = packet[12:question_end]
    if name not in FIFA_HOSTS or query_class != 1:
        return transaction_id + b"\x81\x83" + b"\x00\x01\x00\x00\x00\x00\x00\x00" + question
    if query_type not in (1, 255):
        return transaction_id + b"\x81\x80" + b"\x00\x01\x00\x00\x00\x00\x00\x00" + question
    answer = b"\xc0\x0c\x00\x01\x00\x01" + struct.pack("!IH", 30, 4) + socket.inet_aton("127.0.0.1")
    return transaction_id + b"\x81\x80" + b"\x00\x01\x00\x01\x00\x00\x00\x00" + question + answer


def serve_udp(bind_address, port, stop_event):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
        server.bind((bind_address, port))
        server.settimeout(0.5)
        while not stop_event.is_set():
            try:
                packet, client = server.recvfrom(4096)
                response = build_response(packet)
                if response:
                    server.sendto(response, client)
            except socket.timeout:
                continue
            except (OSError, ValueError):
                if stop_event.is_set():
                    break


def handle_tcp(client):
    with client:
        header = client.recv(2)
        if len(header) != 2:
            return
        expected = struct.unpack("!H", header)[0]
        packet = b""
        while len(packet) < expected:
            chunk = client.recv(expected - len(packet))
            if not chunk:
                return
            packet += chunk
        response = build_response(packet)
        if response:
            client.sendall(struct.pack("!H", len(response)) + response)


def serve_tcp(bind_address, port, stop_event):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((bind_address, port))
        server.listen(16)
        server.settimeout(0.5)
        while not stop_event.is_set():
            try:
                client, _ = server.accept()
                threading.Thread(target=handle_tcp, args=(client,), daemon=True).start()
            except socket.timeout:
                continue
            except OSError:
                if stop_event.is_set():
                    break


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bind", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=53)
    args = parser.parse_args()
    stop_event = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop_event.set())
    signal.signal(signal.SIGTERM, lambda *_: stop_event.set())
    udp_thread = threading.Thread(target=serve_udp, args=(args.bind, args.port, stop_event), daemon=True)
    tcp_thread = threading.Thread(target=serve_tcp, args=(args.bind, args.port, stop_event), daemon=True)
    udp_thread.start()
    tcp_thread.start()
    print(f"READY {args.bind}:{args.port}", flush=True)
    while udp_thread.is_alive() and tcp_thread.is_alive():
        stop_event.wait(0.5)
    stop_event.set()
    udp_thread.join(2)
    tcp_thread.join(2)


if __name__ == "__main__":
    main()
