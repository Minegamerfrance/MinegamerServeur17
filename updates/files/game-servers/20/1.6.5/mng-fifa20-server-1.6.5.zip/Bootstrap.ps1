$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$PythonVersion = '3.13.15'
$PythonUrl = 'https://www.python.org/ftp/python/3.13.15/python-3.13.15-amd64.exe'
$PythonSha256 = 'edec09c4853aeae9ac36efb8c9f95b6b8e2fee65eee56d9767a8b7c69c574403'
$Installer = Join-Path $env:TEMP ('python-' + $PythonVersion + '-amd64.exe')

function Add-PythonPaths {
    $paths = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Launcher'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\Scripts'),
        (Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps')
    )
    foreach ($p in $paths) {
        if ($p -and ($env:Path -notlike "*$p*")) { $env:Path = "$p;$env:Path" }
    }
}

function Test-Python313X64 {
    Add-PythonPaths
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if (-not $py) { $py = Get-Command py -ErrorAction SilentlyContinue }
    if (-not $py) { return $false }
    try {
        $result = & $py.Source -3.13 -c "import struct,sys,tkinter; print('OK' if sys.version_info[:2]==(3,13) and struct.calcsize('P')*8==64 else 'BAD')" 2>$null
        return (($LASTEXITCODE -eq 0) -and (($result | Select-Object -Last 1) -eq 'OK'))
    } catch {
        return $false
    }
}

function Download-Python {
    if (Test-Path -LiteralPath $Installer -PathType Leaf) {
        try {
            $existing = (Get-FileHash -LiteralPath $Installer -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($existing -eq $PythonSha256) { return }
        } catch {}
        Remove-Item -LiteralPath $Installer -Force -ErrorAction SilentlyContinue
    }

    Write-Host '[MNG FUT 20] Python 3.13 x64 is not installed.' -ForegroundColor Yellow
    Write-Host '[MNG FUT 20] Downloading the official Python 3.13.15 x64 installer...' -ForegroundColor Cyan
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $downloaded = $false
    try {
        Invoke-WebRequest -UseBasicParsing -Uri $PythonUrl -OutFile $Installer -TimeoutSec 180
        $downloaded = $true
    } catch {
        $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
        if ($curl) {
            & $curl.Source -L --fail --retry 4 --connect-timeout 20 --max-time 240 -o $Installer $PythonUrl
            if ($LASTEXITCODE -eq 0) { $downloaded = $true }
        }
    }
    if (-not $downloaded -or -not (Test-Path -LiteralPath $Installer -PathType Leaf)) {
        throw 'Could not download Python automatically. Check your internet connection and try again.'
    }

    $hash = (Get-FileHash -LiteralPath $Installer -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne $PythonSha256) {
        Remove-Item -LiteralPath $Installer -Force -ErrorAction SilentlyContinue
        throw 'Python installer security check failed (SHA-256 mismatch). Please run the launcher again.'
    }
}

if (-not (Test-Python313X64)) {
    Download-Python
    Write-Host '[MNG FUT 20] Installing Python 3.13 x64 for this Windows user...' -ForegroundColor Cyan
    $args = @(
        '/quiet',
        'InstallAllUsers=0',
        'PrependPath=1',
        'Include_pip=1',
        'Include_tcltk=1',
        'Include_launcher=1',
        'InstallLauncherAllUsers=0',
        'Include_test=0',
        'Include_doc=0',
        'Shortcuts=0'
    )
    $proc = Start-Process -FilePath $Installer -ArgumentList $args -Wait -PassThru
    if ($proc.ExitCode -notin @(0, 3010)) {
        throw "Python installer failed with exit code $($proc.ExitCode)."
    }
    Add-PythonPaths
    Start-Sleep -Seconds 2
    if (-not (Test-Python313X64)) {
        throw 'Python 3.13 x64 installation completed but Windows could not find the Python Launcher. Restart Windows once, then run Start MNG FUT 20.cmd again.'
    }
    Remove-Item -LiteralPath $Installer -Force -ErrorAction SilentlyContinue
}

Add-PythonPaths
$py = Get-Command py.exe -ErrorAction SilentlyContinue
if (-not $py) { $py = Get-Command py -ErrorAction Stop }

Write-Host '[MNG FUT 20] Python 3.13 x64: READY' -ForegroundColor Green
Write-Host '[MNG FUT 20] Checking required packages...' -ForegroundColor Cyan

& $py.Source -3.13 -m pip --version *> $null
if ($LASTEXITCODE -ne 0) {
    & $py.Source -3.13 -m ensurepip --upgrade
    if ($LASTEXITCODE -ne 0) { throw 'pip could not be initialized.' }
}

$requirements = Join-Path $PSScriptRoot 'requirements.txt'
& $py.Source -3.13 -m pip install --disable-pip-version-check --prefer-binary --only-binary=:all: --retries 5 --timeout 60 -r $requirements
if ($LASTEXITCODE -ne 0) {
    throw 'Could not install the required Python packages. Check the internet connection and try again.'
}

& $py.Source -3.13 -c "import cryptography, PIL, tkinter; print('READY')" *> $null
if ($LASTEXITCODE -ne 0) {
    throw 'Python requirements were installed but failed the final import check.'
}

Write-Host '[MNG FUT 20] Requirements: READY' -ForegroundColor Green
exit 0
