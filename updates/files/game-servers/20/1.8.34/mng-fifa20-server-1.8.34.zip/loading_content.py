from __future__ import annotations

import json
import urllib.parse
from pathlib import Path


CONTENT_PATH = "/fut/loading/content"
ASSET_PATH = "/fut/loading/"
TRIGGER_ID = "MNG_FUTLOAD"
POSTERS = ((200101, "otw1.dds", 860, 484), (200102, "totw1.dds", 843, 504))


def content(base_url):
    actions = []
    for message_id, filename, source_width, source_height in POSTERS:
        scale = min(1920 / source_width, 1080 / source_height)
        width = round(source_width * scale)
        height = round(source_height * scale)
        actions.append({
            "actionid": str(message_id),
            "render": [{
                "name": "bodyImage",
                "type": "IMAGE",
                "value": base_url.rstrip("/") + ASSET_PATH + filename,
                "attributes": {
                    "x": str((1920 - width) // 2),
                    "y": str((1080 - height) // 2),
                    "width": str(width),
                    "height": str(height),
                },
            }],
            "attributes": {"displayTime": "5", "doNotDisplay": "0"},
        })
    return {"triggers": [{"triggerid": TRIGGER_ID, "actions": actions}]}


def apply(module):
    if getattr(module, "_mng_loading_content_applied", False):
        return
    module._mng_loading_content_applied = True
    original_config = module._blaze_osdk_core_config
    original_route = module.route_fut

    def core_config():
        entries = original_config()
        base_url = dict(entries)["FIFA_POW_CONTENT_SERVER_URL"].rstrip("/")
        settings = {
            "DYNAMICCONTENT_ACTIVE": "1",
            "DYNAMICCONTENT_TRIGGERDATA": "12|" + TRIGGER_ID + "|0|1|0",
            "DYNAMICCONTENT_ARUBA_MESSAGEURL": base_url + CONTENT_PATH,
            "ONLINE/DYNAMIC_CONTENT_ENABLED": "1",
            "DYNAMICCONTENT_MAX_IMAGE_PER_MESSAGE": "1",
            "DYNAMICCONTENT_MAX_TEXTBOX_PER_MESSAGE": "2",
        }
        module.log.info("FIFA20 native FUTLOAD config: screen=12 provider=Aruba converter=LiveMessage(1) messageInfo=0xa0 url=%s", settings["DYNAMICCONTENT_ARUBA_MESSAGEURL"])
        return [(key, value) for key, value in entries if key not in settings] + list(settings.items())

    def route(method, raw_path, headers, body):
        path = urllib.parse.urlsplit(raw_path).path.rstrip("/")
        method = method.upper()
        if path == CONTENT_PATH and method in {"GET", "POST"}:
            if method == "POST" and body:
                try:
                    request = json.loads(body.decode("utf-8"))
                    if not isinstance(request, dict):
                        raise ValueError("Invalid content request")
                except (ValueError, UnicodeDecodeError):
                    return 400, {"Cache-Control": "no-store"}, module.json_bytes({"triggers": []})
                trigger_ids = request.get("triggerids", [])
                if not isinstance(trigger_ids, (list, str)):
                    return 400, {"Cache-Control": "no-store"}, module.json_bytes({"triggers": []})
                if trigger_ids and TRIGGER_ID not in trigger_ids:
                    return 200, {"Cache-Control": "no-store"}, module.json_bytes({"triggers": []})
            base_url = dict(original_config())["FIFA_POW_CONTENT_SERVER_URL"]
            module.log.info("FIFA20 native FUTLOAD content served: trigger=%s posters=OTW1,TOTW1", TRIGGER_ID)
            return 200, {"Content-Type": "application/json", "Cache-Control": "no-store"}, module.json_bytes(content(base_url))
        if path.startswith(ASSET_PATH):
            filename = path[len(ASSET_PATH):]
            if method not in {"GET", "HEAD"} or filename not in {poster[1] for poster in POSTERS}:
                return 404, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "unknownLoadingAsset"})
            asset = Path(__file__).resolve().parent / "assets" / "loading" / filename
            if not asset.is_file():
                return 404, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "missingLoadingAsset"})
            module.log.info("FIFA20 native FUTLOAD image served: %s", filename)
            return 200, {"Content-Type": "image/vnd-ms.dds", "Cache-Control": "no-store"}, asset.read_bytes() if method == "GET" else b""
        return original_route(method, raw_path, headers, body)

    module._blaze_osdk_core_config = core_config
    module.route_fut = route
