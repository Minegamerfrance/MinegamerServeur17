from __future__ import annotations

import hashlib
import json
import struct
import threading
import urllib.parse
import xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path

from squad_payload import database_crc, decompress, read_database


VERSION = 2044
NATIVE_SCHEMA_CRC = "366c98dae36dac79a6feec3e3e29e42aa94492b4"
DOWNLOAD_PATH = "/fifa/fifalive/squads/mng-fut-roster-2044.bin"
MARKER_NAME = "roster-update-test-1.8.44.done"


def load_update(asset_directory):
    directory = Path(asset_directory)
    payload = (directory / "mng-fut-roster-2044.bin").read_bytes()
    metadata = json.loads((directory / "mng-fut-roster-2044.json").read_text(encoding="utf-8"))
    if metadata["version"] != VERSION or metadata["schemaCRC"] != NATIVE_SCHEMA_CRC or metadata.get("nameEncoding") != "fut-cards-ng" or len(payload) != metadata["size"] or hashlib.sha256(payload).hexdigest() != metadata["sha256"]:
        raise ValueError("Squad update identity or integrity mismatch")
    database = decompress(payload)
    tables = read_database(database)
    if len(database) != metadata["databaseSize"] or len(tables) != 47 or [table["shortname"] for table in tables] != metadata["tableOrder"]:
        raise ValueError("Squad update database layout mismatch")
    checksum = database_crc(tables)
    if checksum != metadata["databaseCRC"] & 0xFFFFFFFF:
        raise ValueError("Squad update native checksum mismatch")
    version = next(table for table in tables if table["shortname"] == "DbIl")
    record = version["records"]
    if len(record) != 48 or struct.unpack_from("<H", record, 2)[0] + 1 != VERSION or record[4:44].decode("ascii") != NATIVE_SCHEMA_CRC or not record[44] & 1:
        raise ValueError("Squad update version table mismatch")
    return payload, metadata


def update_manifest(original, metadata):
    root = ET.fromstring(original)
    squad_set = root.find("squadInfoSet")
    template = next(squad for squad in squad_set.findall("squadInfo") if squad.get("platform") == "pc64")
    squad = deepcopy(template)
    for field, value in {
        "dbSchemaCRC": NATIVE_SCHEMA_CRC,
        "dbFUTVer": VERSION,
        "dbFUTCRC": metadata["databaseCRC"],
        "dbFUTLoc": DOWNLOAD_PATH.lstrip("/"),
    }.items():
        squad.find(field).text = str(value)
    squad_set.append(squad)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def apply(module, marker_directory=None, asset_directory=None):
    if getattr(module, "_mng_roster_update_applied", False):
        return
    root = Path(__file__).resolve().parent
    marker_directory = Path(marker_directory) if marker_directory is not None else root / "runtime" / "data"
    marker = marker_directory / MARKER_NAME
    try:
        payload, metadata = load_update(asset_directory if asset_directory is not None else root / "assets" / "squads")
        manifest = update_manifest(module.EaswHandler.ROSTER_XML, metadata)
    except (OSError, ValueError, KeyError, TypeError, ET.ParseError, StopIteration, struct.error) as error:
        module.log.warning("FIFA20 squad update disabled: invalid/missing payload (%s); normal FUT entry retained", error)
        module._mng_roster_update_applied = True
        return
    armed = not marker.exists()
    original_get = module.EaswHandler.do_GET
    original_config = module._blaze_osdk_core_config
    original_route = module.route_fut
    lock = threading.Lock()
    served = False

    def core_config():
        entries = original_config()
        if not armed:
            return entries
        base_url = dict(entries)["ROSTER_URL"].rsplit("/", 1)[0]
        settings = {"FUT_SQUAD_UPDATE": "1", "FUT/ROSTERUPDATE_URL": base_url + "/roster", "LIVE_CONTENT_HOST": base_url}
        return [(key, value) for key, value in entries if key not in settings] + list(settings.items())

    def roster_get(self):
        nonlocal armed, served
        path = urllib.parse.urlsplit(self.path).path.rstrip("/")
        if path == DOWNLOAD_PATH:
            module.log.warning("FIFA20 squad download served: version=%d bytes=%d nativeCRC=%d; download sent, application by game not yet confirmed", VERSION, len(payload), metadata["databaseCRC"])
            self._send(200, payload, content_type="application/octet-stream", extra={"Cache-Control": "no-store"})
            return
        if path != "/roster" or not armed:
            return original_get(self)
        with lock:
            if not served:
                try:
                    marker.parent.mkdir(parents=True, exist_ok=True)
                    with marker.open("x", encoding="utf-8") as destination:
                        destination.write("Native FIFA 20 FUT ratings and icon identity update test. Next server/game restart disables advertisement.\n")
                except OSError as error:
                    armed = False
                    module.log.warning("FIFA20 squad update not armed: %s; normal FUT entry retained", error)
                    return original_get(self)
                served = True
        original_send = self._send

        def send(status, body, content_type="text/xml", extra=None):
            return original_send(status, body, content_type=content_type, extra={**(extra or {}), "Cache-Control": "no-store"})

        self.ROSTER_XML = manifest
        self._send = send
        try:
            module.log.warning("FIFA20 squad update manifest: schema=%s version=%d nativeCRC=%d; original FUT ratings and icon identities restored, no transfers; one-session test", NATIVE_SCHEMA_CRC, VERSION, metadata["databaseCRC"])
            return original_get(self)
        finally:
            del self.ROSTER_XML
            del self._send

    def route(method, raw_path, headers, body):
        if urllib.parse.urlsplit(raw_path).path.rstrip("/") != DOWNLOAD_PATH:
            return original_route(method, raw_path, headers, body)
        if method not in ("GET", "HEAD"):
            return 405, {"Allow": "GET, HEAD", "Cache-Control": "no-store"}, b""
        return 200, {"Content-Type": "application/octet-stream", "Content-Length": str(len(payload)), "Cache-Control": "no-store"}, payload if method == "GET" else b""

    module.EaswHandler.do_GET = roster_get
    module._blaze_osdk_core_config = core_config
    module.route_fut = route
    module._mng_roster_update_applied = True
    module.log.warning("FIFA20 native squad update %d: %s; validated binary ready; game application validation pending", VERSION, "armed for one session" if armed else "advertisement disabled after previous test")
