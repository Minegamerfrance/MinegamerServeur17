# Effectifs FUT FIFA 20 — version 1.8.44

Les versions 1.8.42 et 1.8.43 reprenaient les joueurs du mode classique : la traduction des références de noms corrigeait les noms courants, mais conservait les mauvaises notes et excluait les icônes. Cette version remplace ces données par celles de la base FUT originale `cards_ng_db`, sans utiliser Frosty Mod Manager pour lancer le jeu.

- Effectifs natifs **2044**, supérieurs aux versions précédentes pour remplacer leur téléchargement. Serveur **1.8.44**.
- **18 804 fiches FUT** copiées intégralement depuis la base FIFA 20 vérifiée : notes, attributs, identités et apparences. Lewandowski retrouve sa note de base **89**, au lieu des 91 du mode classique.
- **2 647 fiches natives manquantes** sont réintroduites, dont les **89 icônes** du catalogue serveur, avec leurs prénoms et noms. Les variantes de cartes conservent leurs données serveur propres.
- **129 cartes de base supplémentaires**, absentes de la base FUT mais présentes dans les effectifs classiques, reprennent leur note du catalogue FUT. Seuls les attributs connus et non nuls sont repris. Pour **46 anciennes cartes** absentes des deux bases natives, aucune fiche physique ou statistique n'est inventée : leurs données serveur sont conservées. Leurs identifiants sont recensés dans le fichier de contrôle.
- Les autres tables (équipes, liens et compositions), les cartes spéciales personnalisées, les objectifs, les récompenses et les données du compte sont inchangés. Les noms dynamiques déjà réparés sont conservés pour les joueurs classiques supplémentaires.
- Les 47 tables natives, les en-têtes, l'index, les lignes et le contrôle natif d'effectifs sont vérifiés. Aucun fichier du jeu ou aucune sauvegarde n'est modifié par la préparation. Le jeu gère lui-même l'installation des effectifs téléchargés.

## Essai en jeu

Fermer le jeu, installer la version du serveur, puis redémarrer le serveur et FIFA 20. Entrer dans Ultimate Team et accepter la nouvelle mise à jour. Vérifier la carte de base de Lewandowski (89) et les identités des icônes. Les données, le téléchargement et la conservation du contenu serveur sont testés ; leur rendu en jeu reste à confirmer. Ne pas supprimer les sauvegardes.

Le test est annoncé durant une seule session serveur. Après la première demande du manifeste, `runtime/data/roster-update-test-1.8.44.done` empêche une nouvelle annonce au prochain démarrage du serveur. Les marqueurs précédents ne bloquent pas 2044. En cas d'échec, annuler puis redémarrer **le serveur et le jeu** pour revenir à l'entrée FUT sans demande forcée. Ce mécanisme désactive l'annonce ; il ne supprime pas des effectifs déjà acceptés par le jeu.

Pour réarmer volontairement le test, arrêter le serveur puis retirer uniquement ce marqueur, avant de redémarrer le serveur et le jeu. Les marqueurs et sauvegardes ne font pas partie du paquet distribué.
