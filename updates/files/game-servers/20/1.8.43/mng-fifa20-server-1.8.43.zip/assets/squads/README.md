# Correction des noms FUT — test 1.8.43

Le téléchargement natif de la version 1.8.42 a été accepté à 100 % par le jeu. Cependant, son fichier reprenait des références de noms du mode classique : la table de noms FUT utilise d'autres identifiants. Par exemple, l'identifiant 3632 correspond à « Boateng » en mode classique, mais à « Byrne » dans FUT.

- Version d'effectifs : **2043**, supérieure à 2042 pour remplacer les effectifs déjà téléchargés. Version du serveur : **1.8.43**.
- Le fichier reprend les 47 tables du groupe natif `squads`, lues sans modification dans le jeu ouvert : 20 045 joueurs, 792 équipes.
- Les quatre références de noms de chacun des 20 045 joueurs sont converties vers le dictionnaire FUT. Les noms absents sont ajoutés à la table dynamique, sans tronquer les accents ou écraser les entrées existantes. Les 80 180 références sont contrôlées ; aucune ne change le texte du nom d'origine.
- Aucun identifiant de joueur, transfert, note, statistique ou composition d'équipe ne change. Les cartes spéciales et récompenses du serveur sont conservées. Ce correctif n'ajoute pas encore leurs variantes dans la base native.
- Le fichier est au format de base natif, emballé en RefPack. Ses contrôles d'intégrité incluent les en-têtes, l'index, chaque table et le contrôle natif des lignes triées. Le serveur ne le propose pas si sa validation échoue.
- La fenêtre et le téléchargement sont natifs : aucun changement de FIFA20.exe, aucune injection et aucun besoin de Frosty Mod Manager.

## Essai en jeu

Fermer le jeu, installer la version du serveur, redémarrer le serveur puis FIFA 20. Entrer dans Ultimate Team et accepter la nouvelle mise à jour. Vérifier ensuite les noms de Boateng, Upamecano, Witsel, Ndombele, Tolisso et Tomiyasu dans l'équipe. La conversion des données et leur téléchargement sont testés ; le rendu du correctif en jeu reste à confirmer. Aucune suppression manuelle de sauvegarde n'est nécessaire pour proposer la version 2043.

Le test est annoncé durant une seule session serveur. Après la première demande du manifeste, `runtime/data/roster-update-test-1.8.43.done` empêche une nouvelle annonce au prochain démarrage du serveur. Le marqueur du test 1.8.42 ne bloque pas le correctif. En cas d'échec, annuler puis redémarrer **le serveur et le jeu** pour revenir à l'entrée FUT sans demande forcée. Le serveur ne supprime aucune sauvegarde. Ce mécanisme désactive l'annonce ; il ne supprime pas des effectifs déjà acceptés et enregistrés par le jeu.

Pour réarmer volontairement le test, arrêter le serveur puis retirer uniquement ce marqueur, avant de redémarrer le serveur et le jeu. Les marqueurs et sauvegardes ne font pas partie du paquet distribué.
