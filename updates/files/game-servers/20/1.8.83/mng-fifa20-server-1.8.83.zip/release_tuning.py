from __future__ import annotations
import copy
import json
import re
import math
import threading
import time
import urllib.parse
from pathlib import Path
from typing import Any
from storyline_catalog import DORMANT_STORYLINE_IDS, install as install_storyline_catalog
from season_pass_otw import SEASON_PASS_OTW_IDS, install as install_season_pass_otw
from hunter_season_reward import HUNTER_RESOURCE_ID, install as install_hunter_season_reward
from draft_tuning import install as install_draft_tuning
from draft_captain_safety import install as install_draft_captain_safety
from foundation_content import FALCAO_ID, FALCAO_PRIME_ID, DAVID_LUIZ_ID, DAVID_LUIZ_SET_ID, ARNAUTOVIC_ID, CILLESSEN_ID, CILLESSEN_SET_ID, BOJAN_ID, PLAYER_CATEGORY_ID, install_players as install_foundation_players, david_luiz_sbc, cillessen_sbc
from league_players import REWARD_IDS as LEAGUE_REWARD_IDS
from martinez_potm import RESOURCE_ID as MARTINEZ_POTM_ID, SET_ID as MARTINEZ_POTM_SET_ID, CHALLENGE_IMAGES as MARTINEZ_CHALLENGE_IMAGES, install_player as install_martinez_potm, sbc as martinez_potm_sbc
from pukki_potm import RESOURCE_ID as PUKKI_POTM_ID, SET_ID as PUKKI_POTM_SET_ID, CHALLENGE_IMAGES as PUKKI_CHALLENGE_IMAGES, install_player as install_pukki_potm, sbc as pukki_potm_sbc
from lewandowski_potm import RESOURCE_ID as LEWANDOWSKI_POTM_ID, SET_ID as LEWANDOWSKI_POTM_SET_ID, CHALLENGE_IMAGES as LEWANDOWSKI_CHALLENGE_IMAGES, install_player as install_lewandowski_potm, sbc as lewandowski_potm_sbc

MIXED_PACKS = {
    1: (1, 6, 1),
    2: (1, 6, 1),
    3: (1, 6, 1),
    8: (1, 6, 1),
    9: (2, 12, 2),
    10: (1, 6, 1),
    11: (2, 12, 2),
    12: (1, 6, 1),
    13: (2, 12, 2),
    1005: (1, 6, 1),
    1008: (2, 13, 3),
    1009: (2, 13, 3),
    1015: (2, 12, 2),
    1016: (2, 12, 2),
    1017: (1, 4, 2),
    1024: (1, 6, 1),
    1026: (2, 12, 2),
    1027: (1, 6, 1),
}

REMOVED_STORE_PACKS = {4, 5, 6, 7, 23, 24, 1031, 1033, 1034, 1035, 1037}
REMOVED_SBC_SET_IDS = {33, 34, 35, 36, 40, 41}
SBC_BADGES = {DAVID_LUIZ_SET_ID: "badge_davidluiz.png", CILLESSEN_SET_ID: "badge_cillessen.png",
              LEWANDOWSKI_POTM_SET_ID: "badge_potm_bundes.png"}
SBC_BADGE_REVISION = "mng-otw-badge-v2"
SBC_NATIVE_IMAGES = {1: "1001000", 2: "1000004-8c12d6f9-4923", 10: "1000002-89e9285a-7013",
                     11: "1000003-d31aeb07-ebaa", 20: "1007000", 21: "1008000", 22: "1009000",
                     30: "1003000", 31: "1005000", 32: "1006000", 55: "1013000", 56: "1010000"}
SBC_UI_LOCALE = threading.local()
POTM_SET_TEXTS = {
    55: {
        "fr": ("Josef Martinez", "Gagnez Josef Martinez, joueur du mois de la MLS en août."),
        "en": ("Josef Martinez", "Earn the MLS Player of the Month for August, Josef Martinez"),
    },
    56: {
        "fr": ("Teemu Pukki", "Gagnez Teemu Pukki, joueur du mois de Premier League en août."),
        "en": ("Teemu Pukki", "Earn the Premier League Player of the Month for August, Teemu Pukki"),
    },
    57: {
        "fr": ("Robert Lewandowski", "Gagnez Robert Lewandowski, joueur du mois de Bundesliga."),
        "en": ("Robert Lewandowski", "Earn Robert Lewandowski, Bundesliga Player of the Month."),
    },
}
ADVANCED_GROUP_REWARD_PACK_ID = 1028
PROMO_STORE_ORDER = {15: 1, 1008: 2, 16: 3, 17: 4, 1009: 5, 18: 6}
STORE_POINT_PRICES = {
    1: 10, 2: 50, 3: 100, 8: 15, 9: 30, 10: 75, 11: 150,
    12: 150, 13: 300, 14: 250, 15: 350, 16: 600, 17: 1000,
    18: 2000, 19: 100, 20: 100, 22: 100, 1008: 700, 1009: 1100,
}
MARKET_LIVE_BASE = 1180000
MARKET_LIVE_SWING = 90000
FEATURE_DISABLED_MESSAGE = "This online mode is not available in MNG FUT 20 local mode."
JAMES_FLASHBACK_REAL_ID = 839059510
JAMES_FLASHBACK_BAYERN_ID = 855836726
JAMES_FLASHBACK_PORTO_ID = 872613942
JAMES_FLASHBACK_MONACO_ID = 889391158
ROBBEN_BABY_ICON_ID = 16786230
JUNINHO_BABY_ICON_ID = 16777246
BOATENG_REGULAR_ID = 183907
RAMI_REGULAR_ID = 183280
BOATENG_UCL_ID = 805490275
DAVIES_MOMENTS_ID = 50566044
TOLISSO_STORYLINE_ID = 50551331
RAMI_STORYLINE_ID = 50514928
PODOLSKI_STORYLINE_ID = 50482164
HERNANDEZ_STORYLINE_ID = 50509872
NDOMBELE_OTW_ID = 352557105
EXCLUSIVE_REWARD_IDS = {DAVIES_MOMENTS_ID, TOLISSO_STORYLINE_ID, RAMI_STORYLINE_ID,
                        PODOLSKI_STORYLINE_ID, HERNANDEZ_STORYLINE_ID, NDOMBELE_OTW_ID,
                        FALCAO_ID, FALCAO_PRIME_ID, DAVID_LUIZ_ID, ARNAUTOVIC_ID, CILLESSEN_ID, BOJAN_ID, MARTINEZ_POTM_ID, PUKKI_POTM_ID, LEWANDOWSKI_POTM_ID} | LEAGUE_REWARD_IDS
PLAYER_SBC_REWARDS = {52: DAVIES_MOMENTS_ID, DAVID_LUIZ_SET_ID: DAVID_LUIZ_ID,
                      CILLESSEN_SET_ID: CILLESSEN_ID, MARTINEZ_POTM_SET_ID: MARTINEZ_POTM_ID,
                      PUKKI_POTM_SET_ID: PUKKI_POTM_ID, LEWANDOWSKI_POTM_SET_ID: LEWANDOWSKI_POTM_ID}
EXCLUSIVE_REWARD_IDS = EXCLUSIVE_REWARD_IDS | SEASON_PASS_OTW_IDS | {HUNTER_RESOURCE_ID}
UNAVAILABLE_MARKET_PACK_IDS = EXCLUSIVE_REWARD_IDS | DORMANT_STORYLINE_IDS


def _install_rami_regular(module: Any) -> None:
    player = copy.deepcopy(module.PLAYER_DB[RAMI_REGULAR_ID])
    if (player["assetId"], player["rating"], player["preferredPosition"], player["face"]) != (RAMI_REGULAR_ID, 78, "CB", [47, 48, 53, 60, 76, 81]):
        raise ValueError("Unexpected FIFA 20 Rami regular definition")
    player.update({"weight": 90, "packEligible": True, "marketEligible": True, "untradeable": False,
                   "nativeDatabase": {"table": "mng-rami-2048.players", "playerId": RAMI_REGULAR_ID,
                                      "headAssetId": RAMI_REGULAR_ID}})
    module.PLAYER_DB[RAMI_REGULAR_ID] = player


def _install_exclusive_rewards(module: Any) -> None:
    specifications = (
        (235569, NDOMBELE_OTW_ID, 81, 21, "Ones to Watch", "ones_to_watch", "CM",
         [80, 65, 78, 87, 70, 78], {}),
        (234396, DAVIES_MOMENTS_ID, 86, 90, "Player Moments", "player_moments", "LB",
         [95, 70, 80, 84, 81, 82], {
             "acceleration": 97, "sprintSpeed": 92, "positioning": 70, "finishing": 68,
             "shotPower": 76, "longShots": 67, "volleys": 59, "penalties": 64,
             "vision": 85, "crossing": 81, "freeKickAccuracy": 57, "shortPassing": 83,
             "longPassing": 66, "curve": 83, "agility": 94, "balance": 86,
             "reactions": 75, "ballControl": 81, "dribbling": 85, "composure": 78,
             "interceptions": 76, "headingAccuracy": 75, "marking": 81,
             "standingTackle": 89, "slidingTackle": 75, "jumping": 84, "stamina": 86,
             "strength": 80, "aggression": 79,
         }),
        (219683, TOLISSO_STORYLINE_ID, 85, 91, "Season Reward", "season_reward", "CM",
         [76, 82, 84, 83, 82, 85], {
             "acceleration": 80, "sprintSpeed": 72, "positioning": 84, "finishing": 79,
             "shotPower": 87, "longShots": 86, "volleys": 66, "penalties": 74,
             "vision": 85, "crossing": 71, "freeKickAccuracy": 77, "shortPassing": 89,
             "longPassing": 91, "curve": 70, "agility": 79, "balance": 78,
             "reactions": 88, "ballControl": 87, "dribbling": 81, "composure": 78,
             "interceptions": 82, "headingAccuracy": 88, "marking": 80,
             "standingTackle": 84, "slidingTackle": 76, "jumping": 89, "stamina": 90,
             "strength": 81, "aggression": 87,
         }),
        (183280, RAMI_STORYLINE_ID, 84, 91, "Season Reward", "season_reward", "CB",
         [67, 58, 70, 65, 82, 85], {
             "acceleration": 61, "sprintSpeed": 72, "positioning": 34, "finishing": 55,
             "shotPower": 80, "longShots": 51, "volleys": 49, "penalties": 58,
             "vision": 61, "crossing": 53, "freeKickAccuracy": 72, "shortPassing": 81,
             "longPassing": 83, "curve": 60, "agility": 55, "balance": 58,
             "reactions": 78, "ballControl": 72, "dribbling": 61, "composure": 78,
             "interceptions": 81, "headingAccuracy": 80, "marking": 83,
             "standingTackle": 84, "slidingTackle": 80, "jumping": 80, "stamina": 67,
             "strength": 95, "aggression": 82,
         }),
        (150516, PODOLSKI_STORYLINE_ID, 84, 91, "Season Reward", "season_reward", "CF",
         [80, 86, 84, 83, 54, 85], {
             "acceleration": 77, "sprintSpeed": 82, "positioning": 77, "finishing": 82,
             "shotPower": 97, "longShots": 82, "volleys": 91, "penalties": 90,
             "vision": 84, "crossing": 84, "freeKickAccuracy": 85, "shortPassing": 85,
             "longPassing": 77, "curve": 88, "agility": 72, "balance": 74,
             "reactions": 82, "ballControl": 86, "dribbling": 85, "composure": 87,
             "interceptions": 44, "headingAccuracy": 74, "marking": 62,
             "standingTackle": 47, "slidingTackle": 47, "jumping": 80, "stamina": 76,
             "strength": 93, "aggression": 79,
         }),
        (178224, HERNANDEZ_STORYLINE_ID, 84, 91, "Season Reward", "season_reward", "ST",
         [82, 84, 70, 81, 37, 67], {
             "acceleration": 87, "sprintSpeed": 78, "positioning": 92, "finishing": 90,
             "shotPower": 82, "longShots": 73, "volleys": 79, "penalties": 81,
             "vision": 76, "crossing": 70, "freeKickAccuracy": 58, "shortPassing": 71,
             "longPassing": 62, "curve": 73, "agility": 81, "balance": 84,
             "reactions": 86, "ballControl": 83, "dribbling": 78, "composure": 85,
             "interceptions": 32, "headingAccuracy": 84, "marking": 27,
             "standingTackle": 35, "slidingTackle": 31, "jumping": 91, "stamina": 73,
             "strength": 61, "aggression": 67,
         }),
    )
    for asset_id, resource_id, rating, rareflag, rarity_name, rarity_class, position, face, attributes in specifications:
        player = copy.deepcopy(module.PLAYER_DB[asset_id])
        player.update({"resourceId": resource_id, "rating": rating, "rareflag": rareflag,
                       "rarityName": rarity_name, "rarityClass": rarity_class,
                       "preferredPosition": position, "face": face, "tier": "gold",
                       "special": True, "untradeable": True, "packEligible": False,
                       "marketEligible": False})
        player["attributes"].update(attributes)
        if resource_id == HERNANDEZ_STORYLINE_ID:
            player.update(teamid=481, teamName="Sevilla FC", leagueId=53,
                          leagueName="Spain Primera División (1)")
        module.PLAYER_DB[resource_id] = player


def grant_exclusive_reward(state: Any, resource_id: int, marker: str, pile: str = "unassigned") -> dict[str, Any] | None:
    if resource_id not in EXCLUSIVE_REWARD_IDS:
        raise ValueError("Not an exclusive reward")
    with state.lock:
        state.conn.execute("BEGIN IMMEDIATE")
        try:
            prior = state.conn.execute("SELECT value FROM kv WHERE key=?", (marker,)).fetchone()
            if prior:
                state.conn.rollback()
                return None
            counter = state.conn.execute("SELECT value FROM kv WHERE key='next_item_id'").fetchone()
            maximum = state.conn.execute("SELECT COALESCE(MAX(id),0) FROM items").fetchone()[0]
            item_id = max(int(json.loads(counter[0])) if counter else 900000000000, maximum) + 1
            item = state.build_player_item(resource_id, item_id, pile)
            item.update({"untradeable": True, "discardValue": 0})
            state.conn.execute("INSERT INTO items(id,resource_id,pile,data) VALUES(?,?,?,?)",
                               (item_id, resource_id, pile, json.dumps(item)))
            state.conn.execute("INSERT INTO kv(key,value) VALUES('next_item_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                               (json.dumps(item_id),))
            state.conn.execute("INSERT INTO kv(key,value) VALUES(?,?)", (marker, json.dumps(item_id)))
            state.conn.commit()
            return item
        except Exception:
            state.conn.rollback()
            raise


def _davies_sbc() -> dict[str, Any]:
    challenges = []
    for challenge_id, name, chemistry in ((5201, "Bundesliga", 80), (5202, "84-Rated Squad", 75)):
        rules = [
            {"kind": "player_count", "value": 11, "scope": "exact", "count": -1, "text": "Players in the Squad: 11"},
            {"kind": "team_rating", "value": 84, "scope": "min", "count": -1, "text": "Team Rating: Min. 84"},
            {"kind": "chemistry", "value": chemistry, "scope": "min", "count": -1, "text": f"Team Chemistry: Min. {chemistry}"},
            {"kind": "totw_count", "value": 3, "scope": "min", "count": 1, "text": "TOTW Players: Min. 1"},
        ]
        if challenge_id == 5201:
            rules.append({"kind": "league_players", "value": 19, "scope": "min", "count": 1,
                          "text": "Bundesliga Players: Min. 1"})
        challenges.append({"challenge_id": challenge_id, "name": name, "description": "Exchange a squad to earn Alphonso Davies Player Moments.",
                           "players": 11, "formation": "f442", "rules": rules, "awards": []})
    return {"set_id": 52, "category_id": 2, "category": "ADVANCED", "priority": 2,
            "name": "Player Moments : Alphonso Davies", "description": "Complete both challenges to earn untradeable Alphonso Davies 86 LB.",
            "repeatable": False, "awards": [{"type": "PLAYER", "value": DAVIES_MOMENTS_ID, "count": 1}],
            "challenges": challenges}


def _repair_exclusive_reward_items(module: Any) -> None:
    for item in module.STATE.list_items():
        resource_id = int(item.get("resourceId", 0) or 0)
        if resource_id not in EXCLUSIVE_REWARD_IDS:
            continue
        reference = module.STATE.build_player_item(resource_id, int(item["id"]), item.get("pile", "club"))
        fields = {key: reference[key] for key in ("assetId", "rating", "rareflag", "attributeList", "untradeable", "discardValue")}
        if any(item.get(key) != value for key, value in fields.items()):
            module.STATE.update_item_fields(int(item["id"]), fields)

TOTW1_SPECS = (
    (167495, 89), (211256, 84), (165229, 84), (197853, 82), (193283, 84),
    (228702, 86), (139068, 83), (208093, 84), (208722, 89), (165153, 88),
    (175943, 88), (173426, 82), (177604, 82), (228251, 82), (41236, 86),
    (215061, 82), (231447, 81), (231352, 81), (223982, 71), (239768, 75),
    (239085, 82), (212228, 76), (236474, 75),
)

OTW_SPECS = (
    (229880, 79), (235243, 85), (220814, 84), (203263, 82), (228702, 86),
    (231866, 85), (224232, 80), (212194, 84), (198950, 83), (226110, 83),
    (203486, 82), (221992, 82), (183277, 91), (189242, 86), (227796, 79),
    (242444, 80), (194765, 89), (201399, 85), (192505, 85), (232432, 83),
    (205693, 83), (199451, 83), (223334, 78),
)

UCL_BASE_RARITIES = {47, 48}
UCL_2019_20_TEAM_IDS = {
    5, 9, 10, 18, 21, 22, 32, 39, 44, 48, 65, 66, 73, 191, 211,
    231, 234, 240, 241, 243, 245, 266, 280, 325, 461, 673, 100765,
    101059, 112172, 114153,
}


def _promotional_player(base: dict[str, Any], rating: int, rareflag: int, rarity_name: str, rarity_class: str) -> dict[str, Any]:
    player = copy.deepcopy(base)
    asset_id = int(player.get("assetId", player.get("resourceId", 0)) or 0)
    old_rating = int(player.get("rating", 0) or 0)
    increase = max(0, int(rating) - old_rating)
    player["resourceId"] = asset_id + rareflag * 16777216
    player["rating"] = int(rating)
    player["rareflag"] = rareflag
    player["rarityName"] = rarity_name
    player["rarityClass"] = rarity_class
    player["tier"] = "gold" if rating >= 75 else ("silver" if rating >= 65 else "bronze")
    player["special"] = True
    if increase:
        player["face"] = [min(99, int(value) + increase * 2) for value in player.get("face", [])]
        attributes = player.get("attributes", {})
        for key, value in list(attributes.items()):
            if key != "gkSpeed":
                attributes[key] = min(99, int(value) + increase * 2)
    return player


def _install_launch_promotions(module: Any) -> None:
    for asset_id, rating in TOTW1_SPECS:
        base = module.PLAYER_DB.get(asset_id)
        if base:
            player = _promotional_player(base, rating, 3, "Team of the Week", "totw")
            module.PLAYER_DB[int(player["resourceId"])] = player
    for asset_id, rating in OTW_SPECS:
        base = module.PLAYER_DB.get(asset_id)
        if base:
            reference = module.PLAYER_DB.get(asset_id + 48 * 16777216, base)
            player = _promotional_player(reference, int(reference["rating"]), 21, "Ones to Watch", "otw")
            module.PLAYER_DB[int(player["resourceId"])] = player
    if isinstance(getattr(module, "_special_pool_counts", None), dict):
        module._special_pool_counts[3] = len(TOTW1_SPECS)
        module._special_pool_counts[21] = len(OTW_SPECS)


def _totw1_squad(module: Any) -> dict[str, Any]:
    squad = copy.deepcopy(module._native_squad_battle_opponent(0))
    players = []
    for index, (asset_id, rating) in enumerate(TOTW1_SPECS):
        resource_id = asset_id + 3 * 16777216
        if resource_id not in module.PLAYER_DB:
            raise ValueError(f"TOTW1_PLAYER_MISSING:{asset_id}")
        item = module._native_player_item(module.STATE.build_player_item(resource_id, 950000 + index, "none"))
        item.update({"formation": "f343", "untradeable": True, "discardValue": 0})
        players.append({"index": index, "kitNumber": index + 1, "itemData": item})
    squad.update({"id": 1, "squadId": 1, "featuredSquadId": 1, "squadName": "TOTW 1",
                  "name": "TOTW 1", "clubName": "TOTW 1", "clubAbbr": "TOTW",
                  "displayName": "TOTW 1", "teamName": "TOTW 1", "ownerName": "TOTW 1",
                  "personaName": "TOTW 1", "formation": "f343", "chemistry": 100,
                  "rating": round(sum(rating for asset_id, rating in TOTW1_SPECS[:11]) / 11),
                  "captain": players[0]["itemData"]["id"], "players": players,
                  "custom": "[0,0,0,0,0,0,0,0,0,0,0]"})
    squad["starRating"] = squad["rating"]
    return squad


def _totw1_feature_stats(module: Any) -> dict[str, Any]:
    squad = _totw1_squad(module)
    state = module._sb_state()
    entry = next((entry for entry in state.get("opponents", []) if entry.get("id") == 4), {})
    squad.update({"available": True, "featuredSquadAvailable": True, "enabled": True,
                  "endTime": int(state["competitionEnd"]), "endTimeStamp": int(state["competitionEnd"]),
                  "nextFeatureSquadTimeStamp": int(state["competitionEnd"]),
                  "bannerImageName": "mng-totw1.png", "difficultyBasedWinPoints": [round(400 * difficulty[1]) for difficulty in module._SB_DIFFICULTIES],
                  "difficultyBasedLossPoints": [round(250 * difficulty[2]) for difficulty in module._SB_DIFFICULTIES],
                  "basePointsWin": 400, "basePointsLoss": 250, "score": int(entry.get("score", -1)),
                  "oppScore": int(entry.get("oppScore", -1)),
                  "pointsWon": int(entry.get("pointsWon", 0)) if entry.get("played", False) else -1,
                  "played": bool(entry.get("played", False))})
    return squad


def _install_custom_baby_icons(module: Any) -> None:
    icons = (
        {
            "name": "Robben", "firstName": "Arjen", "lastName": "Robben", "commonName": "",
            "rating": 86, "preferredPosition": "LM", "preferredFoot": "Left",
            "workRateAttack": "High", "workRateDefense": "Low", "weakFoot": 2, "skillMoves": 4,
            "dateOfBirth": "1984-01-23", "height": 180, "weight": 80,
            "nation": 34, "nationName": "Netherlands", "assetId": 9014,
            "resourceId": ROBBEN_BABY_ICON_ID, "face": [92, 84, 78, 86, 39, 59],
            "attributes": {
                "acceleration": 93, "sprintSpeed": 91, "positioning": 86, "finishing": 84,
                "shotPower": 86, "longShots": 86, "volleys": 83, "penalties": 78,
                "vision": 81, "crossing": 78, "freeKickAccuracy": 78, "shortPassing": 80,
                "longPassing": 70, "curve": 87, "agility": 89, "balance": 86,
                "reactions": 85, "ballControl": 87, "dribbling": 86, "composure": 84,
                "interceptions": 40, "headingAccuracy": 45, "marking": 37,
                "standingTackle": 38, "slidingTackle": 34, "jumping": 57, "stamina": 68,
                "strength": 58, "aggression": 48,
            },
        },
        {
            "name": "Juninho", "firstName": "Juninho", "lastName": "Pernambucano",
            "commonName": "Juninho", "rating": 86, "preferredPosition": "CM",
            "preferredFoot": "Right", "workRateAttack": "High", "workRateDefense": "Medium",
            "weakFoot": 4, "skillMoves": 4, "dateOfBirth": "1975-01-30", "height": 178,
            "weight": 74, "nation": 54, "nationName": "Brazil", "assetId": 30,
            "resourceId": JUNINHO_BABY_ICON_ID, "face": [83, 78, 86, 84, 75, 73],
            "attributes": {
                "acceleration": 84, "sprintSpeed": 82, "positioning": 80, "finishing": 74,
                "shotPower": 88, "longShots": 87, "volleys": 76, "penalties": 84,
                "vision": 88, "crossing": 86, "freeKickAccuracy": 94, "shortPassing": 88,
                "longPassing": 86, "curve": 93, "agility": 83, "balance": 82,
                "reactions": 85, "ballControl": 86, "dribbling": 83, "composure": 88,
                "interceptions": 77, "headingAccuracy": 65, "marking": 73,
                "standingTackle": 77, "slidingTackle": 73, "jumping": 70, "stamina": 80,
                "strength": 70, "aggression": 72,
            },
        },
    )
    variants = list(icons)
    attribute_groups = (
        ("acceleration", "sprintSpeed"),
        ("positioning", "finishing", "shotPower", "longShots", "volleys", "penalties"),
        ("vision", "crossing", "freeKickAccuracy", "shortPassing", "longPassing", "curve"),
        ("agility", "balance", "reactions", "ballControl", "dribbling", "composure"),
        ("interceptions", "headingAccuracy", "marking", "standingTackle", "slidingTackle"),
        ("jumping", "stamina", "strength", "aggression"),
    )
    for base, rating, position, face, version_offset in (
        (icons[0], 88, "RM", [90, 87, 80, 88, 51, 61], 2),
        (icons[0], 90, "RM", [93, 90, 82, 91, 55, 67], 3),
        (icons[1], 88, "CAM", [77, 83, 90, 86, 68, 76], 2),
        (icons[1], 90, "CAM", [81, 85, 92, 88, 73, 80], 3),
    ):
        player = copy.deepcopy(base)
        player.update(rating=rating, preferredPosition=position, face=face,
                      resourceId=int(base["assetId"]) + version_offset * 16777216)
        for group_index, attributes in enumerate(attribute_groups):
            difference = face[group_index] - base["face"][group_index]
            for attribute in attributes:
                player["attributes"][attribute] = max(1, min(99, player["attributes"][attribute] + difference))
        variants.append(player)
    for player in variants:
        player.update({
            "leagueId": 2118, "leagueName": "Icons", "teamid": 112658,
            "teamName": "Icons", "cardsubtypeid": 0, "rareflag": 12,
            "rarityName": "Icon", "rarityClass": "legend", "tier": "gold", "special": True,
        })
        player["attributes"].update({
            "gkDiving": 0, "gkHandling": 0, "gkKicking": 0,
            "gkReflexes": 0, "gkSpeed": 0, "gkPositioning": 0,
        })
        module.PLAYER_DB[int(player["resourceId"])] = player
    if isinstance(getattr(module, "_special_pool_counts", None), dict):
        module._special_pool_counts[12] = int(module._special_pool_counts.get(12, 0)) + len(variants)


def _install_base_ucl_cards(module: Any) -> dict[int, int]:
    counts = {47: 0, 48: 0}
    for resource_id, base in list(module.PLAYER_DB.items()):
        asset_id = int(base.get("assetId", resource_id) or resource_id)
        base_rarity = int(base.get("rareflag", 0) or 0)
        if int(resource_id) != asset_id or base_rarity not in {0, 1}:
            continue
        if int(base.get("teamid", 0) or 0) not in UCL_2019_20_TEAM_IDS:
            continue
        ucl_rarity = 48 if base_rarity == 1 else 47
        player = copy.deepcopy(base)
        player["resourceId"] = asset_id + ucl_rarity * 16777216
        player["rareflag"] = ucl_rarity
        player["rarityName"] = "UEFA Champions League Rare" if ucl_rarity == 48 else "UEFA Champions League Common"
        player["rarityClass"] = "ucl_rare" if ucl_rarity == 48 else "ucl_common"
        player["special"] = True
        module.PLAYER_DB[int(player["resourceId"])] = player
        counts[ucl_rarity] += 1
    if isinstance(getattr(module, "_special_pool_counts", None), dict):
        module._special_pool_counts.update(counts)
    if isinstance(getattr(module, "DEFAULT_SPECIAL_WEIGHTS", None), dict):
        module.DEFAULT_SPECIAL_WEIGHTS.setdefault("47", 4)
    if isinstance(getattr(module, "PROMO_SPECIAL_WEIGHTS", None), dict):
        module.PROMO_SPECIAL_WEIGHTS.setdefault("47", 5)
    return counts


def _boost_base_ucl_cards(module: Any) -> int:
    boosted = 0
    for player in module.PLAYER_DB.values():
        if int(player.get("rareflag", 0) or 0) not in UCL_BASE_RARITIES:
            continue
        if player.get("_mngFifa19UclBoost"):
            continue
        player["rating"] = min(99, int(player.get("rating", 0) or 0) + 1)
        player["face"] = [min(99, int(value) + 1) for value in player.get("face", [])]
        attributes = player.get("attributes")
        if isinstance(attributes, dict):
            for key, value in list(attributes.items()):
                numeric_value = int(value)
                if numeric_value > 0:
                    attributes[key] = min(99, numeric_value + 1)
        player["_mngFifa19UclBoost"] = True
        boosted += 1
    return boosted


def _james_flashback_player(
    resource_id: int,
    team_id: int,
    team_name: str,
    league_id: int,
    league_name: str,
    rating: int = 88,
    position: str = "CAM",
    face: list[int] | None = None,
) -> dict[str, Any]:
    face = face or [77, 86, 89, 86, 56, 70]
    player = {
        "name": "Rodríguez",
        "firstName": "James",
        "lastName": "Rodríguez",
        "commonName": "James Rodríguez",
        "rating": rating,
        "preferredPosition": position,
        "preferredFoot": "Left",
        "workRateAttack": "High",
        "workRateDefense": "Medium",
        "weakFoot": 4,
        "skillMoves": 4,
        "dateOfBirth": "1991-07-12",
        "height": 180,
        "weight": 75,
        "leagueId": league_id,
        "leagueName": league_name,
        "teamid": team_id,
        "teamName": team_name,
        "nation": 56,
        "nationName": "Colombia",
        "assetId": 198710,
        "resourceId": resource_id,
        "cardsubtypeid": 0,
        "rareflag": 51,
        "rarityName": "Flashback",
        "rarityClass": "flashback",
        "tier": "gold",
        "special": True,
        "face": face,
        "attributes": {
            "acceleration": 77, "sprintSpeed": 74, "positioning": 87,
            "finishing": 86, "shotPower": 88, "longShots": 89,
            "volleys": 86, "penalties": 82, "vision": 91,
            "crossing": 89, "freeKickAccuracy": 90, "shortPassing": 90,
            "longPassing": 89, "curve": 91, "agility": 86,
            "balance": 84, "reactions": 88, "ballControl": 88,
            "dribbling": 86, "composure": 89, "interceptions": 56,
            "headingAccuracy": 66, "marking": 56, "standingTackle": 55,
            "slidingTackle": 48, "jumping": 69, "stamina": 70,
            "strength": 72, "aggression": 63,
            "gkDiving": 0, "gkHandling": 0, "gkKicking": 0,
            "gkReflexes": 0, "gkSpeed": 0, "gkPositioning": 0,
        },
    }
    if rating == 85:
        pace, shooting, passing, dribbling, defending, physical = face
        player["attributes"].update({
            "acceleration": min(99, pace + 2), "sprintSpeed": max(1, pace - 1),
            "positioning": shooting + 2, "finishing": shooting, "shotPower": shooting + 2,
            "longShots": shooting + 2, "volleys": shooting, "penalties": shooting - 2,
            "vision": passing + 3, "crossing": passing + 1, "freeKickAccuracy": passing + 2,
            "shortPassing": passing + 2, "longPassing": passing + 1, "curve": passing + 3,
            "agility": dribbling + 1, "balance": dribbling - 1, "reactions": dribbling,
            "ballControl": dribbling + 1, "dribbling": dribbling, "composure": dribbling + 1,
            "interceptions": defending, "headingAccuracy": defending + 5, "marking": defending,
            "standingTackle": defending - 1, "slidingTackle": defending - 6,
            "jumping": physical, "stamina": physical + 2, "strength": physical + 1,
            "aggression": physical - 3,
        })
    return player



def _market_live_count(actual: int = 0) -> int:
    tick = int(time.time() // 45)
    span = MARKET_LIVE_SWING * 2 + 1
    offset = ((tick * 7919 + 104729) % span) - MARKET_LIVE_SWING
    return max(1000000, int(actual or 0), MARKET_LIVE_BASE + offset)


def _route_path(raw_path: str) -> str:
    path = urllib.parse.urlsplit(str(raw_path or "")).path.lower()
    if path.startswith("/ut/ut/"):
        path = "/ut/" + path[7:]
    return path


def _sbc_badge_asset(path: str) -> Path | None:
    for image_id in (*MARTINEZ_CHALLENGE_IMAGES.values(), *PUKKI_CHALLENGE_IMAGES.values(), *LEWANDOWSKI_CHALLENGE_IMAGES.values()):
        if path == f"/fut/sbc/gen4/challenges/images/sbc_challenge_image_{image_id}.png":
            return Path(__file__).resolve().parent / "assets" / "sbc" / f"sbc_challenge_image_{image_id}.png"
    for image_id in SBC_NATIVE_IMAGES.values():
        if path == f"/fut/sbc/gen4/sets/images/sbc_set_image_{image_id}.png":
            return Path(__file__).resolve().parent / "assets" / "sbc" / f"sbc_set_image_{image_id}.png"
    matched = re.fullmatch(r"/fut/sbc/gen4/sets/images/sbc_set_image_(\d+)-(?:localfut20-sbc|mng-otw-badge-v1|" + SBC_BADGE_REVISION + r")\.png", path)
    if not matched:
        return None
    filename = SBC_BADGES.get(int(matched.group(1)) - 1000000)
    return Path(__file__).resolve().parent / "assets" / "sbc" / filename if filename else None


def _sbc_request_locale(headers: dict[str, str], raw_path: str) -> str:
    normalized_headers = {str(key).lower(): str(value) for key, value in (headers or {}).items()}
    query = urllib.parse.parse_qs(urllib.parse.urlsplit(str(raw_path or "")).query)
    requested = (query.get("language", query.get("locale", query.get("lang", [""])))[0]
                 or normalized_headers.get("x-ut-language", "")
                 or normalized_headers.get("accept-language", "fr"))
    return "en" if str(requested).lower().replace("_", "-").startswith("en") else "fr"


def _localized_potm_set(summary: dict[str, Any], set_id: int) -> dict[str, Any]:
    localized = POTM_SET_TEXTS.get(int(set_id))
    if localized:
        name, description = localized.get(getattr(SBC_UI_LOCALE, "value", "fr"), localized["fr"])
        summary["name"] = name
        summary["description"] = description
    return summary


def _disabled_mode(path: str) -> str:
    low = str(path or "").lower()
    if "/rivals/" in low or low.endswith("/rivals"):
        return "Division Rivals"
    if "/champion/" in low or "/champions/" in low or low.endswith("/champion") or low.endswith("/champions"):
        return "FUT Champions"
    return ""

def _round_half_up(value: float) -> int:
    return int(math.floor(float(value) + 0.5))


def fifa20_player_quick_sell(module: Any, resource_id: int) -> int:
    if int(resource_id) in UNAVAILABLE_MARKET_PACK_IDS:
        return 0
    rid = module.canonical_player_resource_id(int(resource_id))
    meta = module.player_meta(rid) or {}
    rating = max(0, int(meta.get("rating", 0) or 0))
    rareflag = int(meta.get("rareflag", 0) or 0)
    special = bool(meta.get("special", False)) or rareflag > 1
    rarity_name = str(meta.get("rarityName", "") or "").strip().lower()
    rarity_class = str(meta.get("rarityClass", "") or "").strip().lower()
    if not special:
        if rating >= 75:
            return int(rating * (8 if rareflag == 1 else 4))
        if rating >= 65:
            return _round_half_up(rating * (3.5 if rareflag == 1 else 1.5))
        return _round_half_up(rating * (0.75 if rareflag == 1 else 0.30))
    if rarity_class == "toty" or rarity_name == "team of the year":
        return int(rating * 800)
    if rareflag in {12, 84} or rarity_name == "icon" or rarity_name.startswith("icon moments"):
        return int(rating * 750)
    if rating >= 75:
        return int(rating * 122)
    if rating >= 65:
        return int(rating * 70)
    return int(rating * 20)


def _regular_rating_weight(rating: int) -> float:
    table = {81: 0.90, 82: 0.80, 83: 0.65, 84: 0.50, 85: 0.36, 86: 0.25, 87: 0.17, 88: 0.11, 89: 0.07, 90: 0.045, 91: 0.028, 92: 0.017, 93: 0.010, 94: 0.006}
    if rating <= 80:
        return 1.0
    if rating >= 95:
        return 0.003
    return table.get(int(rating), 0.003)


def _special_rating_weight(rating: int) -> float:
    table = {85: 0.85, 86: 0.72, 87: 0.60, 88: 0.48, 89: 0.38, 90: 0.29, 91: 0.22, 92: 0.16, 93: 0.115, 94: 0.080, 95: 0.055, 96: 0.038, 97: 0.025, 98: 0.016, 99: 0.010}
    if rating <= 84:
        return 1.0
    return table.get(int(rating), 0.010 if rating >= 99 else 1.0)


def _tier(rating: int) -> str:
    rating = int(rating or 0)
    if rating >= 75:
        return "gold"
    if rating >= 65:
        return "silver"
    return "bronze"


def _is_special(module: Any, item: dict[str, Any]) -> bool:
    rid = int(item.get("resourceId", item.get("assetId", 0)) or 0)
    meta = module.PLAYER_DB.get(rid, {}) or module.player_meta(rid) or {}
    return bool(meta.get("special", False)) or int(item.get("rareflag", meta.get("rareflag", 0)) or 0) > 1


def _pool(module: Any, kind: str, tier: str, rare: bool) -> list[int]:
    if kind == "manager":
        return [int(rid) for rid, meta in module.MANAGER_DB.items() if _tier(int(meta.get("rating", 0) or 0)) == tier and (int(meta.get("rareflag", 0) or 0) > 0) == rare]
    if kind == "consumable":
        return [int(rid) for rid, meta in module.CONSUMABLE_DB.items() if _tier(int(meta.get("rating", 0) or 0)) == tier and (int(meta.get("rareflag", 0) or 0) > 0) == rare]
    if kind == "club_kit":
        native = list(dict.fromkeys(list(getattr(module, "_NATIVE_HOME_KITS", [])) + list(getattr(module, "_NATIVE_AWAY_KITS", []))))
        return [int(rid) for rid in native if int(rid) in module.CLUB_ITEM_DB and (int(module.CLUB_ITEM_DB[int(rid)].get("rareflag", 0) or 0) > 0) == rare]
    if kind == "club_badge":
        native = list(dict.fromkeys(list(getattr(module, "_NATIVE_BADGES", []))))
        return [int(rid) for rid in native if int(rid) in module.CLUB_ITEM_DB and (int(module.CLUB_ITEM_DB[int(rid)].get("rareflag", 0) or 0) > 0) == rare]
    return []


def _pick_resource(module: Any, original_choice, kind: str, tier: str, rare: bool, used: set[int]) -> int | None:
    candidates = [rid for rid in _pool(module, kind, tier, rare) if rid not in used]
    if not candidates:
        candidates = [rid for rid in _pool(module, kind, tier, not rare) if rid not in used]
    if not candidates:
        return None
    return int(original_choice(candidates))


def _pick_consumable(module: Any, original_choice, original_shuffle, tier: str, rare: bool, used: set[int], used_groups: set[int]) -> int | None:
    groups = [list(group) for group in module._consumable_pack_groups()]
    group_indexes = list(range(len(groups)))
    original_shuffle(group_indexes)
    for wanted_rare in (rare, not rare):
        for gi in group_indexes:
            if gi in used_groups:
                continue
            candidates = []
            for rid in groups[gi]:
                rid = int(rid)
                meta = module.CONSUMABLE_DB.get(rid, {})
                if rid in used or _tier(int(meta.get("rating", 0) or 0)) != tier:
                    continue
                if (int(meta.get("rareflag", 0) or 0) > 0) != wanted_rare:
                    continue
                candidates.append(rid)
            if candidates:
                used_groups.add(gi)
                return int(original_choice(candidates))
    positions = []
    for rid, meta in module.CONSUMABLE_DB.items():
        rid = int(rid)
        if rid in used or str(meta.get("sourceMember", "")) != "consumablesPosition":
            continue
        if _tier(int(meta.get("rating", 0) or 0)) != tier:
            continue
        positions.append(rid)
    exact = [rid for rid in positions if (int(module.CONSUMABLE_DB[rid].get("rareflag", 0) or 0) > 0) == rare]
    if exact:
        return int(original_choice(exact))
    if positions:
        return int(original_choice(positions))
    return _pick_resource(module, original_choice, "consumable", tier, rare, used)


def _make_non_player(module: Any, state: Any, original_choice, original_shuffle, kind: str, source: dict[str, Any], used: set[int], used_groups: set[int]) -> dict[str, Any] | None:
    tier = _tier(int(source.get("rating", 0) or 0))
    rare = int(source.get("rareflag", 0) or 0) > 0
    if kind == "consumable":
        rid = _pick_consumable(module, original_choice, original_shuffle, tier, rare, used, used_groups)
    else:
        if kind.startswith("club"):
            tier = "gold"
            rare = True
        rid = _pick_resource(module, original_choice, kind, tier, rare, used)
    if rid is None:
        return None
    if kind == "manager":
        item = state.make_manager_item(rid, "unassigned")
    elif kind == "consumable":
        item = state.make_consumable_item(rid, "unassigned")
    else:
        item = state.make_club_item(rid, "unassigned", "free")
    used.add(rid)
    return item


def _mixed_pack(module: Any, state: Any, pack_id: int, pack: dict[str, Any], original_choice, original_shuffle) -> dict[str, Any]:
    plan = MIXED_PACKS.get(int(pack_id))
    if not plan:
        return pack
    items = list(pack.get("itemData") or [])
    if not items:
        return pack
    manager_count, consumable_count, club_count = plan
    normal = [(idx, item) for idx, item in enumerate(items) if str(item.get("itemType", "player")).lower() == "player" and not _is_special(module, item)]
    normal.sort(key=lambda pair: (int(pair[1].get("rating", 0) or 0), int(pair[1].get("rareflag", 0) or 0), int(pair[1].get("id", 0) or 0)))
    chosen: list[tuple[int, str]] = []
    remaining = list(normal)
    club_kinds = []
    if club_count == 1:
        club_kinds = [original_choice(["club_kit", "club_badge"])]
    elif club_count > 1:
        club_kinds = ["club_kit", "club_badge"] + [original_choice(["club_kit", "club_badge"]) for _ in range(club_count - 2)]
    for club_kind in club_kinds:
        pos = next((i for i, pair in enumerate(remaining) if int(pair[1].get("rareflag", 0) or 0) > 0), None)
        if pos is None:
            break
        idx, _item = remaining.pop(pos)
        chosen.append((idx, club_kind))
    for kind, count in (("manager", manager_count), ("consumable", consumable_count)):
        for _ in range(count):
            if not remaining:
                break
            idx, _item = remaining.pop(0)
            chosen.append((idx, kind))
    used = {int(item.get("resourceId", item.get("assetId", 0)) or 0) for item in items}
    used_groups: set[int] = set()
    for idx, kind in sorted(chosen, key=lambda pair: pair[0], reverse=True):
        source = items[idx]
        replacement = _make_non_player(module, state, original_choice, original_shuffle, kind, source, used, used_groups)
        if replacement is None:
            continue
        try:
            state.delete_item(int(source.get("id", 0) or 0))
        except Exception:
            try:
                state.delete_item(int(replacement.get("id", 0) or 0))
            except Exception:
                pass
            continue
        items[idx] = replacement
    order = {"player": 0, "manager": 1, "development": 2, "kit": 3, "custom": 3, "stadium": 3, "ball": 3}
    items.sort(key=lambda item: order.get(str(item.get("itemType", "player")).lower(), 4))
    pack["itemData"] = items
    pack["itemList"] = items
    pack["items"] = items
    pack["numberItems"] = len(items)
    pack["newcards"] = len(items)
    native_duplicates = list(pack.get("duplicateItemIdList") or [])
    remaining_ids = {int(item.get("id", 0) or 0) for item in items}
    duplicate_pairs = []
    for entry in native_duplicates:
        if not isinstance(entry, dict):
            continue
        item_id = int(entry.get("itemId", 0) or 0)
        if item_id not in remaining_ids:
            continue
        pair = {"itemId": item_id}
        duplicate_id = int(entry.get("duplicateItemId", 0) or 0)
        if duplicate_id:
            pair["duplicateItemId"] = duplicate_id
        duplicate_pairs.append(pair)
    pack["duplicateItemIdList"] = duplicate_pairs
    try:
        detail = []
        for item in items:
            rid = int(item.get("resourceId", item.get("assetId", 0)) or 0)
            kind = str(item.get("itemType", "player")).lower()
            source_member = str(module.CONSUMABLE_DB.get(rid, {}).get("sourceMember", ""))
            family = str(module.CLUB_ITEM_DB.get(rid, {}).get("family", ""))
            detail.append((kind, rid, source_member or family))
        module.log.warning("MNG FUT 20 MIXED PACK id=%d items=%s", int(pack_id), detail)
    except Exception:
        pass
    return pack

def _repair_existing_discard_values(module: Any) -> int:
    state = getattr(module, "STATE", None)
    if state is None:
        return 0
    changed = 0
    try:
        items = list(state.list_items())
    except Exception:
        return 0
    for item in items:
        if str(item.get("itemType", "player")).lower() != "player":
            continue
        iid = int(item.get("id", 0) or 0)
        rid = int(item.get("resourceId", item.get("assetId", 0)) or 0)
        if not iid or not rid:
            continue
        value = 0 if item.get("untradeable") else fifa20_player_quick_sell(module, rid)
        if int(item.get("discardValue", -1) or 0) == value:
            continue
        try:
            state.update_item_fields(iid, {"discardValue": value})
            changed += 1
        except Exception:
            pass
    return changed


def apply(module: Any) -> None:
    original_create_pack = module.State.create_pack
    original_choice = module.random.choice
    original_shuffle = module.random.shuffle
    original_get_pack_cfg = module.get_pack_cfg
    original_store_purchasegroups = module._store_purchasegroups
    original_credits_payload = module._credits_payload
    original_route_fut = module.route_fut
    original_battle_opponent = module._native_squad_battle_opponent
    original_battle_match = module._native_squad_battle_match_response
    original_opponent_list = module._sb_opponent_list

    def battle_opponent(slot):
        if int(slot) == 4:
            squad = _totw1_squad(module)
            squad.update({"id": 4, "squadId": 4})
            return squad
        return original_battle_opponent(slot)

    def battle_match(slot):
        if int(module._sb_state().get("selectedOpponentId", -1)) == 4:
            slot = 4
        return original_battle_match(slot)

    def regular_opponent_list(state):
        regular = dict(state, opponents=[entry for entry in state.get("opponents", []) if entry.get("id") != 4])
        return original_opponent_list(regular)

    module._native_squad_battle_opponent = battle_opponent
    module._native_squad_battle_match_response = battle_match
    module._sb_opponent_list = regular_opponent_list
    original_sbc_evaluate = module._sbc_evaluate
    original_generate_player_pick_resources = module._generate_player_pick_resources
    pack_lock = threading.RLock()
    for resource_id, player in list(module.PLAYER_DB.items()):
        asset_id = int(player.get("assetId", resource_id) or resource_id)
        rareflag = int(player.get("rareflag", 0) or 0)
        if int(resource_id) != asset_id and rareflag <= 1:
            module.PLAYER_DB.pop(resource_id, None)
    module.PLAYER_DB[JAMES_FLASHBACK_REAL_ID] = _james_flashback_player(
        JAMES_FLASHBACK_REAL_ID, 243, "Real Madrid", 53, "LaLiga Santander"
    )
    module.PLAYER_DB[JAMES_FLASHBACK_BAYERN_ID] = _james_flashback_player(
        JAMES_FLASHBACK_BAYERN_ID, 21, "Bayern München", 19, "Bundesliga"
    )
    module.PLAYER_DB[JAMES_FLASHBACK_PORTO_ID] = _james_flashback_player(
        JAMES_FLASHBACK_PORTO_ID, 236, "FC Porto", 308, "Liga NOS", 85, "LW", [83, 82, 82, 85, 55, 66]
    )
    module.PLAYER_DB[JAMES_FLASHBACK_MONACO_ID] = _james_flashback_player(
        JAMES_FLASHBACK_MONACO_ID, 69, "AS Monaco", 16, "Ligue 1 Conforama", 85, "RW", [82, 81, 83, 85, 55, 66]
    )
    _install_custom_baby_icons(module)
    ucl_counts = _install_base_ucl_cards(module)
    boosted_ucl = _boost_base_ucl_cards(module)
    _install_launch_promotions(module)
    _install_rami_regular(module)
    _install_exclusive_rewards(module)
    install_foundation_players(module)
    install_martinez_potm(module)
    install_pukki_potm(module)
    install_lewandowski_potm(module)
    install_storyline_catalog(module)
    install_season_pass_otw(module)
    install_hunter_season_reward(module)
    install_draft_tuning(module)
    original_pack_exclusion = module._player_is_excluded_from_packs
    module._player_is_excluded_from_packs = lambda resource_id, meta: (
        module.canonical_player_resource_id(int(resource_id)) in UNAVAILABLE_MARKET_PACK_IDS
        or original_pack_exclusion(resource_id, meta)
    )
    original_market_all_pools = module._market_all_pools

    def exclusive_market_pools():
        return {kind: [resource for resource in resources if int(resource) not in UNAVAILABLE_MARKET_PACK_IDS]
                for kind, resources in original_market_all_pools().items()}

    module._market_all_pools = exclusive_market_pools
    original_build_player_item = module.State.build_player_item
    original_make_player_item = module.State.make_player_item
    original_create_auction = module.State.create_auction

    def exclusive_build_player_item(self, resource_id, item_id, pile="club", loan_games=0):
        item = original_build_player_item(self, resource_id, item_id, pile, loan_games)
        if module.canonical_player_resource_id(int(resource_id)) in UNAVAILABLE_MARKET_PACK_IDS:
            item.update({"untradeable": True, "discardValue": 0})
        return item

    def exclusive_make_player_item(self, resource_id, pile="club"):
        if module.canonical_player_resource_id(int(resource_id)) in DORMANT_STORYLINE_IDS:
            raise ValueError("This Storyline card is catalogue-only and cannot be granted yet")
        return original_make_player_item(self, resource_id, pile)

    def exclusive_create_auction(self, *args, **kwargs):
        resource_id = kwargs.get("resource_id", args[0] if args else 0)
        if module.canonical_player_resource_id(int(resource_id)) in UNAVAILABLE_MARKET_PACK_IDS:
            raise ValueError("This reward is untradeable")
        return original_create_auction(self, *args, **kwargs)

    module.State.build_player_item = exclusive_build_player_item
    module.State.make_player_item = exclusive_make_player_item
    module.State.create_auction = exclusive_create_auction
    original_market_seed = module._market_seed

    def seed_launch_promotions():
        original_market_seed()
        active_resources = {
            int(auction.get("resourceId", auction.get("resource_id", 0)) or 0)
            for auction in module.STATE.list_auctions(seller_type="cpu")
            if auction.get("status") == "active"
        }
        market_groups = [
            [asset_id + rarity * 16777216 for asset_id, rating in entries]
            for rarity, entries in ((3, TOTW1_SPECS), (21, OTW_SPECS))
        ]
        market_groups.append([asset_id + version * 16777216
                              for asset_id in (9014, 30) for version in (1, 2, 3)])
        market_groups.append([BOATENG_REGULAR_ID, BOATENG_UCL_ID])
        market_groups.append([RAMI_REGULAR_ID])
        for resources in market_groups:
            for resource_id in resources:
                if resource_id in active_resources or resource_id not in module.PLAYER_DB:
                    continue
                price = module._market_recommended_price(resource_id)
                item = module.STATE.build_player_item(resource_id, 810000000000 + resource_id, "trade")
                item["itemState"] = "forSale"
                module.STATE.create_auction(
                    resource_id=resource_id, item_data=item, seller_type="cpu", seller_name="MNG FUT",
                    starting_bid=price, buy_now_price=price, duration=3600,
                )

    module._market_seed = seed_launch_promotions
    module.SBC_CATALOG = [entry for entry in module.SBC_CATALOG if int(entry.get("set_id", 0) or 0) not in REMOVED_SBC_SET_IDS]
    for entry in module.SBC_CATALOG:
        if int(entry.get("set_id", 0) or 0) in {20, 21, 22}:
            entry["awards"] = [{"type": "PACK", "pack_id": ADVANCED_GROUP_REWARD_PACK_ID, "count": 1}]
            entry["description"] = {
                20: "Solve four escalating league puzzles for a Jumbo Premium Gold Players Pack.",
                21: "Solve four escalating nation puzzles for a Jumbo Premium Gold Players Pack.",
                22: "Master mixed league-and-nation squads for a Jumbo Premium Gold Players Pack.",
            }[int(entry.get("set_id", 0) or 0)]

    module.SBC_CATALOG.insert(0, {
        "set_id": 50,
        "category_id": 2,
        "category": "ADVANCED",
        "priority": 0,
        "name": "Flashback PRIME : James Rodríguez",
        "description": "Complete the challenge and choose James Flashback: Real Madrid or Bayern München.",
        "repeatable": False,
        "awards": [{"type": "PLAYER_PICK", "pool": "james_flashback", "options": 2, "count": 1}],
        "challenges": [{
            "challenge_id": 5001,
            "name": "Two Clubs, One Maestro",
            "description": "Exchange an 84-rated squad to unlock the James Rodríguez Flashback Player Pick.",
            "players": 11,
            "formation": "f442",
            "rules": [
                {"kind": "player_count", "value": 11, "scope": "exact", "count": -1, "text": "Players in the Squad: 11"},
                {"kind": "team_rating", "value": 84, "scope": "min", "count": -1, "text": "Team Rating: Min. 84"},
                {"kind": "rare_count", "value": 3, "scope": "min", "count": -1, "text": "Rare Players: Min. 3"},
                {"kind": "chemistry", "value": 60, "scope": "min", "count": -1, "text": "Team Chemistry: Min. 60"},
            ],
            "awards": [],
        }],
    })

    module.SBC_CATALOG.insert(1, {
        "set_id": 51,
        "category_id": 2,
        "category": "ADVANCED",
        "priority": 1,
        "name": "Flashback BABY : James Rodríguez",
        "description": "Complete the challenge and choose James Flashback BABY: FC Porto or AS Monaco.",
        "repeatable": False,
        "awards": [{"type": "PLAYER_PICK", "pool": "james_flashback_baby", "options": 2, "count": 1}],
        "challenges": [{
            "challenge_id": 5101,
            "name": "The Young Maestro",
            "description": "Exchange an 82-rated squad to unlock the James Rodríguez Flashback BABY Player Pick.",
            "players": 11,
            "formation": "f442",
            "rules": [
                {"kind": "player_count", "value": 11, "scope": "exact", "count": -1, "text": "Players in the Squad: 11"},
                {"kind": "team_rating", "value": 82, "scope": "min", "count": -1, "text": "Team Rating: Min. 82"},
                {"kind": "rare_count", "value": 2, "scope": "min", "count": -1, "text": "Rare Players: Min. 2"},
                {"kind": "chemistry", "value": 55, "scope": "min", "count": -1, "text": "Team Chemistry: Min. 55"},
            ],
            "awards": [],
        }],
    })

    module.SBC_CATALOG.insert(2, _davies_sbc())
    module.SBC_CATALOG.insert(3, david_luiz_sbc())
    module.SBC_CATALOG.insert(4, cillessen_sbc())
    module.SBC_CATALOG.insert(5, martinez_potm_sbc())
    module.SBC_CATALOG.insert(6, pukki_potm_sbc())
    module.SBC_CATALOG.insert(7, lewandowski_potm_sbc())
    for set_entry in module.SBC_CATALOG:
        if any(award.get("type") in {"PLAYER", "PLAYER_PICK"} for award in set_entry.get("awards", [])):
            set_entry.update(category_id=PLAYER_CATEGORY_ID, category="Joueur")
    for set_entry in module.SBC_CATALOG[:8]:
        set_id = int(set_entry.get("set_id", 0) or 0)
        if set_id:
            module.SET_BY_ID[set_id] = set_entry
        for challenge_entry in set_entry.get("challenges", []):
            challenge_id = int(challenge_entry.get("challenge_id", 0) or 0)
            if challenge_id:
                module.CHALLENGE_BY_ID[challenge_id] = (set_entry, challenge_entry)
    for set_entry in module.SBC_CATALOG:
        set_id = int(set_entry.get("set_id", 0) or 0)
        for award in set_entry.get("awards", []):
            if award.get("type") not in {"PLAYER", "PLAYER_PICK"}:
                continue
            reward_player = module.PLAYER_DB.get(int(award.get("value", 0) or 0), {})
            if int(reward_player.get("rareflag", 0) or 0) == 21:
                SBC_BADGES[set_id] = "badge_otw.png"
                break

    original_sbc_set_summary = module._sbc_set_summary

    def badge_sbc_set_summary(set_entry, challenge_counts, set_counts):
        summary = original_sbc_set_summary(set_entry, challenge_counts, set_counts)
        set_id = summary["setId"]
        _localized_potm_set(summary, set_id)
        if set_id in SBC_BADGES:
            summary["setImageId"] = f"{1000000 + set_id}-{SBC_BADGE_REVISION}"
        elif set_id in SBC_NATIVE_IMAGES:
            summary["setImageId"] = SBC_NATIVE_IMAGES[set_id]
        return summary

    module._sbc_set_summary = badge_sbc_set_summary
    original_sbc_challenge_payload = module._sbc_challenge_payload

    def image_sbc_challenge_payload(set_entry, challenge_entry, completion_count, priority=0):
        payload = original_sbc_challenge_payload(set_entry, challenge_entry, completion_count, priority)
        _localized_potm_set(payload, set_entry.get("set_id", 0))
        image_id = {**MARTINEZ_CHALLENGE_IMAGES, **PUKKI_CHALLENGE_IMAGES, **LEWANDOWSKI_CHALLENGE_IMAGES}.get(challenge_entry["challenge_id"])
        if image_id:
            payload["challengeImageId"] = image_id
        return payload

    module._sbc_challenge_payload = image_sbc_challenge_payload
    original_sbc_sets_payload = module._sbc_sets_payload

    def player_sbc_sets_payload():
        payload = original_sbc_sets_payload()
        payload["categories"] = [category for category in payload["categories"] if category["categoryId"] != PLAYER_CATEGORY_ID]
        names = {1: "Bases", 2: "Avancé", 3: "Améliorations"}
        for category in payload["categories"]:
            category["name"] = names.get(category["categoryId"], category["name"])
        challenge_counts, set_counts = module.STATE.sbc_completion_counts()
        sets = [module._sbc_set_summary(entry, challenge_counts, set_counts)
                for entry in module.SBC_CATALOG if entry["category_id"] == PLAYER_CATEGORY_ID]
        payload["categories"].append({"categoryId": PLAYER_CATEGORY_ID, "id": PLAYER_CATEGORY_ID,
                                      "name": "Joueur", "priority": 4, "sets": sets})
        return payload

    module._sbc_sets_payload = player_sbc_sets_payload
    original_sbc_awards_payload = module._sbc_awards_payload
    original_requirement_payload = module._sbc_requirement_payload
    original_complete_sbc = module.State.complete_sbc

    def exclusive_awards_payload(awards):
        payload = original_sbc_awards_payload([award for award in awards if award.get("type") != "PLAYER"])
        for reward in payload:
            if reward.get("type") == "pack" and reward.get("value") in {1013, 1016}:
                pack = module.get_pack_cfg(reward["value"])
                reward.update(name=pack["name"], packName=pack["name"], description=pack["bio"],
                              halId=3, assetId=3, packAssetId=3, packId=reward["value"])
        for award in awards:
            if award.get("type") == "PLAYER":
                resource = int(award["value"])
                preview = module.STATE.build_player_item(resource, 0, "unassigned")
                preview.update(untradeable=True, discardValue=0)
                payload.append({"value": resource, "type": "item", "awardType": "item", "halId": 0,
                                "count": int(award.get("count", 1)), "awardCount": int(award.get("count", 1)),
                                "awardValue": resource, "isUntradeable": True, "untradeable": True,
                                "loan": 0, "itemData": preview})
        return payload

    def exclusive_requirement_payload(raw, eligibility_slot):
        player_rules = {"totw_count": ("PLAYER_RARITY", 18), "league_players": ("PLAYER_LEAGUE", 11),
                        "nation_players": ("PLAYER_NATION", 10), "club_players": ("PLAYER_CLUB", 12)}
        if raw.get("kind") in player_rules:
            rule_type, key = player_rules[raw["kind"]]
            return [module._sbc_elg_entry("PLAYER_COUNT", eligibility_slot, 2, raw["count"]),
                    module._sbc_elg_entry("SCOPE", eligibility_slot, 13, module._SBC_SCOPE_IDS[raw["scope"]]),
                    module._sbc_elg_entry(rule_type, eligibility_slot, key, raw["value"])]
        return original_requirement_payload(raw, eligibility_slot)

    def recover_exclusive_sbc_rewards(state, set_id):
        resource_id = PLAYER_SBC_REWARDS[set_id]
        row = state.conn.execute("SELECT times_completed FROM sbc_set_completions WHERE set_id=?", (set_id,)).fetchone()
        rewards = []
        for cycle in range(1, int(row[0]) + 1 if row else 1):
            reward = grant_exclusive_reward(state, resource_id, f"mng_sbc_{set_id}_reward_{cycle}")
            if reward:
                rewards.append(reward)
        return rewards

    def exclusive_complete_sbc(self, challenge_id, set_id, item_ids, challenge_awards, set_challenge_ids, set_awards, repeatable):
        result = original_complete_sbc(self, challenge_id, set_id, item_ids, challenge_awards,
                                       set_challenge_ids, set_awards, repeatable)
        if isinstance(result, dict) and bool(result.get("setCompleted", False)):
            group_prizes = module._sbc_awards_payload(set_awards)
            result["awardedPrizes"] = group_prizes
            result["setAwards"] = group_prizes
            result["success"] = True
            result["challengeComplete"] = True
        if int(set_id) in PLAYER_SBC_REWARDS:
            resource_id = PLAYER_SBC_REWARDS[int(set_id)]
            player_items = recover_exclusive_sbc_rewards(self, int(set_id))
            if not player_items:
                existing_item = self.owned_player_item_by_resource_id(resource_id)
                if isinstance(existing_item, dict):
                    player_items = [existing_item]
            result["itemData"] = player_items
            if player_items:
                player_item = player_items[0]
                for field in ("awardedPrizes", "rewards", "awards"):
                    prizes = result.get(field)
                    if not isinstance(prizes, list):
                        continue
                    for prize in prizes:
                        if not isinstance(prize, dict) or prize.get("type") != "item":
                            continue
                        try:
                            prize_resource = int(prize.get("awardValue", prize.get("value", 0)) or 0)
                        except (TypeError, ValueError):
                            continue
                        if prize_resource == resource_id:
                            prize["itemData"] = player_item
                            prize["itemId"] = int(player_item.get("id", 0) or 0)
            module.log.info("SBC player reward attached set=%d resource=%d itemId=%s", int(set_id),
                            PLAYER_SBC_REWARDS[int(set_id)],
                            player_items[0].get("id") if player_items else "already-granted")
        return result

    module._sbc_awards_payload = exclusive_awards_payload
    module._sbc_requirement_payload = exclusive_requirement_payload
    module.State.complete_sbc = exclusive_complete_sbc
    for set_id in PLAYER_SBC_REWARDS:
        recover_exclusive_sbc_rewards(module.STATE, set_id)

    def tuned_generate_player_pick_resources(pool: str, options: int, min_rating: int = 0):
        if str(pool or "").lower() == "james_flashback":
            return [JAMES_FLASHBACK_REAL_ID, JAMES_FLASHBACK_BAYERN_ID]
        if str(pool or "").lower() == "james_flashback_baby":
            return [JAMES_FLASHBACK_PORTO_ID, JAMES_FLASHBACK_MONACO_ID]
        return original_generate_player_pick_resources(pool, options, min_rating)

    module._generate_player_pick_resources = tuned_generate_player_pick_resources

    def tuned_native_player_pick_payload():
        pending = module.STATE.pending_player_picks()
        if not pending:
            return {
                "playerPicks": [],
                "availablePicks": 0,
                "ownership": [],
                "picks": [],
                "count": 0,
            }
        pick = pending[0]
        pick_id = int(pick.get("id", 0) or 0)
        player_items = []
        ownership = []
        for index, raw_resource_id in enumerate(pick.get("resources", [])):
            resource_id = int(raw_resource_id or 0)
            if resource_id not in module.PLAYER_DB:
                continue
            transient_id = 820000000000 + pick_id * 10 + index
            item = module._native_player_item(
                module.STATE.build_player_item(resource_id, transient_id, "none")
            )
            item["untradeable"] = True
            item["playerPickId"] = pick_id
            item["choiceIndex"] = index
            player_items.append(item)
            ownership.append(bool(module.STATE.owned_player_item_by_resource_id(resource_id)))
        return {
            "playerPicks": player_items,
            "availablePicks": 1 if player_items else 0,
            "ownership": ownership,
            "playerPickId": pick_id,
            "picks": player_items,
            "count": len(pending),
        }

    module._native_player_pick_payload = tuned_native_player_pick_payload

    PLAYER_PICK_TOKEN_ID_BASE = 830000000000
    PLAYER_PICK_DEFINITION_ID_BASE = 760000

    def player_pick_token(pick: dict[str, Any]) -> dict[str, Any]:
        pick_id = int(pick.get("id", 0) or 0)
        token_id = PLAYER_PICK_TOKEN_ID_BASE + pick_id
        definition_id = PLAYER_PICK_DEFINITION_ID_BASE + pick_id
        return {
            "id": token_id,
            "itemId": token_id,
            "definitionId": definition_id,
            "resourceId": definition_id,
            "assetId": definition_id,
            "timestamp": int(pick.get("createdAt", 0) or 0),
            "itemState": "free",
            "itemType": "misc",
            "cardsubtypeid": 237,
            "cardSubtypeId": 237,
            "subtype": 237,
            "rareflag": 0,
            "rating": 0,
            "owners": 1,
            "untradeable": True,
            "discardValue": 0,
            "lastSalePrice": 0,
            "resourceGameYear": 2020,
            "pile": "unassigned",
            "playerPickId": pick_id,
            "availablePicks": 1,
            "name": "Player Pick",
            "displayName": "Player Pick",
        }

    def sync_pending_player_pick_token() -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
        pending = module.STATE.pending_player_picks()
        active_pick = pending[0] if pending else None
        active_token = player_pick_token(active_pick) if active_pick else None
        active_token_id = int(active_token.get("id", 0) or 0) if active_token else 0
        for item in module.STATE.list_items("unassigned"):
            item_id = int(item.get("id", 0) or 0)
            subtype = int(
                item.get("cardsubtypeid", item.get("cardSubtypeId", item.get("subtype", 0)))
                or 0
            )
            if subtype == 237 and item_id >= PLAYER_PICK_TOKEN_ID_BASE and item_id != active_token_id:
                module.STATE.delete_item(item_id)
        if active_token and not module.STATE.get_item(active_token_id):
            with module.STATE.lock:
                module.STATE.conn.execute(
                    "INSERT OR REPLACE INTO items(id,resource_id,pile,data) VALUES(?,?,?,?)",
                    (
                        active_token_id,
                        int(active_token["resourceId"]),
                        "unassigned",
                        json.dumps(active_token, separators=(",", ":")),
                    ),
                )
                module.STATE.conn.commit()
            module.log.info(
                "PLAYER PICK persisted unassigned token id=%d definition=%d pending=%d",
                active_token_id,
                int(active_token["definitionId"]),
                len(pending),
            )
        return active_pick, active_token

    def pending_pick_for_identifier(identifier: int) -> dict[str, Any] | None:
        for pick in module.STATE.pending_player_picks():
            pick_id = int(pick.get("id", 0) or 0)
            if identifier in {
                pick_id,
                PLAYER_PICK_TOKEN_ID_BASE + pick_id,
                PLAYER_PICK_DEFINITION_ID_BASE + pick_id,
            }:
                return pick
        return None

    def player_pick_payload_for(pick: dict[str, Any]) -> dict[str, Any]:
        pending = module.STATE.pending_player_picks()
        if not pending or int(pending[0].get("id", 0) or 0) != int(pick.get("id", 0) or 0):
            return {
                "playerPicks": [],
                "availablePicks": 0,
                "ownership": [],
                "picks": [],
                "count": len(pending),
            }
        return tuned_native_player_pick_payload()

    def player_pick_selection(payload: Any) -> tuple[int, int]:
        selected_resource = 0
        choice_index = 0

        def inspect(value: Any) -> None:
            nonlocal selected_resource, choice_index
            if isinstance(value, dict):
                for key in ("resourceId", "definitionId", "selectedResourceId"):
                    try:
                        candidate = int(value.get(key, 0) or 0)
                    except Exception:
                        candidate = 0
                    if candidate in module.PLAYER_DB:
                        selected_resource = candidate
                        break
                for key in ("choiceIndex", "selectedIndex", "index"):
                    try:
                        if key in value:
                            choice_index = max(0, int(value.get(key, 0) or 0))
                            break
                    except Exception:
                        pass
                for child in value.values():
                    inspect(child)
            elif isinstance(value, list):
                for child in value:
                    inspect(child)

        inspect(payload)
        return choice_index, selected_resource

    def tuned_sbc_evaluate(challenge_entry: dict[str, Any], saved: dict[str, Any] | None):
        extra_rules = [rule for rule in challenge_entry.get("rules", []) if rule.get("kind") in {"totw_count", "league_players", "nation_players", "club_players"}]
        evaluated_entry = dict(challenge_entry)
        evaluated_entry["rules"] = [rule for rule in challenge_entry.get("rules", []) if rule not in extra_rules]
        valid, checks, item_ids = original_sbc_evaluate(evaluated_entry, saved)
        for rule in extra_rules:
            items = [module.STATE.get_item(item_id) or {} for item_id in item_ids]
            field = {"totw_count": "rareflag", "league_players": "leagueId", "nation_players": "nation", "club_players": "teamid"}[rule["kind"]]
            actual = sum(int(item.get(field, 0) or 0) == int(rule["value"]) for item in items)
            checks.append({"type": rule["kind"], "target": rule["count"], "actual": actual,
                           "scope": "min", "valid": actual >= rule["count"]})
        reported_rating = 0
        if isinstance(saved, dict):
            try:
                reported_rating = int(saved.get("rating", 0) or 0)
            except Exception:
                reported_rating = 0
        if reported_rating > 0:
            for check in checks:
                if str(check.get("type", "")) != "team_rating":
                    continue
                target = int(check.get("target", 0) or 0)
                scope = str(check.get("scope", "min"))
                check["actual"] = reported_rating
                check["valid"] = (
                    reported_rating >= target if scope == "min"
                    else reported_rating <= target if scope == "max"
                    else reported_rating == target
                )
        return all(bool(check.get("valid", False)) for check in checks), checks, item_ids

    module._sbc_evaluate = tuned_sbc_evaluate

    def fifa_points() -> int:
        with module.STATE.lock:
            row = module.STATE.conn.execute("SELECT value FROM kv WHERE key='fifa_points'").fetchone()
            try:
                return max(0, int(json.loads(row[0]))) if row else 0
            except Exception:
                return 0

    def add_fifa_points(amount: int) -> int:
        with module.STATE.lock:
            row = module.STATE.conn.execute("SELECT value FROM kv WHERE key='fifa_points'").fetchone()
            try:
                current = max(0, int(json.loads(row[0]))) if row else 0
            except Exception:
                current = 0
            balance = max(0, current + int(amount))
            module.STATE.conn.execute(
                "INSERT INTO kv(key,value) VALUES('fifa_points',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (json.dumps(balance),),
            )
            module.STATE.conn.commit()
            return balance

    def tuned_credits_payload():
        payload = original_credits_payload()
        for currency in payload.get("currencies", []):
            if str(currency.get("name", "")).lower() == "points":
                currency["funds"] = fifa_points()
                currency["finalFunds"] = fifa_points()
        return payload

    module._credits_payload = tuned_credits_payload

    def tuned_get_pack_cfg(pack_id: int):
        try:
            if int(pack_id) in REMOVED_STORE_PACKS:
                return {}
        except Exception:
            pass
        return original_get_pack_cfg(pack_id)

    def tuned_store_purchasegroups():
        payload = original_store_purchasegroups()
        if isinstance(payload, dict) and isinstance(payload.get("purchase"), list):
            payload = dict(payload)
            rows = [row for row in payload["purchase"] if int(row.get("packId", row.get("id", 0)) or 0) not in REMOVED_STORE_PACKS]
            for row in rows:
                pid = int(row.get("packId", row.get("id", 0)) or 0)
                point_price = int(STORE_POINT_PRICES.get(pid, 0))
                row["points"] = point_price
                row["isFifaPointPurchasable"] = point_price > 0 and not bool(row.get("isMyPack", False))
                if isinstance(row.get("currencies"), list):
                    for currency in row["currencies"]:
                        if str(currency.get("name", "")).lower() == "points":
                            currency["funds"] = point_price
                            currency["finalFunds"] = point_price
                if pid in PROMO_STORE_ORDER:
                    order = PROMO_STORE_ORDER[pid]
                    row["categoryList"] = {"categoryId": 4, "orderInCategory": order}
                    row["displayGroup"] = {"value": "special", "priority": 4}
                    row["purchaseGroup"] = "special"
                    row["group"] = "special"
                    row["sortPriority"] = order
                    row["isPromo"] = True
            payload["purchase"] = rows
        return payload

    def tuned_route_fut(method: str, raw_path: str, headers: dict[str, str], body: bytes):
        path = _route_path(raw_path)
        SBC_UI_LOCALE.value = _sbc_request_locale(headers, raw_path)
        if path == "/fut/squadbattle/cmn/mng-totw1.png":
            if method.upper() not in {"GET", "HEAD"}:
                return 405, {"Allow": "GET, HEAD", "Cache-Control": "no-store"}, b""
            poster = (Path(__file__).parent / "assets/livemessaging/totw1.png").read_bytes()
            return 200, {"Content-Type": "image/png", "Content-Length": str(len(poster)), "Cache-Control": "no-store"}, poster if method.upper() == "GET" else b""
        badge_asset = _sbc_badge_asset(path)
        if badge_asset is not None:
            if method.upper() not in {"GET", "HEAD"}:
                return 405, {"Allow": "GET, HEAD", "Cache-Control": "no-store"}, module.json_bytes({"reason": "methodNotAllowed"})
            if not badge_asset.is_file():
                return 404, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "missingSbcBadge"})
            image = badge_asset.read_bytes()
            module.log.info("MNG FUT 20 SBC badge served: %s bytes=%d", badge_asset.name, len(image))
            return 200, {"Content-Type": "image/png", "Content-Length": str(len(image)), "Cache-Control": "no-store"}, image if method.upper() == "GET" else b""
        if method.upper() == "POST" and path == "/ut/game/fifa20/match":
            request = json.loads(body.decode("utf-8")) if body else {}
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(raw_path).query)
            featured_id = module._sb_find_int(request, ("featuredSquadId",), 0)
            consumer = str(request.get("featureConsumerId", query.get("featureConsumerId", [""])[0])).lower()
            slot = module._sb_requested_opponent(request, query)
            if featured_id == 1 or consumer == "sqbttotw" or slot == 4:
                with module._sb_lock:
                    state = module._sb_state()
                    if not any(entry.get("id") == 4 for entry in state.get("opponents", [])):
                        state["opponents"].append({"id": 4, "squad": battle_opponent(4), "played": False,
                                                   "pointsWon": 0, "score": -1, "oppScore": -1})
                        module._sb_save(state)
                request.update({"sqbtOpponentSquadId": 4, "sqbtOppid": 4,
                                "sqbtEventId": int(state["competitionId"])})
                status, response_headers, response_body = original_route_fut(method, raw_path, headers, module.json_bytes(request))
                if status == 200:
                    response = json.loads(response_body)
                    response.update({"sqbtOpponentSquadId": 4, "sqbtOppid": 4, "featuredSquadId": 1})
                    response_body = module.json_bytes(response)
                    module.log.info("TOTW 1 Squad Battles match supplied opponent=4")
                return status, response_headers, response_body
        if method.upper() == "GET" and re.fullmatch(r"/ut/game/fifa20/sqbt/(?:v2/)?user/opponentsquad/4", path):
            return 200, {"Cache-Control": "no-store"}, module.json_bytes(battle_opponent(4))
        if method.upper() == "GET" and path.startswith("/ut/game/fifa20/featuredsquad"):
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(raw_path).query)
            consumer = query.get("featureConsumerId", [""])[0].lower()
            if path == "/ut/game/fifa20/featuredsquad/user/stats" and consumer == "sqbttotw":
                return 200, {"Cache-Control": "no-store"}, module.json_bytes(_totw1_feature_stats(module))
            if path == "/ut/game/fifa20/featuredsquad/history" and consumer == "sqbttotw":
                module.log.info("TOTW 1 history available players=%d", len(TOTW1_SPECS))
                return 200, {"Cache-Control": "no-store"}, module.json_bytes([1])
            if path == "/ut/game/fifa20/featuredsquad/1" or (path == "/ut/game/fifa20/featuredsquad" and consumer == "sqbttotw"):
                squad = _totw1_squad(module)
                module.log.info("TOTW 1 squad supplied players=%d", len(squad["players"]))
                return 200, {"Cache-Control": "no-store"}, module.json_bytes(squad)
        if method.upper() == "POST" and path == "/ut/game/fifa20/auctionhouse":
            request = json.loads(body.decode("utf-8")) if body else {}
            item_data = request.get("itemData", {}) if isinstance(request, dict) else {}
            item_id = int(item_data.get("id", 0) or 0) if isinstance(item_data, dict) else 0
            item = module.STATE.get_item(item_id) or {}
            if int(item.get("resourceId", 0) or 0) in EXCLUSIVE_REWARD_IDS:
                return 403, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "untradeableItem", "code": "UNTRADEABLE_ITEM"})
        dynamic_head = re.fullmatch(r"/fut/playerheads/g4/single/p([0-9]+)\.dds", path)
        if method.upper() == "GET" and dynamic_head:
            head_path = Path(__file__).resolve().parent / "assets" / "playerheads" / ("p" + dynamic_head.group(1) + ".dds")
            if head_path.is_file():
                return 200, {"Content-Type": "image/vnd-ms.dds", "Cache-Control": "no-store"}, head_path.read_bytes()
        sync_pending_player_pick_token()
        point_purchase = False
        point_price = 0
        if method.upper() == "POST" and path == "/ut/game/fifa20/purchased/items":
            try:
                request_payload = json.loads(body.decode("utf-8")) if body else {}
                pack_id = int(request_payload.get("packId", 3) or 3)
                point_purchase = not bool(int(request_payload.get("useCredits", 1) or 0))
                point_price = int(STORE_POINT_PRICES.get(pack_id, 0))
                with module.STATE.lock:
                    earned_pack = module.STATE.conn.execute(
                        "SELECT id FROM unopened_packs WHERE pack_id=? LIMIT 1", (pack_id,)
                    ).fetchone()
                if earned_pack:
                    point_purchase = False
            except Exception:
                point_purchase = False
            if point_purchase and (point_price <= 0 or fifa_points() < point_price):
                payload = {"reason": "insufficientFifaPoints", "duplicateItemIdList": [], "itemData": []}
                payload.update(tuned_credits_payload())
                return 403, {"Cache-Control": "no-store"}, module.json_bytes(payload)
        mode = _disabled_mode(path)
        if mode:
            payload = {
                "reason": FEATURE_DISABLED_MESSAGE,
                "code": "FEATURE_DISABLED",
                "message": FEATURE_DISABLED_MESSAGE,
                "error": FEATURE_DISABLED_MESSAGE,
                "errorMessage": FEATURE_DISABLED_MESSAGE,
                "localizedMessage": FEATURE_DISABLED_MESSAGE,
                "title": mode,
            }
            try:
                module.log.info("MNG FUT 20 disabled mode blocked mode=%s path=%s", mode, path)
            except Exception:
                pass
            return 409, {"Cache-Control": "no-store"}, module.json_bytes(payload)
        numeric_pick_route = re.fullmatch(
            r"/ut/game/fifa20/playerpicks?/([0-9]+)(?:/(?:select|selection|claim))?",
            path,
        )
        resource_pick_route = re.fullmatch(
            r"/ut/game/fifa20/playerpicks/item/([0-9]+)/select", path
        )
        if method.upper() == "POST" and path == "/ut/game/fifa20/item/nontargeted":
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(raw_path).query)
            try:
                token_id = int(query.get("itemId", [0])[0])
            except (ValueError, TypeError):
                token_id = 0
            requested_pick = pending_pick_for_identifier(token_id)
            if requested_pick:
                result = player_pick_payload_for(requested_pick)
                result["itemData"] = result["playerPicks"]
                module.log.info("PLAYER PICK redeemed token=%d id=%d options=%d",
                                token_id, requested_pick["id"], len(result["playerPicks"]))
                return 200, {"Cache-Control": "no-store"}, module.json_bytes(result)
        if method.upper() == "GET" and path == "/ut/game/fifa20/playerpicks/pending":
            pending_rows = []
            for pending_pick in module.STATE.pending_player_picks():
                pick_id = int(pending_pick.get("id", 0) or 0)
                options = []
                for choice_index, resource_id in enumerate(pending_pick.get("resources", [])):
                    resource_id = int(resource_id or 0)
                    if resource_id not in module.PLAYER_DB:
                        continue
                    item = module._native_player_item(module.STATE.build_player_item(
                        resource_id, 820000000000 + pick_id * 10 + choice_index, "none"
                    ))
                    item.update(untradeable=True, playerPickId=pick_id, choiceIndex=choice_index)
                    options.append({"index": choice_index, "itemData": item})
                pending_rows.append({
                    "id": pick_id,
                    "playerPickId": pick_id,
                    "itemId": PLAYER_PICK_TOKEN_ID_BASE + pick_id,
                    "type": str(pending_pick.get("pool", "promo")),
                    "availablePicks": 1,
                    "options": options,
                    "playerPickOptions": options,
                    "itemData": [option["itemData"] for option in options],
                    "items": [option["itemData"] for option in options],
                })
            result = {"playerPicks": pending_rows, "picks": pending_rows,
                      "count": len(pending_rows), "availablePicks": len(pending_rows)}
            module.log.info("PLAYER PICK pending groups=%d options=%s", len(pending_rows),
                            [len(row["options"]) for row in pending_rows])
            return 200, {"Cache-Control": "no-store"}, module.json_bytes(result)
        if method.upper() == "GET" and numeric_pick_route:
            requested_pick = pending_pick_for_identifier(int(numeric_pick_route.group(1)))
            if requested_pick:
                result = player_pick_payload_for(requested_pick)
                module.log.info(
                    "PLAYER PICK opened token=%s id=%s options=%s",
                    numeric_pick_route.group(1),
                    requested_pick.get("id"),
                    len(result.get("playerPicks", [])),
                )
                return 200, {"Cache-Control": "no-store"}, module.json_bytes(result)
        compatible_pick_claim = method.upper() in {"POST", "PUT"} and (
            path in {
            "/ut/game/fifa20/playerpick",
            "/ut/game/fifa20/playerpicks",
            "/ut/game/fifa20/playerpick/pending",
            "/ut/game/fifa20/playerpicks/pending",
            }
            or numeric_pick_route is not None
            or resource_pick_route is not None
        )
        if compatible_pick_claim:
            pending = module.STATE.pending_player_picks()
            if pending:
                try:
                    request_payload = json.loads(body.decode("utf-8")) if body else {}
                except Exception:
                    request_payload = {}
                choice_index, selected_resource = player_pick_selection(request_payload)
                if resource_pick_route:
                    selected_resource = int(resource_pick_route.group(1))
                route_pick = (
                    pending_pick_for_identifier(int(numeric_pick_route.group(1)))
                    if numeric_pick_route is not None
                    else pending[0]
                )
                if route_pick is None:
                    route_pick = pending[0]
                if resource_pick_route:
                    route_pick = next((pick for pick in pending if selected_resource in
                                       [int(resource) for resource in pick.get("resources", [])]), None)
                    if route_pick is None:
                        return 404, {"Cache-Control": "no-store"}, module.json_bytes({"reason": "playerPickNotFound"})
                pick_id = int(route_pick.get("id", 0) or 0)
                selected = module.STATE.claim_player_pick(pick_id, choice_index, selected_resource)
                if selected:
                    module.STATE.delete_item(PLAYER_PICK_TOKEN_ID_BASE + pick_id)
                    sync_pending_player_pick_token()
                    native_selected = module._native_pack_item(selected)
                    remaining = module._native_player_pick_payload()
                    remaining_picks = module.STATE.pending_player_picks()
                    received_items = [native_selected]
                    if remaining_picks:
                        received_items.append(module._native_pack_item(player_pick_token(remaining_picks[0])))
                    result = {
                        "success": True,
                        "playerPickId": pick_id,
                        "selectedItem": native_selected,
                        "itemData": received_items,
                        "itemList": received_items,
                        "items": received_items,
                        **remaining,
                        **module._credits_payload(),
                    }
                    if resource_pick_route:
                        result = {
                            "itemData": [native_selected],
                            "duplicateItemIdList": [],
                            **module._credits_payload(),
                        }
                    module.log.info(
                        "PLAYER PICK claimed compatible id=%d choice=%d resource=%d remaining=%d",
                        pick_id,
                        choice_index,
                        int(native_selected.get("resourceId", 0) or 0),
                        int(remaining.get("count", 0) or 0),
                    )
                    return 200, {"Cache-Control": "no-store"}, module.json_bytes(result)
        status, response_headers, response_body = original_route_fut(method, raw_path, headers, body)
        if method.upper() == "POST" and int(status) == 200 and path == "/ut/game/fifa20/purchased/items":
            decoded = json.loads(response_body.decode("utf-8"))
            pending = module.STATE.pending_player_picks()
            if isinstance(decoded, dict) and isinstance(decoded.get("itemData"), list) and pending:
                native_token = module._native_pack_item(player_pick_token(pending[0]))
                for item_key in ("itemData", "items", "itemList"):
                    response_items = decoded.get(item_key)
                    if isinstance(response_items, list) and not any(
                        int(item.get("id", 0) or 0) == native_token["id"]
                        for item in response_items if isinstance(item, dict)
                    ):
                        response_items.append(dict(native_token))
                decoded.update(module._native_player_pick_payload())
                module.log.info("PACK_OPEN_PLAYER_PICK token=%d pending=%d items=%d",
                                native_token["id"], len(pending), len(decoded["itemData"]))
                response_body = module.json_bytes(decoded)
        if method.upper() == "GET" and int(status) == 200 and path in {
            "/ut/game/fifa20/usermassinfo",
            "/ut/game/fifa20/purchased/items",
        }:
            decoded = json.loads(response_body.decode("utf-8"))
            if isinstance(decoded, dict):
                pick_payload = module._native_player_pick_payload()
                decoded.update(pick_payload)
                if path.endswith("/usermassinfo") and isinstance(decoded.get("userInfo"), dict):
                    decoded["userInfo"]["availablePicks"] = pick_payload["availablePicks"]
                    decoded["userInfo"]["playerPickCount"] = pick_payload["count"]
                    has_unassigned = bool(module.STATE.list_items("unassigned"))
                    decoded["userInfo"]["purchased"] = has_unassigned
                    module.log.info("UNASSIGNED entry purchased=%s pendingPicks=%d",
                                    has_unassigned, pick_payload["count"])
                response_body = module.json_bytes(decoded)
        if method.upper() == "PUT" and path.endswith("/squad") and "/sbs/challenge/" in path and int(status) == 200:
            try:
                challenge_id = int(path.split("/sbs/challenge/", 1)[1].split("/", 1)[0])
                request_payload = json.loads(body.decode("utf-8")) if body else {}
                reported_rating = int(request_payload.get("rating", 0) or 0)
                if reported_rating > 0:
                    with module.STATE.lock:
                        row = module.STATE.conn.execute(
                            "SELECT data FROM sbc_squads WHERE challenge_id=?", (challenge_id,)
                        ).fetchone()
                        if row:
                            saved_squad = json.loads(row[0])
                            saved_squad["rating"] = reported_rating
                            module.STATE.conn.execute(
                                "UPDATE sbc_squads SET data=? WHERE challenge_id=?",
                                (json.dumps(saved_squad, separators=(",", ":")), challenge_id),
                            )
                            module.STATE.conn.commit()
            except Exception:
                pass
        if (
            method.upper() == "PUT"
            and "/sbs/challenge/" in path
            and not path.endswith("/squad")
            and int(status) == 200
        ):
            try:
                decoded = json.loads(response_body.decode("utf-8"))
                if isinstance(decoded, dict) and bool(decoded.get("setCompleted", False)):
                    sync_pending_player_pick_token()
                    pick_payload = module._native_player_pick_payload()
                    if int(pick_payload.get("count", 0) or 0) > 0:
                        pending = module.STATE.pending_player_picks()
                        token = player_pick_token(pending[0]) if pending else None
                        decoded.update(pick_payload)
                        decoded["playerPickPending"] = True
                        decoded["rewardData"] = pick_payload
                        if token:
                            decoded["itemData"] = [token]
                            decoded["items"] = [token]
                            decoded["itemList"] = [token]
                        response_body = module.json_bytes(decoded)
            except Exception:
                pass
        if point_purchase and int(status) == 200:
            try:
                decoded = json.loads(response_body.decode("utf-8"))
                if isinstance(decoded, dict) and decoded.get("itemData"):
                    add_fifa_points(-point_price)
                    decoded.update(tuned_credits_payload())
                    response_body = module.json_bytes(decoded)
            except Exception:
                pass
        if int(status) == 200 and path == "/ut/game/fifa20/hub":
            try:
                decoded = json.loads(response_body.decode("utf-8"))
                if isinstance(decoded, dict):
                    actual = max(
                        int(decoded.get("auctionCount", 0) or 0),
                        int(decoded.get("liveAuctions", 0) or 0),
                        int(decoded.get("liveTransfers", 0) or 0),
                    )
                    live = _market_live_count(actual)
                    decoded["auctionCount"] = live
                    decoded["liveAuctions"] = live
                    decoded["liveTransfers"] = live
                    response_body = module.json_bytes(decoded)
                    try:
                        module.log.info("MNG FUT 20 market population liveTransfers=%d activeLocal=%d", live, actual)
                    except Exception:
                        pass
            except Exception:
                pass
        return status, response_headers, response_body

    def quick_sell(self, resource_id: int) -> int:
        return fifa20_player_quick_sell(module, resource_id)

    def weighted_player_choice(seq):
        try:
            values = list(seq)
            if len(values) >= 2 and all(isinstance(x, int) for x in values):
                sample = values[: min(16, len(values))]
                if sample and all(int(x) in module.PLAYER_DB for x in sample):
                    weights = []
                    for rid in values:
                        meta = module.PLAYER_DB.get(int(rid), {}) or {}
                        rating = int(meta.get("rating", 0) or 0)
                        special = bool(meta.get("special", False)) or int(meta.get("rareflag", 0) or 0) > 1
                        weights.append(_special_rating_weight(rating) if special else _regular_rating_weight(rating))
                    total = sum(weights)
                    if total > 0:
                        return module.random.choices(values, weights=weights, k=1)[0]
        except Exception:
            pass
        return original_choice(seq)

    def weighted_player_shuffle(seq):
        try:
            if isinstance(seq, list) and len(seq) >= 2 and all(isinstance(x, int) for x in seq[: min(16, len(seq))]):
                sample = seq[: min(16, len(seq))]
                if sample and all(int(x) in module.PLAYER_DB for x in sample):
                    keyed = []
                    for rid in seq:
                        meta = module.PLAYER_DB.get(int(rid), {}) or {}
                        rating = int(meta.get("rating", 0) or 0)
                        special = bool(meta.get("special", False)) or int(meta.get("rareflag", 0) or 0) > 1
                        weight = _special_rating_weight(rating) if special else _regular_rating_weight(rating)
                        weight = max(float(weight), 0.000001)
                        keyed.append((module.random.random() ** (1.0 / weight), rid))
                    keyed.sort(key=lambda pair: pair[0])
                    seq[:] = [rid for _, rid in keyed]
                    return None
        except Exception:
            pass
        return original_shuffle(seq)

    def tuned_create_pack(self, pack_id: int = 1):
        with pack_lock:
            module.random.choice = weighted_player_choice
            module.random.shuffle = weighted_player_shuffle
            try:
                pack = original_create_pack(self, pack_id)
                return _mixed_pack(module, self, int(pack_id), pack, original_choice, original_shuffle)
            finally:
                module.random.choice = original_choice
                module.random.shuffle = original_shuffle

    module.get_pack_cfg = tuned_get_pack_cfg
    module._store_purchasegroups = tuned_store_purchasegroups
    module.route_fut = tuned_route_fut
    install_draft_captain_safety(module)
    module.State.player_discard_value = quick_sell
    module.State.create_pack = tuned_create_pack
    _repair_exclusive_reward_items(module)
    repaired = _repair_existing_discard_values(module)
    from squad_battles_progress import install as install_squad_battles_progress
    install_squad_battles_progress(module)
    from season_pass import apply as apply_season_pass
    apply_season_pass(module)
    from live_messaging import apply as apply_live_messaging
    apply_live_messaging(module)
    from loading_content import apply as apply_loading_content
    apply_loading_content(module)
    from roster_update import apply as apply_roster_update
    apply_roster_update(module)
    from custom_icon_identity import install as install_custom_icon_identity
    install_custom_icon_identity(module)
    from client_hub_data import install as install_client_hub_data
    install_client_hub_data(module)
    from launcher_identity import install as install_launcher_identity
    install_launcher_identity(module)
    from online_leaderboards import install as install_online_leaderboards
    install_online_leaderboards(module)
    from easfc_catalog import install as install_easfc_catalog
    install_easfc_catalog(module)
    from flashback_sbc_badge import install as install_flashback_sbc_badge
    install_flashback_sbc_badge(module)
    try:
        module.log.warning("MNG FUT 20 release tuning active: mixed packs, rating weights, discard values, million-plus market, disabled online modes, removedSBCs=%d, repairedItems=%d, uclCommon=%d, uclRare=%d, boostedUcl=%d", len(REMOVED_SBC_SET_IDS), repaired, ucl_counts[47], ucl_counts[48], boosted_ucl)
    except Exception:
        pass
